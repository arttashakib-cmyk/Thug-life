package com.thuglife.app.data.repository

import com.thuglife.app.data.local.ThugLifeDatabase
import com.thuglife.app.domain.AudioAsset
import com.thuglife.app.domain.Exercise
import com.thuglife.app.domain.ExerciseType
import com.thuglife.app.domain.Expression
import com.thuglife.app.domain.LessonDetail
import com.thuglife.app.domain.LessonStatus
import com.thuglife.app.domain.LessonWithStatus
import com.thuglife.app.domain.Scenario
import com.thuglife.app.domain.ScenarioStep
import com.thuglife.app.domain.ScenarioWithStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class ContentRepository(private val db: ThugLifeDatabase) {
    private val content = db.contentDao()
    private val progress = db.progressDao()

    fun lessonsWithStatus(): Flow<List<LessonWithStatus>> =
        combine(content.observeLessons(), progress.observeLessonProgress()) { lessons, prog ->
            val byId = prog.associateBy { it.lessonId }
            val counts = content.lessonExpressionCounts().associate { it.lessonId to it.n }
            lessons.map { l ->
                val p = byId[l.id]
                val status = when (p?.status) {
                    "COMPLETED" -> LessonStatus.COMPLETED
                    "IN_PROGRESS" -> LessonStatus.IN_PROGRESS
                    else -> LessonStatus.NOT_STARTED
                }
                LessonWithStatus(l.toDomain(), status, p?.bestScorePercent ?: 0, counts[l.id] ?: 0)
            }
        }

    suspend fun lesson(id: String): LessonDetail? {
        val l = content.getLesson(id) ?: return null
        return LessonDetail(l.toDomain(), content.expressionsForLesson(id).map { it.toDomain() })
    }

    suspend fun expression(id: String): Expression? = content.getExpression(id)?.toDomain()
    suspend fun expressions(ids: List<String>): List<Expression> = if (ids.isEmpty()) emptyList() else content.getExpressions(ids).map { it.toDomain() }
    suspend fun allExpressions(): List<Expression> = content.getAllExpressions().map { it.toDomain() }

    suspend fun exercise(id: String): Exercise? = content.getExercise(id)?.toDomain()
    suspend fun exercises(ids: List<String>): List<Exercise> = if (ids.isEmpty()) emptyList() else content.getExercises(ids).mapNotNull { it.toDomain() }
    suspend fun exercisesForLesson(id: String): List<Exercise> = content.exercisesForLesson(id).mapNotNull { it.toDomain() }
    suspend fun exercisesForExpression(id: String): List<Exercise> = content.exercisesForExpression(id).mapNotNull { it.toDomain() }
    suspend fun exercisesByTypes(types: List<ExerciseType>): List<Exercise> =
        content.exercisesByTypes(types.map { it.name }).mapNotNull { it.toDomain() }

    suspend fun audio(id: String?): AudioAsset? = if (id == null) null else content.getAudio(id)?.toDomain()

    fun scenariosWithStatus(): Flow<List<ScenarioWithStatus>> =
        combine(content.observeScenarios(), progress.observeScenarioProgress()) { list, prog ->
            val byId = prog.associateBy { it.scenarioId }
            list.map { s -> ScenarioWithStatus(s.toDomain(), byId[s.id]?.completions ?: 0, byId[s.id]?.bestScorePercent ?: 0) }
        }

    suspend fun scenario(id: String): Scenario? = content.getScenario(id)?.toDomain()
    suspend fun steps(scenarioId: String): List<ScenarioStep> = content.stepsForScenario(scenarioId).map { it.toDomain() }
}
