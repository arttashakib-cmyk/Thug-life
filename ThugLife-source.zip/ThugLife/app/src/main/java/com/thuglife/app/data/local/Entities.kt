package com.thuglife.app.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

// ---------------- Content tables (seeded from assets/content/curriculum.json, upserted by id) ----------------

@Entity(tableName = "expressions", indices = [Index("pathway"), Index("difficulty")])
data class ExpressionEntity(
    @PrimaryKey val id: String,
    val english: String,
    val persian: String,
    val context: String,
    val register: String,
    val topic: String,
    val difficulty: Int,
    val examplesJson: String,
    val alternativesJson: String,
    val warning: String?,
    val pronunciation: String?,
    val audioAssetId: String?,
    val source: String?,
    val tagsJson: String,
    val pathway: String,
    val situationFa: String?,
    val unnaturalText: String?,
    val unnaturalReasonFa: String?
)

@Entity(tableName = "lessons", indices = [Index("pathway", "orderIndex")])
data class LessonEntity(
    @PrimaryKey val id: String,
    val pathway: String,
    val orderIndex: Int,
    val titleFa: String,
    val titleEn: String,
    val descriptionFa: String,
    val introFa: String,
    val difficulty: Int,
    val minutes: Int,
    val lyricJson: String,
    val lyricAttribution: String,
    val newExampleEn: String,
    val newExampleFa: String
)

@Entity(tableName = "lesson_expressions", primaryKeys = ["lessonId", "expressionId"], indices = [Index("expressionId")])
data class LessonExpressionEntity(val lessonId: String, val expressionId: String, val position: Int)

@Entity(tableName = "audio_assets")
data class AudioAssetEntity(
    @PrimaryKey val id: String,
    val kind: String,
    val text: String?,
    val resourceName: String?,
    val locale: String,
    val attribution: String?
)

@Entity(tableName = "exercises", indices = [Index("expressionId"), Index("lessonId"), Index("type")])
data class ExerciseEntity(
    @PrimaryKey val id: String,
    val type: String,
    val skill: String,
    val expressionId: String?,
    val lessonId: String?,
    val difficulty: Int,
    val promptFa: String,
    val promptEn: String?,
    val optionsJson: String,
    val acceptedJson: String,
    val tokensJson: String,
    val explanationFa: String,
    val audioAssetId: String?,
    val timeLimitSec: Int?,
    val orderIndex: Int
)

@Entity(tableName = "scenarios")
data class ScenarioEntity(
    @PrimaryKey val id: String,
    val titleFa: String,
    val titleEn: String,
    val descriptionFa: String,
    val difficulty: Int,
    val topic: String,
    val startStepId: String,
    val stepCount: Int
)

@Entity(tableName = "scenario_steps", indices = [Index("scenarioId", "position")])
data class ScenarioStepEntity(
    @PrimaryKey val id: String,
    val scenarioId: String,
    val position: Int,
    val kind: String,
    val situationFa: String,
    val partnerLine: String?,
    val audioAssetId: String?,
    val optionsJson: String,
    val acceptedJson: String,
    val tokensJson: String,
    val prompt: String?,
    val okFa: String?,
    val badFa: String?,
    val hintFa: String?,
    val formalityFa: String,
    val alternativesJson: String,
    val avoidFa: String?,
    val nextStepId: String?,
    val expressionId: String?
)

// ---------------- Learner tables (never touched by content import) ----------------

@Entity(tableName = "expression_review_states", indices = [Index("nextReviewAt"), Index("learningState")])
data class ReviewStateEntity(
    @PrimaryKey val expressionId: String,
    val successfulRecalls: Int,
    val failedRecalls: Int,
    val firstSeenAt: Long,
    val lastReviewedAt: Long?,
    val nextReviewAt: Long?,
    val easeFactor: Double,
    val intervalDays: Double,
    val repetitions: Int,
    val learningState: String,
    val recentQuality: Int,
    val contextTags: String
)

@Entity(tableName = "learning_sessions", indices = [Index("startedAt")])
data class SessionEntity(
    @PrimaryKey val id: String,
    val mode: String,
    val refId: String?,
    val titleFa: String,
    val startedAt: Long,
    val endedAt: Long?,
    val durationSeconds: Long,
    val attempts: Int,
    val correct: Int,
    val xpEarned: Int,
    val completed: Boolean
)

@Entity(tableName = "exercise_attempts", indices = [Index("sessionId"), Index("timestamp"), Index("skill"), Index("localDate"), Index("expressionId")])
data class AttemptEntity(
    /** Deterministic id "sessionId:ordinal:itemId": a duplicate submit is rejected by the primary key. */
    @PrimaryKey val id: String,
    val sessionId: String,
    val itemId: String,
    val expressionId: String?,
    val skill: String,
    val type: String,
    val isCorrect: Boolean,
    val assisted: Boolean,
    val userAnswer: String,
    val responseTimeMs: Long,
    val timedMode: Boolean,
    val timestamp: Long,
    val localDate: String,
    val xpAwarded: Int
)

/** XP ledger. The primary key is a dedupe key, so the same event can never be counted twice. */
@Entity(tableName = "xp_events", indices = [Index("localDate")])
data class XpEventEntity(
    @PrimaryKey val dedupeKey: String,
    val amount: Int,
    val reason: String,
    val timestamp: Long,
    val localDate: String
)

@Entity(tableName = "lesson_progress")
data class LessonProgressEntity(
    @PrimaryKey val lessonId: String,
    val status: String,
    val bestScorePercent: Int,
    val completions: Int,
    val lastCompletedAt: Long?,
    val lastActiveAt: Long
)

@Entity(tableName = "scenario_progress")
data class ScenarioProgressEntity(
    @PrimaryKey val scenarioId: String,
    val completions: Int,
    val bestScorePercent: Int,
    val lastCompletedAt: Long?
)

@Entity(tableName = "skill_profiles")
data class SkillProfileEntity(
    @PrimaryKey val skill: String,
    val level: Int,
    val samples: Int,
    val lastAdjustSamples: Int
)

@Entity(tableName = "achievements")
data class AchievementEntity(@PrimaryKey val id: String, val unlockedAt: Long)
