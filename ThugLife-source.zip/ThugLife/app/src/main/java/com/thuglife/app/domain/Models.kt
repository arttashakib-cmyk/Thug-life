package com.thuglife.app.domain

enum class Pathway(val fa: String, val subtitleFa: String) {
    RAP("رپ و هیپ‌هاپ", "اصالت، تلاش و اسلنگ خیابان"),
    ROCK("راک", "انرژی صحنه، جاده و سقوط و برخاستن"),
    POP("پاپ", "عشق، ملودی و فرهنگ روز"),
    EVERYDAY("روزمره", "مکالمه‌ی طبیعی هر روز");

    companion object {
        fun fromName(name: String?): Pathway? = entries.firstOrNull { it.name == name }
    }
}

enum class Skill(val fa: String) {
    LISTENING("شنیداری"),
    RECOGNITION("تشخیص عبارت"),
    CONTEXT("درک بافت"),
    RECALL("یادآوری فعال"),
    PRODUCTION("تولید نوشتاری");

    companion object {
        fun fromName(name: String?): Skill? = entries.firstOrNull { it.name == name }
    }
}

enum class Register(val fa: String) {
    FORMAL("رسمی"),
    NEUTRAL("خنثی"),
    INFORMAL("غیررسمی"),
    SLANG("اسلنگ"),
    HUMOROUS("شوخ‌طبعانه"),
    SARCASTIC("طعنه‌آمیز"),
    MILD_RUDE("تند / کمی بی‌ادبانه");

    companion object {
        fun fromName(name: String?): Register = entries.firstOrNull { it.name == name } ?: NEUTRAL
    }
}

enum class InputKind { CHOICE, BINARY, TYPED, ORDER, REVEAL }

enum class ExerciseType(val skill: Skill, val input: InputKind, val titleFa: String, val usesAudio: Boolean = false) {
    MEANING_RECOGNITION(Skill.RECOGNITION, InputKind.CHOICE, "تشخیص سریع معنا"),
    LISTEN_IDENTIFY(Skill.LISTENING, InputKind.CHOICE, "بشنو و شناسایی کن", true),
    RECALL_TYPED(Skill.RECALL, InputKind.TYPED, "یادآوری تایپی"),
    CONTEXT_MATCH(Skill.CONTEXT, InputKind.CHOICE, "تطبیق بافت"),
    SENTENCE_RECONSTRUCTION(Skill.PRODUCTION, InputKind.ORDER, "بازسازی جمله"),
    TYPED_PRODUCTION(Skill.PRODUCTION, InputKind.TYPED, "تولید جمله"),
    NATURAL_OR_UNNATURAL(Skill.CONTEXT, InputKind.BINARY, "طبیعی یا غیرطبیعی؟"),
    AUDIO_MEMORY(Skill.LISTENING, InputKind.TYPED, "حافظه‌ی شنیداری", true),
    SLANG_DECODER(Skill.RECOGNITION, InputKind.CHOICE, "رمزگشای اسلنگ"),
    MISSING_PHRASE(Skill.RECALL, InputKind.TYPED, "عبارت گمشده"),
    LISTEN_COMPREHENSION(Skill.LISTENING, InputKind.CHOICE, "درک مطلب شنیداری", true),
    CONVERSATION_COMEBACK(Skill.CONTEXT, InputKind.CHOICE, "پاسخ مکالمه"),
    FLASHCARD_REVEAL(Skill.RECALL, InputKind.REVEAL, "فلش‌کارت");

    companion object {
        fun fromName(name: String?): ExerciseType? = entries.firstOrNull { it.name == name }
    }
}

enum class AudioKind { TTS, BUNDLED }

data class AudioAsset(
    val id: String,
    val kind: AudioKind,
    val text: String?,
    val resourceName: String?,
    val locale: String,
    val attribution: String?
)

data class Expression(
    val id: String,
    val english: String,
    val persian: String,
    val context: String,
    val register: Register,
    val topic: String,
    val difficulty: Int,
    val examples: List<String>,
    val alternatives: List<String>,
    val warning: String?,
    val pronunciation: String?,
    val audioAssetId: String?,
    val source: String?,
    val tags: List<String>,
    val pathway: Pathway,
    val situationFa: String?
)

data class Lesson(
    val id: String,
    val pathway: Pathway,
    val order: Int,
    val titleFa: String,
    val titleEn: String,
    val descriptionFa: String,
    val introFa: String,
    val difficulty: Int,
    val minutes: Int,
    val lyric: List<String>,
    val lyricAttribution: String,
    val newExampleEn: String,
    val newExampleFa: String
)

data class LessonDetail(val lesson: Lesson, val expressions: List<Expression>)

enum class LessonStatus { NOT_STARTED, IN_PROGRESS, COMPLETED }

data class LessonWithStatus(val lesson: Lesson, val status: LessonStatus, val bestScorePercent: Int, val expressionCount: Int)

data class Exercise(
    val id: String,
    val type: ExerciseType,
    val expressionId: String?,
    val lessonId: String?,
    val difficulty: Int,
    val promptFa: String,
    val promptEn: String?,
    val options: List<String>,
    val accepted: List<String>,
    val tokens: List<String>,
    val explanationFa: String,
    val audioAssetId: String?,
    val timeLimitSec: Int?,
    val order: Int
) {
    val skill: Skill get() = type.skill
}

enum class ScenarioStepKind { CHOICE, LISTEN_CHOICE, TYPED, FILL, ORDER }
enum class OptionQuality(val score: Double) { BEST(1.0), OK(0.6), BAD(0.0) }

data class ScenarioOption(val text: String, val quality: OptionQuality, val feedbackFa: String, val nextStepId: String?)

data class ScenarioStep(
    val id: String,
    val scenarioId: String,
    val position: Int,
    val kind: ScenarioStepKind,
    val situationFa: String,
    val partnerLine: String?,
    val audioAssetId: String?,
    val options: List<ScenarioOption>,
    val accepted: List<String>,
    val tokens: List<String>,
    val prompt: String?,
    val okFa: String?,
    val badFa: String?,
    val hintFa: String?,
    val formalityFa: String,
    val alternatives: List<String>,
    val avoidFa: String?,
    val nextStepId: String?,
    val expressionId: String?
)

data class Scenario(
    val id: String,
    val titleFa: String,
    val titleEn: String,
    val descriptionFa: String,
    val difficulty: Int,
    val topic: String,
    val startStepId: String,
    val stepCount: Int
)

data class ScenarioWithStatus(val scenario: Scenario, val completions: Int, val bestScorePercent: Int)

enum class LearningState { NEW, LEARNING, REVIEW, RELEARNING, MASTERED;
    companion object { fun fromName(n: String?): LearningState = entries.firstOrNull { it.name == n } ?: NEW }
}

enum class ReviewRating(val quality: Int) { AGAIN(0), HARD(3), GOOD(4), EASY(5) }

/** Spaced-repetition state for one expression. All times are epoch milliseconds. */
data class ReviewState(
    val expressionId: String,
    val successfulRecalls: Int = 0,
    val failedRecalls: Int = 0,
    val firstSeenAt: Long = 0L,
    val lastReviewedAt: Long? = null,
    val nextReviewAt: Long? = null,
    val easeFactor: Double = 2.5,
    val intervalDays: Double = 0.0,
    val repetitions: Int = 0,
    val learningState: LearningState = LearningState.NEW,
    val recentQuality: Int = 0,
    val contextTags: String = ""
)

enum class EnglishLevel(val fa: String, val skillLevel: Int) {
    BEGINNER("مبتدی", 1),
    ELEMENTARY("پایه", 2),
    INTERMEDIATE("متوسط", 3),
    UPPER_INTERMEDIATE("بالاتر از متوسط", 4),
    ADVANCED("پیشرفته", 5);

    companion object { fun fromName(n: String?): EnglishLevel = entries.firstOrNull { it.name == n } ?: BEGINNER }
}

enum class LearningGoal(val fa: String) {
    CONVERSATION("مکالمه‌ی روزمره"),
    MUSIC("فهم موسیقی و ترانه"),
    SLANG("اسلنگ و اصطلاحات"),
    LISTENING("تقویت شنیدن"),
    SPEAKING("تلفظ و صحبت کردن");

    companion object { fun fromName(n: String?): LearningGoal = entries.firstOrNull { it.name == n } ?: CONVERSATION }
}
