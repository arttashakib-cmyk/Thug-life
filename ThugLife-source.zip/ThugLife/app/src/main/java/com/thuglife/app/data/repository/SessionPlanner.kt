package com.thuglife.app.data.repository

import com.thuglife.app.data.prefs.PreferencesRepository
import com.thuglife.app.domain.ChallengeKind
import com.thuglife.app.domain.Exercise
import com.thuglife.app.domain.ExerciseType
import com.thuglife.app.domain.Expression
import com.thuglife.app.domain.ReviewState
import com.thuglife.app.domain.Skill
import com.thuglife.app.domain.engine.ReviewKindPolicy
import kotlin.math.abs
import kotlin.random.Random

/** Builds deterministic exercise lists (the seed comes from the session id so a restored session gets the same list). */
class SessionPlanner(
    private val content: ContentRepository,
    private val progress: ProgressRepository,
    private val prefs: PreferencesRepository
) {
    suspend fun lessonPractice(lessonId: String, seed: Long): List<Exercise> {
        val detail = content.lesson(lessonId) ?: return emptyList()
        val all = content.exercisesForLesson(lessonId)
        val byId = all.associateBy { it.id }
        val ids = detail.expressions.map { it.id.removePrefix("x_") }
        val out = ArrayList<Exercise>()
        fun add(id: String) { byId[id]?.let { out.add(it) } }
        add("lc_${lessonId.removePrefix("l_")}")
        ids.take(2).forEach { add("lis_$it") }
        add("lyr_${lessonId.removePrefix("l_")}")
        ids.take(3).forEach { add("rcl_$it") }
        ids.drop(1).take(1).forEach { add("sit_$it") }
        val withBad = ids.firstOrNull { byId.containsKey("natB_$it") }
        if (withBad != null) add("natB_$withBad")
        ids.drop(2).take(1).forEach { add("ord_$it") }
        ids.take(1).forEach { add("prod_$it") }
        return out.distinctBy { it.id }
    }

    suspend fun challenge(kind: ChallengeKind, count: Int, seed: Long): List<Exercise> {
        val rnd = Random(seed)
        val level = progress.skillLevels()
        val pool: List<Exercise> = if (kind == ChallengeKind.DELAYED_RECALL) {
            val old = progress.reviewedBefore(6, 40).map { it.expressionId }.toSet()
            content.exercisesByTypes(kind.types).filter { it.expressionId in old }
        } else {
            content.exercisesByTypes(kind.types)
        }
        return pickByLevel(pool, level[kind.types.first().skill] ?: 2, count, rnd)
    }

    suspend fun weakness(skill: Skill, count: Int, seed: Long): List<Exercise> {
        val rnd = Random(seed)
        val types = ExerciseType.entries.filter { it.skill == skill && it != ExerciseType.FLASHCARD_REVEAL }
        val pool = content.exercisesByTypes(types)
        val mistakes = progress.recentMistakeExpressionIds(15).toSet()
        val prioritized = pool.filter { it.expressionId in mistakes }.shuffled(rnd).take(count / 2)
        val level = progress.skillLevels()[skill] ?: 2
        val rest = pickByLevel(pool.filter { p -> prioritized.none { it.id == p.id } }, level, count - prioritized.size, rnd)
        return (prioritized + rest).distinctBy { it.id }.shuffled(rnd)
    }

    suspend fun diagnostic(): List<Exercise> {
        val self = prefs.current().level.skillLevel
        val rnd = Random(self.toLong() * 7919L)
        val plan = listOf(
            ExerciseType.LISTEN_IDENTIFY, ExerciseType.MEANING_RECOGNITION, ExerciseType.CONTEXT_MATCH,
            ExerciseType.RECALL_TYPED, ExerciseType.SENTENCE_RECONSTRUCTION
        )
        val out = ArrayList<Exercise>()
        for (t in plan) {
            val pool = content.exercisesByTypes(listOf(t))
            out.addAll(pickByLevel(pool, self, 2, rnd))
        }
        return out
    }

    suspend fun review(ahead: Boolean, limit: Int): List<Exercise> {
        val states: List<ReviewState> = if (ahead) progress.aheadStates(limit) else progress.dueStates(limit)
        val out = ArrayList<Exercise>()
        for (s in states) {
            val expr = content.expression(s.expressionId) ?: continue
            val candidates = content.exercisesForExpression(s.expressionId)
            var chosen: Exercise? = null
            for (type in ReviewKindPolicy.preferred(s)) {
                if (type == ExerciseType.FLASHCARD_REVEAL) { chosen = flashcard(expr, s); break }
                val match = candidates.firstOrNull { it.type == type }
                if (match != null) { chosen = match; break }
            }
            out.add(chosen ?: flashcard(expr, s))
        }
        return out
    }

    private fun flashcard(e: Expression, s: ReviewState): Exercise {
        val forward = s.repetitions % 2 == 0
        return Exercise(
            id = "fc_${e.id}_${if (forward) "a" else "b"}", type = ExerciseType.FLASHCARD_REVEAL, expressionId = e.id, lessonId = null,
            difficulty = e.difficulty,
            promptFa = if (forward) "معنی و کاربرد این عبارت را به یاد بیاورید." else "عبارت انگلیسیِ «${e.persian}» چه بود؟",
            promptEn = if (forward) e.english else null,
            options = emptyList(), accepted = listOf(e.english), tokens = emptyList(),
            explanationFa = if (forward) "${e.persian}\n\n${e.context}" else "${e.english}\n\n${e.context}",
            audioAssetId = e.audioAssetId, timeLimitSec = null, order = 0
        )
    }

    private fun pickByLevel(pool: List<Exercise>, level: Int, count: Int, rnd: Random): List<Exercise> {
        if (pool.isEmpty() || count <= 0) return emptyList()
        val shuffled = pool.shuffled(rnd)
        return shuffled.sortedBy { abs(it.difficulty - level) }.take(count).shuffled(rnd)
    }
}
