package com.thuglife.app.domain.engine

import com.thuglife.app.domain.ExerciseType
import com.thuglife.app.domain.ReviewRating

/**
 * Turns an exercise outcome into a review rating. Speed never raises a rating above GOOD and a fast wrong
 * answer is always AGAIN: speed and accuracy are tracked separately, and speed alone is never mastery.
 */
object RatingPolicy {
    fun slowThresholdMs(type: ExerciseType): Long = when (type) {
        ExerciseType.MEANING_RECOGNITION, ExerciseType.SLANG_DECODER, ExerciseType.NATURAL_OR_UNNATURAL -> 12_000L
        ExerciseType.LISTEN_IDENTIFY, ExerciseType.CONTEXT_MATCH, ExerciseType.LISTEN_COMPREHENSION,
        ExerciseType.CONVERSATION_COMEBACK -> 20_000L
        ExerciseType.FLASHCARD_REVEAL -> 30_000L
        else -> 45_000L
    }

    fun rate(correct: Boolean, near: Boolean, hintUsed: Boolean, responseMs: Long, type: ExerciseType): ReviewRating {
        if (!correct) return ReviewRating.AGAIN
        if (near || hintUsed) return ReviewRating.HARD
        return if (responseMs > slowThresholdMs(type)) ReviewRating.HARD else ReviewRating.GOOD
    }
}
