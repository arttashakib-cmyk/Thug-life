package com.thuglife.app.domain.engine

data class SpeechComparisonResult(
    val matchedWords: List<String>,
    val missingWords: List<String>,
    val extraWords: List<String>,
    val completion: Double
)

/**
 * Compares recognised text with the target expression word by word. This measures what a recognition engine
 * heard, not pronunciation quality, and the UI says so. No 0..100 "pronunciation score" is ever produced.
 */
object SpeechComparison {
    fun compare(expected: String, recognised: String): SpeechComparisonResult {
        val exp = TextNormalizer.tokens(expected)
        val rec = TextNormalizer.tokens(recognised).toMutableList()
        val matched = mutableListOf<String>()
        val missing = mutableListOf<String>()
        for (w in exp) {
            val idx = rec.indexOf(w)
            if (idx >= 0) { matched.add(w); rec.removeAt(idx) } else missing.add(w)
        }
        val completion = if (exp.isEmpty()) 0.0 else matched.size.toDouble() / exp.size
        return SpeechComparisonResult(matched, missing, rec.toList(), completion)
    }
}
