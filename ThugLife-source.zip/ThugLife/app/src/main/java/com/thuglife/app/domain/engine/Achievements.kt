package com.thuglife.app.domain.engine

data class AchievementDef(val id: String, val titleFa: String, val descFa: String)

/** Inputs the achievement rules look at. All come from recorded data. */
data class AchievementFacts(
    val lessonsCompleted: Int,
    val scenariosCompleted: Int,
    val recalledExpressions: Int,
    val currentStreak: Int,
    val longestStreak: Int,
    val totalXp: Int,
    val perfectLesson: Boolean,
    val pathwaysTouched: Int,
    val sessionsCompleted: Int,
    val listeningCorrect: Int
)

object Achievements {
    val all: List<AchievementDef> = listOf(
        AchievementDef("first_lesson", "اولین قدم", "اولین درس را کامل کردید."),
        AchievementDef("first_scenario", "اولین گفتگو", "اولین سناریوی حالت خیابان را کامل کردید."),
        AchievementDef("recall_10", "ده عبارت در ذهن", "ده عبارت را بدون کمک درست یادآوری کردید."),
        AchievementDef("recall_30", "حافظه‌ی در حال رشد", "سی عبارت را با موفقیت یادآوری کردید."),
        AchievementDef("streak_3", "سه روز پشت‌سرهم", "سه روز پیاپی تمرین کردید."),
        AchievementDef("streak_7", "یک هفته‌ی کامل", "هفت روز پیاپی تمرین کردید."),
        AchievementDef("xp_200", "۲۰۰ امتیاز", "به ۲۰۰ امتیاز تجربه رسیدید."),
        AchievementDef("xp_1000", "۱۰۰۰ امتیاز", "به ۱۰۰۰ امتیاز تجربه رسیدید."),
        AchievementDef("perfect_lesson", "بی‌نقص", "یک آزمون درس را با نمره‌ی کامل گذراندید."),
        AchievementDef("explorer", "کاوشگر سبک‌ها", "در هر چهار مسیر موسیقی حداقل یک درس کامل کردید."),
        AchievementDef("good_ear", "گوش تیز", "ده تمرین شنیداری را درست جواب دادید."),
        AchievementDef("sessions_10", "پایبندی", "ده جلسه‌ی تمرین را تمام کردید.")
    )

    /** Missing a day never removes an achievement; these only ever unlock. */
    fun unlocked(f: AchievementFacts): Set<String> = buildSet {
        if (f.lessonsCompleted >= 1) add("first_lesson")
        if (f.scenariosCompleted >= 1) add("first_scenario")
        if (f.recalledExpressions >= 10) add("recall_10")
        if (f.recalledExpressions >= 30) add("recall_30")
        if (f.longestStreak >= 3) add("streak_3")
        if (f.longestStreak >= 7) add("streak_7")
        if (f.totalXp >= 200) add("xp_200")
        if (f.totalXp >= 1000) add("xp_1000")
        if (f.perfectLesson) add("perfect_lesson")
        if (f.pathwaysTouched >= 4) add("explorer")
        if (f.listeningCorrect >= 10) add("good_ear")
        if (f.sessionsCompleted >= 10) add("sessions_10")
    }
}
