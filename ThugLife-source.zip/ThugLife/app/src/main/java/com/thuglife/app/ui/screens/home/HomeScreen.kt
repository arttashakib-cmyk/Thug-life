package com.thuglife.app.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.thuglife.app.AppContainer
import com.thuglife.app.core.fa
import com.thuglife.app.core.faShort
import com.thuglife.app.data.repository.DayStat
import com.thuglife.app.domain.LessonStatus
import com.thuglife.app.domain.SessionMode
import com.thuglife.app.domain.engine.RecAction
import com.thuglife.app.domain.engine.Recommendation
import com.thuglife.app.domain.engine.Recommender
import com.thuglife.app.ui.components.AppCard
import com.thuglife.app.ui.components.ErrorState
import com.thuglife.app.ui.components.LoadingState
import com.thuglife.app.ui.components.PrimaryButton
import com.thuglife.app.ui.components.ProgressLine
import com.thuglife.app.ui.components.ScreenScaffold
import com.thuglife.app.ui.components.SectionTitle
import com.thuglife.app.ui.components.StatTile
import com.thuglife.app.ui.components.containerViewModel
import com.thuglife.app.ui.navigation.Routes
import com.thuglife.app.ui.theme.Orange
import com.thuglife.app.ui.theme.Violet
import com.thuglife.app.ui.theme.VioletDeep
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class HomeUi(
    val name: String,
    val levelLabel: String,
    val level: Int,
    val totalXp: Int,
    val levelProgress: Float,
    val streak: Int,
    val activeToday: Boolean,
    val xpToday: Int,
    val dailyTarget: Int,
    val due: Int,
    val overdue: Int,
    val recommendation: Recommendation,
    val weekly: List<DayStat>,
    val lessonsDone: Int,
    val lessonsTotal: Int,
    val recalled: Int,
    val encountered: Int
)

sealed interface HomeState {
    data object Loading : HomeState
    data object Failed : HomeState
    data class Ready(val ui: HomeUi) : HomeState
}

fun RecAction.route(): String = when (this) {
    RecAction.StartReview -> Routes.session(SessionMode.REVIEW)
    is RecAction.OpenLesson -> Routes.lesson(lessonId)
    is RecAction.Weakness -> Routes.session(SessionMode.WEAKNESS, skill.name)
    RecAction.OpenStreet -> Routes.STREET
    RecAction.OpenArena -> Routes.ARENA
}

class HomeViewModel(private val c: AppContainer) : ViewModel() {
    val state: StateFlow<HomeState> = build().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState.Loading)

    private fun build(): Flow<HomeState> =
        combine(c.prefs.preferences, c.progress.observeStats(), c.content.lessonsWithStatus(), c.content.scenariosWithStatus(), c.progress.observeXpToday()) { prefs, stats, lessons, scenarios, xpToday ->
            val level = prefs.level.skillLevel
            val inProgress = lessons.firstOrNull { it.status == LessonStatus.IN_PROGRESS }
            val next = lessons.filter { it.status == LessonStatus.NOT_STARTED }.sortedWith(
                compareBy<com.thuglife.app.domain.LessonWithStatus>(
                    { if (prefs.genres.isEmpty() || it.lesson.pathway in prefs.genres) 0 else 1 },
                    { maxOf(0, it.lesson.difficulty - (level + 1)) },
                    { it.lesson.order }
                )
            ).firstOrNull()
            val snapshot = c.progress.snapshot(
                inProgress?.let { it.lesson.id to it.lesson.titleFa }, next?.let { it.lesson.id to it.lesson.titleFa },
                scenarios.any { it.completions == 0 }
            )
            val ui = HomeUi(
                prefs.displayName, prefs.level.fa, stats.level, stats.totalXp, stats.levelProgress, stats.streak.current, stats.streak.activeToday,
                xpToday, prefs.dailyTargetXp, snapshot.dueCount, snapshot.overdueCount, Recommender.recommend(snapshot),
                stats.weekly, lessons.count { it.status == LessonStatus.COMPLETED }, lessons.size, stats.recalled, stats.encountered
            )
            HomeState.Ready(ui) as HomeState
        }.catch { emit(HomeState.Failed) }
}

@Composable
fun HomeScreen(onNavigate: (String) -> Unit, onSettings: () -> Unit, onProgress: () -> Unit) {
    val vm = containerViewModel { c, _ -> HomeViewModel(c) }
    val state by vm.state.collectAsStateWithLifecycle()
    ScreenScaffold(title = "Thug Life", actions = {
        IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = "تنظیمات") }
    }) { padding ->
        Box(Modifier.padding(padding)) {
            when (val s = state) {
                HomeState.Loading -> LoadingState()
                HomeState.Failed -> ErrorState("نمایش اطلاعات صفحه‌ی اصلی ممکن نشد. برنامه را ببندید و دوباره باز کنید.")
                is HomeState.Ready -> HomeContent(s.ui, onNavigate, onProgress)
            }
        }
    }
}

@Composable
private fun HomeContent(ui: HomeUi, onNavigate: (String) -> Unit, onProgress: () -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(VioletDeep, Violet, Orange.copy(alpha = 0.85f)))).padding(20.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (ui.name.isBlank()) "سلام! آماده‌ای؟" else "سلام ${ui.name}!", style = MaterialTheme.typography.headlineSmall, color = Color.White)
                Text("سطح انگلیسی: ${ui.levelLabel}  ·  سطح تجربه ${ui.level.fa()}", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.9f))
                ProgressLine(ui.levelProgress, color = Color.White)
                Text("${ui.totalXp.fa()} امتیاز  ·  🔥 ${ui.streak.fa()} روز پیاپی", style = MaterialTheme.typography.labelLarge, color = Color.White)
            }
        }

        AppCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("قدم بعدی پیشنهادی", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                Text(ui.recommendation.titleFa, style = MaterialTheme.typography.titleLarge)
                Text(ui.recommendation.reasonFa, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                PrimaryButton("ادامه‌ی یادگیری", { onNavigate(ui.recommendation.action.route()) }, Modifier.fillMaxWidth())
            }
        }

        AppCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionTitle("ماموریت امروز")
                val ratio = if (ui.dailyTarget == 0) 0f else ui.xpToday.toFloat() / ui.dailyTarget
                ProgressLine(ratio)
                Text("${ui.xpToday.fa()} از ${ui.dailyTarget.fa()} امتیاز هدف روزانه", style = MaterialTheme.typography.bodyMedium)
                Text(
                    when {
                        ui.xpToday >= ui.dailyTarget -> "هدف امروز را کامل کردید. هر تمرین بیشتر هم مفید است، اما فشاری نیست."
                        ui.activeToday -> "امروز شروع کرده‌اید؛ چند تمرین دیگر تا هدف مانده است."
                        ui.streak > 0 -> "اگر امروز تمرین کنید، رشته‌ی ${ui.streak.fa()} روزه‌ی شما ادامه پیدا می‌کند."
                        else -> "هر وقت آماده بودید با یک تمرین کوتاه شروع کنید."
                    },
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (ui.due > 0) Text("${ui.due.fa()} مرور سررسید" + if (ui.overdue > 0) " (${ui.overdue.fa()} مورد عقب‌افتاده)" else "", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("درس کامل‌شده", "${ui.lessonsDone.fa()} از ${ui.lessonsTotal.fa()}", Modifier.weight(1f))
            StatTile("عبارت یادآوری‌شده", "${ui.recalled.fa()} از ${ui.encountered.fa()} دیده‌شده", Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
        }

        AppCard(Modifier.fillMaxWidth(), onClick = onProgress) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionTitle("فعالیت هفته")
                val max = (ui.weekly.maxOfOrNull { it.total } ?: 0).coerceAtLeast(1)
                Row(Modifier.fillMaxWidth().height(72.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                    ui.weekly.forEach { d ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size(width = 22.dp, height = (6 + 42 * d.total.toFloat() / max).dp).clip(RoundedCornerShape(6.dp))
                                    .background(if (d.total > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                            )
                            Text(d.date.dayOfWeek.faShort(), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        SectionTitle("دسترسی سریع")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickTile("🎵", "آزمایشگاه موسیقی", Modifier.weight(1f)) { onNavigate(Routes.MUSIC) }
            QuickTile("🏙️", "حالت خیابان", Modifier.weight(1f)) { onNavigate(Routes.STREET) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickTile("🏆", "میدان چالش", Modifier.weight(1f)) { onNavigate(Routes.ARENA) }
            QuickTile("🧠", "کارت‌های حافظه", Modifier.weight(1f)) { onNavigate(Routes.MEMORY) }
        }
        QuickTile("📊", "پیشرفت من", Modifier.fillMaxWidth(), onProgress)
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun QuickTile(emoji: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    AppCard(modifier, onClick = onClick) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(emoji, style = MaterialTheme.typography.headlineSmall)
            Text(label, style = MaterialTheme.typography.titleSmall)
        }
    }
}
