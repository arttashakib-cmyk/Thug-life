package com.thuglife.app

import android.content.Context
import com.thuglife.app.audio.AudioController
import com.thuglife.app.audio.SpeechController
import com.thuglife.app.audio.VoiceRecorder
import com.thuglife.app.core.Clock
import com.thuglife.app.core.FeedbackPlayer
import com.thuglife.app.core.SystemTimeClock
import com.thuglife.app.data.content.ContentImporter
import com.thuglife.app.data.local.ThugLifeDatabase
import com.thuglife.app.data.online.OnlineServices
import com.thuglife.app.data.prefs.PreferencesRepository
import com.thuglife.app.data.repository.ContentRepository
import com.thuglife.app.data.repository.ProgressRepository
import com.thuglife.app.data.repository.SessionPlanner

/** Manual dependency container (no DI framework): every collaborator is created lazily, once. */
class AppContainer(private val context: Context) {
    val clock: Clock = SystemTimeClock
    val database: ThugLifeDatabase by lazy { ThugLifeDatabase.build(context) }
    val prefs: PreferencesRepository by lazy { PreferencesRepository(context) }
    val content: ContentRepository by lazy { ContentRepository(database) }
    val progress: ProgressRepository by lazy { ProgressRepository(database, prefs, clock) }
    val importer: ContentImporter by lazy { ContentImporter(context, database, prefs) }
    val planner: SessionPlanner by lazy { SessionPlanner(content, progress, prefs) }
    val audio: AudioController by lazy { AudioController(context) }
    val speech: SpeechController by lazy { SpeechController(context) }
    val recorder: VoiceRecorder by lazy { VoiceRecorder(context) }
    val feedback: FeedbackPlayer by lazy { FeedbackPlayer(context) }
    val online: OnlineServices = OnlineServices()
}
