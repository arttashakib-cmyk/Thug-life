package com.thuglife.app.ui.navigation

import com.thuglife.app.domain.SessionMode

object Routes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val MUSIC = "music"
    const val STREET = "street"
    const val ARENA = "arena"
    const val MEMORY = "memory"
    const val PROGRESS = "progress"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val LESSON = "lesson/{id}"
    const val SCENARIO = "scenario/{id}"
    const val SPEAK = "speak/{id}"
    const val SESSION = "session/{mode}/{ref}/{timed}"

    fun lesson(id: String) = "lesson/$id"
    fun scenario(id: String) = "scenario/$id"
    fun speak(expressionId: String) = "speak/$expressionId"
    fun session(mode: SessionMode, ref: String = "-", timed: Boolean = false) = "session/${mode.name}/$ref/$timed"

    val bottomBarRoutes = setOf(HOME, MUSIC, STREET, ARENA, MEMORY)
}
