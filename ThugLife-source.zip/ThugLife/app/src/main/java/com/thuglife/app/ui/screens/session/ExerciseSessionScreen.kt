package com.thuglife.app.ui.screens.session

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.CompositionLocalProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.thuglife.app.core.DAY_MS
import com.thuglife.app.core.HOUR_MS
import com.thuglife.app.core.MINUTE_MS
import com.thuglife.app.core.durationFa
import com.thuglife.app.core.fa
import com.thuglife.app.core.percentFa
import com.thuglife.app.domain.Exercise
import com.thuglife.app.domain.ExerciseType
import com.thuglife.app.domain.InputKind
import com.thuglife.app.domain.ReviewRating
import com.thuglife.app.domain.ReviewState
import com.thuglife.app.domain.engine.Achievements
import com.thuglife.app.ui.components.AppCard
import com.thuglife.app.ui.components.AudioPlayRow
import com.thuglife.app.ui.components.EmptyState
import com.thuglife.app.ui.components.EnglishText
import com.thuglife.app.ui.components.ErrorState
import com.thuglife.app.ui.components.LoadingState
import com.thuglife.app.ui.components.PrimaryButton
import com.thuglife.app.ui.components.ProgressLine
import com.thuglife.app.ui.components.ScreenScaffold
import com.thuglife.app.ui.components.SecondaryButton
import com.thuglife.app.ui.components.StatTile
import com.thuglife.app.ui.components.Tag
import com.thuglife.app.ui.components.containerViewModel
import com.thuglife.app.ui.theme.Danger
import com.thuglife.app.ui.theme.Success

private val persianChars = Regex("[\\u0600-\\u06FF]")
private fun hasPersian(s: String) = persianChars.containsMatchIn(s)

fun describeNextReview(s: ReviewState?, now: Long): String? {
    val next = s?.nextReviewAt ?: return null
    val d = next - now
    return when {
        d < 90 * MINUTE_MS -> "مرور بعدی: حدود ${(d / MINUTE_MS).coerceAtLeast(1).fa()} دقیقه دیگر"
        d < DAY_MS -> "مرور بعدی: حدود ${(d / HOUR_MS).coerceAtLeast(1).fa()} ساعت دیگر"
        else -> "مرور بعدی: حدود ${(d / DAY_MS).coerceAtLeast(1).fa()} روز دیگر"
    }
}

@Composable
fun ExerciseSessionScreen(onExit: () -> Unit, onFinishedPrimary: () -> Unit, finishedPrimaryLabel: String = "پایان") {
    val vm = containerViewModel { c, h -> ExerciseSessionViewModel(c, h) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    var confirmExit by rememberSaveable { mutableStateOf(false) }
    val active = ui is SessionUi.Active
    BackHandler(enabled = active) { confirmExit = true }

    val title = when (val s = ui) {
        is SessionUi.Active -> s.exercise.type.titleFa
        is SessionUi.Finished -> "نتیجه‌ی جلسه"
        else -> "تمرین"
    }
    ScreenScaffold(title = title, onBack = { if (active) confirmExit = true else onExit() }) { padding ->
        Column(Modifier.padding(padding).fillMaxWidth()) {
            when (val s = ui) {
                SessionUi.Loading -> LoadingState()
                is SessionUi.Empty -> EmptyState(s.messageFa, actionText = "بازگشت", onAction = onExit)
                is SessionUi.Error -> ErrorState(s.messageFa, onRetry = { vm.retry() })
                is SessionUi.Active -> ActiveView(s, vm)
                is SessionUi.Finished -> FinishedView(s, finishedPrimaryLabel, onFinishedPrimary)
            }
        }
    }
    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("خروج از تمرین؟") },
            text = { Text("پاسخ‌هایی که تا اینجا داده‌اید ذخیره شده‌اند و در پیشرفت شما حساب می‌شوند.") },
            confirmButton = { TextButton(onClick = { confirmExit = false; onExit() }) { Text("خروج") } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("ادامه‌ی تمرین") } }
        )
    }
}

@Composable
private fun ActiveView(s: SessionUi.Active, vm: ExerciseSessionViewModel) {
    val ex = s.exercise
    Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${(s.index + 1).fa()} از ${s.total.fa()}", style = MaterialTheme.typography.labelLarge)
            if (s.timed && s.timeLeftSec != null) {
                Tag("⏱ ${s.timeLeftSec.fa()} ثانیه", color = if (s.timeLeftSec <= 5) Danger else MaterialTheme.colorScheme.secondary)
            }
        }
        ProgressLine((s.index).toFloat() / s.total.toFloat())

        AppCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(ex.promptFa, style = MaterialTheme.typography.titleMedium)
                if (!ex.promptEn.isNullOrBlank()) EnglishText(ex.promptEn, Modifier.fillMaxWidth(), MaterialTheme.typography.titleLarge)
                if (ex.audioAssetId != null) AudioPlayRow(ex.audioAssetId, autoPlay = true)
            }
        }

        val answered = s.feedback != null
        when (ex.type.input) {
            InputKind.CHOICE -> ChoiceInput(ex, s.feedback, vm::submit)
            InputKind.BINARY -> BinaryInput(ex, s.feedback, vm::submit)
            InputKind.TYPED -> TypedInput(ex, answered, vm::submit)
            InputKind.ORDER -> OrderInput(ex, answered) { vm.submit("", it) }
            InputKind.REVEAL -> RevealInput(ex, s.feedback, vm::selfRate)
        }
        s.feedback?.let { FeedbackPanel(ex, it, last = s.index + 1 >= s.total, onNext = vm::next) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun OptionText(text: String, color: Color = Color.Unspecified) {
    if (hasPersian(text)) Text(text, style = MaterialTheme.typography.bodyLarge, color = color, modifier = Modifier.fillMaxWidth())
    else EnglishText(text, Modifier.fillMaxWidth(), MaterialTheme.typography.bodyLarge, color)
}

@Composable
private fun ChoiceInput(ex: Exercise, fb: AnswerFeedback?, onPick: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ex.options.forEach { opt ->
            val isCorrect = ex.accepted.contains(opt)
            val chosen = fb?.userAnswer == opt
            val border = when {
                fb != null && isCorrect -> Success
                fb != null && chosen -> Danger
                else -> MaterialTheme.colorScheme.outline
            }
            OutlinedButton(
                onClick = { onPick(opt) },
                modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium,
                border = BorderStroke(if (fb != null && (isCorrect || chosen)) 2.dp else 1.dp, border)
            ) {
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) { OptionText(opt, MaterialTheme.colorScheme.onSurface) }
            }
        }
    }
}

@Composable
private fun BinaryInput(ex: Exercise, fb: AnswerFeedback?, onPick: (String) -> Unit) {
    val labels = listOf("NATURAL" to "طبیعی و درست", "UNNATURAL" to "غیرطبیعی یا نادرست")
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        labels.forEach { (key, label) ->
            val isCorrect = ex.accepted.contains(key)
            val chosen = fb?.userAnswer == key
            val border = when {
                fb != null && isCorrect -> Success
                fb != null && chosen -> Danger
                else -> MaterialTheme.colorScheme.outline
            }
            OutlinedButton(
                onClick = { onPick(key) }, modifier = Modifier.fillMaxWidth().height(56.dp), shape = MaterialTheme.shapes.medium,
                border = BorderStroke(if (fb != null && (isCorrect || chosen)) 2.dp else 1.dp, border)
            ) { Text(label, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface) }
        }
    }
}

@Composable
private fun TypedInput(ex: Exercise, answered: Boolean, onSubmit: (String) -> Unit) {
    var text by rememberSaveable(ex.id) { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
            value = text, onValueChange = { if (!answered) text = it.take(120) }, enabled = !answered,
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("پاسخ انگلیسی") },
            textStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Ltr, textAlign = TextAlign.Left),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, autoCorrectEnabled = false, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { if (!answered && text.isNotBlank()) onSubmit(text) })
        )
        if (!answered) PrimaryButton("بررسی پاسخ", { onSubmit(text) }, Modifier.fillMaxWidth(), enabled = text.isNotBlank())
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun OrderInput(ex: Exercise, answered: Boolean, onSubmit: (List<String>) -> Unit) {
    val picked = remember(ex.id) { mutableStateListOf<Int>() }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            AppCard(Modifier.fillMaxWidth()) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (picked.isEmpty()) Text("کلمه‌ها را به ترتیب انتخاب کنید…", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                    picked.forEach { idx ->
                        AssistChip(onClick = { if (!answered) picked.remove(idx) }, label = { Text(ex.tokens[idx], style = MaterialTheme.typography.bodyLarge) })
                    }
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ex.tokens.forEachIndexed { idx, token ->
                    if (idx !in picked) {
                        AssistChip(onClick = { if (!answered) picked.add(idx) }, label = { Text(token, style = MaterialTheme.typography.bodyLarge) })
                    }
                }
            }
        }
    }
    if (!answered) {
        PrimaryButton("بررسی پاسخ", { onSubmit(picked.map { ex.tokens[it] }) }, Modifier.fillMaxWidth(), enabled = picked.isNotEmpty())
        if (picked.isNotEmpty()) SecondaryButton("پاک کردن", { picked.clear() }, Modifier.fillMaxWidth())
    }
}

@Composable
private fun RevealInput(ex: Exercise, fb: AnswerFeedback?, onRate: (ReviewRating) -> Unit) {
    var revealed by rememberSaveable(ex.id) { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (!revealed) {
            PrimaryButton("نمایش پاسخ", { revealed = true }, Modifier.fillMaxWidth())
            Text("اول سعی کنید پاسخ را از ذهن بیاورید، بعد پاسخ را ببینید و صادقانه امتیاز بدهید.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            AppCard(Modifier.fillMaxWidth()) { Text(ex.explanationFa, style = MaterialTheme.typography.bodyLarge) }
            if (fb == null) {
                Text("چقدر راحت یادتان آمد؟", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(ReviewRating.AGAIN to "دوباره", ReviewRating.HARD to "سخت", ReviewRating.GOOD to "خوب", ReviewRating.EASY to "آسان").forEach { (r, label) ->
                        OutlinedButton(onClick = { onRate(r) }, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 12.dp)) {
                            Text(label, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeedbackPanel(ex: Exercise, fb: AnswerFeedback, last: Boolean, onNext: () -> Unit) {
    val color = if (fb.correct) Success else Danger
    val c = com.thuglife.app.ui.components.LocalContainer.current
    AppCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val head = when {
                fb.timedOut -> "زمان تمام شد"
                ex.type.input == InputKind.REVEAL -> "ثبت شد"
                fb.near -> "تقریباً درست! (غلط تایپی کوچک)"
                fb.correct -> "درست!"
                else -> "درست نبود"
            }
            Text(head, style = MaterialTheme.typography.titleMedium, color = color)
            if (ex.type.input != InputKind.REVEAL) {
                val shown = when (fb.correctAnswer) {
                    "NATURAL" -> "طبیعی و درست"
                    "UNNATURAL" -> "غیرطبیعی یا نادرست"
                    else -> fb.correctAnswer
                }
                if (!fb.correct || fb.near) {
                    Text("پاسخ درست:", style = MaterialTheme.typography.labelLarge)
                    if (hasPersian(shown)) Text(shown, style = MaterialTheme.typography.bodyLarge) else EnglishText(shown, Modifier.fillMaxWidth(), MaterialTheme.typography.bodyLarge)
                }
                if (ex.type != ExerciseType.FLASHCARD_REVEAL) Text(ex.explanationFa, style = MaterialTheme.typography.bodyMedium)
            }
            if (fb.xp > 0) Text("+${fb.xp.fa()} امتیاز", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            else if (fb.correct && !fb.duplicate) Text("برای این تمرین امروز قبلاً امتیاز گرفته‌اید.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            describeNextReview(fb.review, c.clock.now())?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            PrimaryButton(if (last) "مشاهده‌ی نتیجه" else "ادامه", onNext, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun FinishedView(s: SessionUi.Finished, primaryLabel: String, onPrimary: () -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(s.titleFa, style = MaterialTheme.typography.headlineSmall)
        val ratio = if (s.summary.total == 0) 0.0 else s.summary.correct.toDouble() / s.summary.total
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("پاسخ درست", "${s.summary.correct.fa()} از ${s.summary.total.fa()}", Modifier.weight(1f))
            StatTile("دقت", percentFa(ratio), Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("امتیاز این جلسه", (s.summary.xp + s.bonusXp).fa(), Modifier.weight(1f))
            StatTile("زمان واقعی پاسخ‌دادن", durationFa(s.summary.activeSeconds), Modifier.weight(1f), MaterialTheme.colorScheme.tertiary)
        }
        if (s.leveledUp) AppCard(Modifier.fillMaxWidth()) { Text("🎉 به سطح ${s.newLevel.fa()} رسیدید!", style = MaterialTheme.typography.titleMedium) }
        if (s.lessonScore != null) {
            AppCard(Modifier.fillMaxWidth()) {
                Column {
                    Text("نمره‌ی آزمون درس: ${percentFa(s.lessonScore / 100.0)}", style = MaterialTheme.typography.titleSmall)
                    Text(if (s.lessonScore >= 50) "درس کامل شد و عبارت‌ها برای مرور زمان‌بندی شدند." else "این درس ثبت شد، اما برای گرفتن امتیاز تکمیل، دست‌کم ۵۰٪ لازم است. می‌توانید دوباره امتحان کنید.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        if (s.diagnosticSkills.isNotEmpty()) {
            AppCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("تخمین اولیه‌ی مهارت‌ها", style = MaterialTheme.typography.titleSmall)
                    s.diagnosticSkills.forEach { (skill, r) -> Text("${skill.fa}: ${r.first.fa()} از ${r.second.fa()} درست", style = MaterialTheme.typography.bodyMedium) }
                    Text("این فقط یک تخمین اولیه است، نه آزمون رسمی؛ با تمرین به‌روز می‌شود.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        s.summary.newAchievements.forEach { id ->
            Achievements.all.firstOrNull { it.id == id }?.let { a ->
                AppCard(Modifier.fillMaxWidth()) { Column { Text("🏅 ${a.titleFa}", style = MaterialTheme.typography.titleSmall); Text(a.descFa, style = MaterialTheme.typography.bodySmall) } }
            }
        }
        PrimaryButton(primaryLabel, onPrimary, Modifier.fillMaxWidth())
    }
}
