package com.thuglife.app.domain.engine

import java.util.Locale

enum class Verdict { CORRECT, NEAR, WRONG, EMPTY }

data class ValidationResult(val verdict: Verdict, val matched: String? = null) {
    val isAccepted: Boolean get() = verdict == Verdict.CORRECT || verdict == Verdict.NEAR
}

object TextNormalizer {
    private val nonWord = Regex("[^\\p{L}\\p{N} ]")
    private val spaces = Regex("\\s+")

    /** Lowercase, drop apostrophes, hyphens become spaces, strip punctuation, collapse spaces. */
    fun normalize(input: String): String {
        var s = input.lowercase(Locale.ROOT)
        s = s.replace('\u2019', '\'').replace('\u2018', '\'').replace("'", "")
        s = s.replace('-', ' ').replace('\u2013', ' ').replace('\u2014', ' ')
        s = nonWord.replace(s, "")
        return spaces.replace(s, " ").trim()
    }

    fun tokens(input: String): List<String> {
        val n = normalize(input)
        return if (n.isEmpty()) emptyList() else n.split(" ")
    }
}

object AnswerValidator {
    private val negations = setOf("not", "dont", "cant", "never", "isnt", "wasnt", "wont", "no")

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    /**
     * Typed answers. Exact normalized match is CORRECT. A tiny typo (1 edit for 5+ letters, 2 edits for 14+)
     * is NEAR (accepted, but rated HARD). With [allowContains] a longer sentence that contains an accepted
     * phrase as whole words is accepted unless it adds a negation the accepted phrase does not have.
     * This is pattern matching, not semantic understanding of free text.
     */
    fun validateTyped(input: String, accepted: List<String>, allowContains: Boolean = false): ValidationResult {
        val typed = TextNormalizer.normalize(input)
        if (typed.isEmpty()) return ValidationResult(Verdict.EMPTY)
        val norms = accepted.map { it to TextNormalizer.normalize(it) }.filter { it.second.isNotEmpty() }
        norms.firstOrNull { it.second == typed }?.let { return ValidationResult(Verdict.CORRECT, it.first) }
        if (allowContains) {
            val typedTokens = typed.split(" ")
            for ((orig, n) in norms) {
                if (" $typed ".contains(" $n ")) {
                    val accTokens = n.split(" ").toSet()
                    val addedNegation = typedTokens.any { it in negations && it !in accTokens }
                    if (!addedNegation) return ValidationResult(Verdict.CORRECT, orig)
                }
            }
        }
        var best: Pair<String, Int>? = null
        for ((orig, n) in norms) {
            val limit = when {
                n.length >= 14 -> 2
                n.length >= 5 -> 1
                else -> 0
            }
            if (limit == 0) continue
            val d = levenshtein(typed, n)
            if (d <= limit && (best == null || d < best.second)) best = orig to d
        }
        return if (best != null) ValidationResult(Verdict.NEAR, best.first) else ValidationResult(Verdict.WRONG)
    }

    fun validateOrder(selected: List<String>, accepted: List<String>): ValidationResult {
        if (selected.isEmpty()) return ValidationResult(Verdict.EMPTY)
        val typed = TextNormalizer.normalize(selected.joinToString(" "))
        val hit = accepted.firstOrNull { TextNormalizer.normalize(it) == typed }
        return if (hit != null) ValidationResult(Verdict.CORRECT, hit) else ValidationResult(Verdict.WRONG)
    }

    fun validateChoice(selected: String?, accepted: List<String>): ValidationResult {
        if (selected == null) return ValidationResult(Verdict.EMPTY)
        return if (accepted.contains(selected)) ValidationResult(Verdict.CORRECT, selected) else ValidationResult(Verdict.WRONG)
    }
}
