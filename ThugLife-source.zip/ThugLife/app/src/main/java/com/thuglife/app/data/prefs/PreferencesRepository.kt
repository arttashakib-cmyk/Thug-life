package com.thuglife.app.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.thuglife.app.domain.EnglishLevel
import com.thuglife.app.domain.LearningGoal
import com.thuglife.app.domain.Pathway
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "thuglife_settings")

enum class ThemeMode(val fa: String) { DARK("تیره"), LIGHT("روشن"), SYSTEM("مطابق سیستم");
    companion object { fun fromName(n: String?): ThemeMode = entries.firstOrNull { it.name == n } ?: DARK }
}

data class UserPreferences(
    val onboardingCompleted: Boolean = false,
    val displayName: String = "",
    val level: EnglishLevel = EnglishLevel.BEGINNER,
    val goal: LearningGoal = LearningGoal.CONVERSATION,
    val genres: Set<Pathway> = emptySet(),
    val sessionMinutes: Int = 10,
    val dailyTargetXp: Int = 60,
    val remindersEnabled: Boolean = false,
    val reminderHour: Int = 19,
    val onlineEnabled: Boolean = false,
    val theme: ThemeMode = ThemeMode.DARK,
    val playbackSpeed: Float = 1.0f,
    val autoPlayAudio: Boolean = false,
    val soundEffects: Boolean = true,
    val haptics: Boolean = true,
    val contentVersion: Int = 0
)

class PreferencesRepository(private val context: Context) {
    private object K {
        val onboarding = booleanPreferencesKey("onboarding_completed")
        val name = stringPreferencesKey("display_name")
        val level = stringPreferencesKey("level")
        val goal = stringPreferencesKey("goal")
        val genres = stringSetPreferencesKey("genres")
        val sessionMinutes = intPreferencesKey("session_minutes")
        val dailyTarget = intPreferencesKey("daily_target_xp")
        val reminders = booleanPreferencesKey("reminders")
        val reminderHour = intPreferencesKey("reminder_hour")
        val online = booleanPreferencesKey("online_enabled")
        val theme = stringPreferencesKey("theme")
        val speed = floatPreferencesKey("playback_speed")
        val autoPlay = booleanPreferencesKey("auto_play")
        val sfx = booleanPreferencesKey("sound_effects")
        val haptics = booleanPreferencesKey("haptics")
        val contentVersion = intPreferencesKey("content_version")
    }

    val preferences: Flow<UserPreferences> = context.settingsStore.data.map { p ->
        UserPreferences(
            onboardingCompleted = p[K.onboarding] ?: false,
            displayName = p[K.name] ?: "",
            level = EnglishLevel.fromName(p[K.level]),
            goal = LearningGoal.fromName(p[K.goal]),
            genres = (p[K.genres] ?: emptySet()).mapNotNull { Pathway.fromName(it) }.toSet(),
            sessionMinutes = p[K.sessionMinutes] ?: 10,
            dailyTargetXp = p[K.dailyTarget] ?: 60,
            remindersEnabled = p[K.reminders] ?: false,
            reminderHour = p[K.reminderHour] ?: 19,
            onlineEnabled = p[K.online] ?: false,
            theme = ThemeMode.fromName(p[K.theme]),
            playbackSpeed = p[K.speed] ?: 1.0f,
            autoPlayAudio = p[K.autoPlay] ?: false,
            soundEffects = p[K.sfx] ?: true,
            haptics = p[K.haptics] ?: true,
            contentVersion = p[K.contentVersion] ?: 0
        )
    }

    suspend fun current(): UserPreferences = preferences.first()

    suspend fun saveOnboarding(
        name: String, level: EnglishLevel, goal: LearningGoal, genres: Set<Pathway>,
        sessionMinutes: Int, dailyTargetXp: Int, reminders: Boolean, online: Boolean
    ) {
        context.settingsStore.edit {
            it[K.name] = name.trim().take(24)
            it[K.level] = level.name
            it[K.goal] = goal.name
            it[K.genres] = genres.map { g -> g.name }.toSet()
            it[K.sessionMinutes] = sessionMinutes
            it[K.dailyTarget] = dailyTargetXp
            it[K.reminders] = reminders
            it[K.online] = online
            it[K.onboarding] = true
        }
    }

    suspend fun setTheme(v: ThemeMode) { context.settingsStore.edit { it[K.theme] = v.name } }
    suspend fun setPlaybackSpeed(v: Float) { context.settingsStore.edit { it[K.speed] = v } }
    suspend fun setAutoPlay(v: Boolean) { context.settingsStore.edit { it[K.autoPlay] = v } }
    suspend fun setSoundEffects(v: Boolean) { context.settingsStore.edit { it[K.sfx] = v } }
    suspend fun setHaptics(v: Boolean) { context.settingsStore.edit { it[K.haptics] = v } }
    suspend fun setDailyTarget(v: Int) { context.settingsStore.edit { it[K.dailyTarget] = v } }
    suspend fun setReminders(enabled: Boolean) { context.settingsStore.edit { it[K.reminders] = enabled } }
    suspend fun setReminderHour(h: Int) { context.settingsStore.edit { it[K.reminderHour] = h.coerceIn(0, 23) } }
    suspend fun setOnline(v: Boolean) { context.settingsStore.edit { it[K.online] = v } }
    suspend fun setContentVersion(v: Int) { context.settingsStore.edit { it[K.contentVersion] = v } }
    suspend fun setGoal(v: LearningGoal) { context.settingsStore.edit { it[K.goal] = v.name } }
    suspend fun setLevel(v: EnglishLevel) { context.settingsStore.edit { it[K.level] = v.name } }
    suspend fun setGenres(v: Set<Pathway>) { context.settingsStore.edit { it[K.genres] = v.map { g -> g.name }.toSet() } }
    suspend fun setName(v: String) { context.settingsStore.edit { it[K.name] = v.trim().take(24) } }
}
