package com.thuglife.app.ui.screens.music

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.thuglife.app.AppContainer
import com.thuglife.app.core.fa
import com.thuglife.app.core.percentFa
import com.thuglife.app.domain.LessonStatus
import com.thuglife.app.domain.LessonWithStatus
import com.thuglife.app.domain.Pathway
import com.thuglife.app.ui.components.AppCard
import com.thuglife.app.ui.components.EmptyState
import com.thuglife.app.ui.components.ErrorState
import com.thuglife.app.ui.components.LoadingState
import com.thuglife.app.ui.components.ScreenScaffold
import com.thuglife.app.ui.components.Tag
import com.thuglife.app.ui.components.containerViewModel
import com.thuglife.app.ui.components.starsFa
import com.thuglife.app.ui.theme.look
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class MusicUi(val pathway: Pathway, val lessons: List<LessonWithStatus>, val allCount: Int)

sealed interface MusicState {
    data object Loading : MusicState
    data object Failed : MusicState
    data class Ready(val ui: MusicUi) : MusicState
}

class MusicLabViewModel(c: AppContainer, private val handle: SavedStateHandle) : ViewModel() {
    private val selected = MutableStateFlow(Pathway.fromName(handle.get<String>("pathway")) ?: Pathway.RAP)
    val state: StateFlow<MusicState> = combine(c.content.lessonsWithStatus(), selected) { lessons, p ->
        MusicState.Ready(MusicUi(p, lessons.filter { it.lesson.pathway == p }.sortedBy { it.lesson.order }, lessons.size)) as MusicState
    }.catch { emit(MusicState.Failed) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MusicState.Loading)

    fun select(p: Pathway) { selected.value = p; handle["pathway"] = p.name }
}

@Composable
fun MusicLabScreen(onOpenLesson: (String) -> Unit) {
    val vm = containerViewModel { c, h -> MusicLabViewModel(c, h) }
    val state by vm.state.collectAsStateWithLifecycle()
    ScreenScaffold(title = "آزمایشگاه موسیقی") { padding ->
        Column(Modifier.padding(padding)) {
            when (val s = state) {
                MusicState.Loading -> LoadingState()
                MusicState.Failed -> ErrorState("بارگذاری درس‌ها ممکن نشد.")
                is MusicState.Ready -> {
                    PathwayPicker(s.ui.pathway, vm::select)
                    if (s.ui.lessons.isEmpty()) {
                        EmptyState("هنوز درسی در این مسیر نیست.")
                    } else {
                        LazyColumn(
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(s.ui.lessons, key = { it.lesson.id }) { l -> LessonCard(l, onOpenLesson) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PathwayPicker(selected: Pathway, onSelect: (Pathway) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Pathway.entries.forEach { p ->
            val look = p.look()
            val on = p == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                    .background(if (on) look.brush else androidx.compose.ui.graphics.Brush.linearGradient(listOf(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.surfaceVariant)))
                    .clickable { onSelect(p) }.padding(vertical = 10.dp),
                contentAlignment = androidx.compose.ui.Alignment.Center
            ) {
                Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                    Text(look.emoji, style = MaterialTheme.typography.titleMedium)
                    Text(p.fa, style = MaterialTheme.typography.labelMedium, color = if (on) Color.White else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun LessonCard(l: LessonWithStatus, onOpen: (String) -> Unit) {
    val look = l.lesson.pathway.look()
    AppCard(Modifier.fillMaxWidth(), onClick = { onOpen(l.lesson.id) }) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tag("${look.emoji} درس ${l.lesson.order.fa()}", color = look.start)
                when (l.status) {
                    LessonStatus.COMPLETED -> Tag("کامل شد · ${percentFa(l.bestScorePercent / 100.0)}", color = MaterialTheme.colorScheme.tertiary)
                    LessonStatus.IN_PROGRESS -> Tag("در حال یادگیری", color = MaterialTheme.colorScheme.secondary)
                    LessonStatus.NOT_STARTED -> Tag("جدید", color = MaterialTheme.colorScheme.primary)
                }
            }
            Text(l.lesson.titleFa, style = MaterialTheme.typography.titleLarge)
            Text(l.lesson.titleEn, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(l.lesson.descriptionFa, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${l.expressionCount.fa()} عبارت · حدود ${l.lesson.minutes.fa()} دقیقه · ${starsFa(l.lesson.difficulty)}", style = MaterialTheme.typography.bodySmall)
        }
    }
}
