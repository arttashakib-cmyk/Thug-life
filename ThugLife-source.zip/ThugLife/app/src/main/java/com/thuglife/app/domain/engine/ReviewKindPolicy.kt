package com.thuglife.app.domain.engine

import com.thuglife.app.domain.ExerciseType
import com.thuglife.app.domain.LearningState
import com.thuglife.app.domain.ReviewState

/**
 * Chooses which kind of exercise a due expression gets, so reviews mix recognition, listening, recall and
 * production instead of repeating a fixed card order. Items that keep failing get easier recognition first.
 */
object ReviewKindPolicy {
    fun preferred(s: ReviewState): List<ExerciseType> = when {
        s.learningState == LearningState.RELEARNING || s.failedRecalls >= 3 ->
            listOf(ExerciseType.MEANING_RECOGNITION, ExerciseType.LISTEN_IDENTIFY)
        s.repetitions % 4 == 0 -> listOf(ExerciseType.CONTEXT_MATCH, ExerciseType.MEANING_RECOGNITION)
        s.repetitions % 4 == 1 -> listOf(ExerciseType.LISTEN_IDENTIFY, ExerciseType.AUDIO_MEMORY)
        s.repetitions % 4 == 2 -> listOf(ExerciseType.FLASHCARD_REVEAL)
        else -> listOf(ExerciseType.RECALL_TYPED, ExerciseType.TYPED_PRODUCTION)
    }
}
