package com.thuglife.app.ui.screens.street

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.thuglife.app.AppContainer
import com.thuglife.app.core.durationFa
import com.thuglife.app.core.fa
import com.thuglife.app.core.percentFa
import com.thuglife.app.data.repository.AttemptInput
import com.thuglife.app.data.repository.SessionSummary
import com.thuglife.app.domain.ExerciseType
import com.thuglife.app.domain.OptionQuality
import com.thuglife.app.domain.Scenario
import com.thuglife.app.domain.ScenarioStep
import com.thuglife.app.domain.ScenarioStepKind
import com.thuglife.app.domain.Skill
import com.thuglife.app.domain.engine.AnswerValidator
import com.thuglife.app.domain.engine.Verdict
import com.thuglife.app.ui.components.AppCard
import com.thuglife.app.ui.components.AudioPlayRow
import com.thuglife.app.ui.components.EmptyState
import com.thuglife.app.ui.components.EnglishText
import com.thuglife.app.ui.components.ErrorState
import com.thuglife.app.ui.components.LoadingState
import com.thuglife.app.ui.components.PrimaryButton
import com.thuglife.app.ui.components.ScreenScaffold
import com.thuglife.app.ui.components.SecondaryButton
import com.thuglife.app.ui.components.StatTile
import com.thuglife.app.ui.components.Tag
import com.thuglife.app.ui.components.containerViewModel
import com.thuglife.app.ui.theme.Danger
import com.thuglife.app.ui.theme.Success
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class StepFeedback(
    val quality: OptionQuality,
    val messageFa: String,
    val chosen: String,
    val correctAnswer: String?,
    val xp: Int,
    val nextStepId: String?
)

sealed interface ScenarioUi {
    data object Loading : ScenarioUi
    data class Failed(val messageFa: String) : ScenarioUi
    data class Active(val scenario: Scenario, val step: ScenarioStep, val stepNumber: Int, val feedback: StepFeedback?) : ScenarioUi
    data class Finished(val scenario: Scenario, val scorePercent: Int, val summary: SessionSummary, val bonusXp: Int, val steps: Int) : ScenarioUi
}

class ScenarioViewModel(private val c: AppContainer, private val handle: SavedStateHandle) : ViewModel() {
    private val scenarioId: String = handle.get<String>("id") ?: ""
    private val _ui = MutableStateFlow<ScenarioUi>(ScenarioUi.Loading)
    val ui: StateFlow<ScenarioUi> = _ui.asStateFlow()

    private val sessionId: String = handle.get<String>("sid") ?: UUID.randomUUID().toString().also { handle["sid"] = it }
    private var scenario: Scenario? = null
    private var steps: Map<String, ScenarioStep> = emptyMap()
    private var ordinal: Int = handle.get<Int>("n") ?: 0
    private var scoreSum: Float = handle.get<Float>("score") ?: 0f
    private var shownAt = 0L
    private var locked = false

    init { load() }

    fun load() {
        viewModelScope.launch {
            try {
                val sc = c.content.scenario(scenarioId)
                val list = c.content.steps(scenarioId)
                if (sc == null || list.isEmpty()) { _ui.value = ScenarioUi.Failed("این سناریو پیدا نشد."); return@launch }
                scenario = sc
                steps = list.associateBy { it.id }
                c.progress.startSession("STREET", scenarioId, sc.titleFa, sessionId)
                val cur = steps[handle.get<String>("step") ?: sc.startStepId] ?: steps[sc.startStepId]!!
                show(cur)
            } catch (e: Exception) {
                _ui.value = ScenarioUi.Failed("بارگذاری سناریو با خطا مواجه شد.")
            }
        }
    }

    private fun show(step: ScenarioStep) {
        handle["step"] = step.id
        locked = false
        shownAt = c.clock.now()
        _ui.value = ScenarioUi.Active(scenario!!, step, ordinal + 1, null)
    }

    fun chooseOption(index: Int) {
        val s = _ui.value as? ScenarioUi.Active ?: return
        val opt = s.step.options.getOrNull(index) ?: return
        finishStep(s, opt.quality, opt.feedbackFa, opt.text, null, opt.nextStepId ?: s.step.nextStepId, answer = opt.text)
    }

    fun submitText(text: String) {
        val s = _ui.value as? ScenarioUi.Active ?: return
        val step = s.step
        val r = if (step.kind == ScenarioStepKind.TYPED) AnswerValidator.validateTyped(text, step.accepted, allowContains = true)
        else AnswerValidator.validateTyped(text, step.accepted)
        if (r.verdict == Verdict.EMPTY) return
        val q = when (r.verdict) { Verdict.CORRECT -> OptionQuality.BEST; Verdict.NEAR -> OptionQuality.OK; else -> OptionQuality.BAD }
        val msg = if (q == OptionQuality.BAD) (step.badFa ?: "این پاسخ مناسب نیست.") else (step.okFa ?: "درست!")
        finishStep(s, q, msg, text, step.accepted.firstOrNull(), step.nextStepId, answer = text)
    }

    fun submitOrder(tokens: List<String>) {
        val s = _ui.value as? ScenarioUi.Active ?: return
        val step = s.step
        val r = AnswerValidator.validateOrder(tokens, step.accepted)
        if (r.verdict == Verdict.EMPTY) return
        val q = if (r.verdict == Verdict.CORRECT) OptionQuality.BEST else OptionQuality.BAD
        val msg = if (q == OptionQuality.BEST) (step.okFa ?: "درست!") else (step.badFa ?: "ترتیب درست نیست.")
        finishStep(s, q, msg, tokens.joinToString(" "), step.accepted.firstOrNull(), step.nextStepId, answer = tokens.joinToString(" "))
    }

    private fun finishStep(s: ScenarioUi.Active, q: OptionQuality, msg: String, chosen: String, correct: String?, next: String?, answer: String) {
        if (locked) return
        locked = true
        val step = s.step
        val ms = (c.clock.now() - shownAt).coerceAtLeast(0L)
        val ord = ordinal
        viewModelScope.launch {
            val type = when (step.kind) {
                ScenarioStepKind.CHOICE -> ExerciseType.CONVERSATION_COMEBACK
                ScenarioStepKind.LISTEN_CHOICE -> ExerciseType.LISTEN_COMPREHENSION
                ScenarioStepKind.TYPED -> ExerciseType.TYPED_PRODUCTION
                ScenarioStepKind.FILL -> ExerciseType.MISSING_PHRASE
                ScenarioStepKind.ORDER -> ExerciseType.SENTENCE_RECONSTRUCTION
            }
            val skill = if (step.kind == ScenarioStepKind.LISTEN_CHOICE) Skill.LISTENING else type.skill
            val out = c.progress.recordAttempt(
                AttemptInput(sessionId, ord, step.id, step.expressionId, skill, type, q != OptionQuality.BAD, q == OptionQuality.OK, answer.take(200), ms,
                    false, s.scenario.difficulty, null)
            )
            val prefs = c.prefs.current()
            c.feedback.result(q != OptionQuality.BAD, prefs.soundEffects, prefs.haptics)
            if (!out.duplicate) {
                scoreSum += q.score.toFloat()
                ordinal = ord + 1
                handle["n"] = ordinal
                handle["score"] = scoreSum
            }
            _ui.update { cur -> if (cur is ScenarioUi.Active && cur.step.id == step.id) cur.copy(feedback = StepFeedback(q, msg, chosen, correct, out.xpAwarded, next)) else cur }
        }
    }

    fun next() {
        val s = _ui.value as? ScenarioUi.Active ?: return
        val fb = s.feedback ?: return
        val nextStep = fb.nextStepId?.let { steps[it] }
        if (nextStep != null) { show(nextStep); return }
        viewModelScope.launch {
            try {
                val count = ordinal.coerceAtLeast(1)
                val score = ((scoreSum / count) * 100).toInt().coerceIn(0, 100)
                val bonus = c.progress.completeScenario(scenarioId, score)
                val summary = c.progress.finishSession(sessionId)
                _ui.value = ScenarioUi.Finished(s.scenario, score, summary, bonus, count)
            } catch (e: Exception) {
                _ui.value = ScenarioUi.Failed("ذخیره‌ی نتیجه ممکن نشد، اما پاسخ‌های شما ثبت شده‌اند.")
            }
        }
    }
}

@Composable
fun ScenarioScreen(onExit: () -> Unit) {
    val vm = containerViewModel { c, h -> ScenarioViewModel(c, h) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val active = ui is ScenarioUi.Active
    var confirm by rememberSaveable { mutableStateOf(false) }
    BackHandler(enabled = active) { confirm = true }
    ScreenScaffold(title = (ui as? ScenarioUi.Active)?.scenario?.titleFa ?: "حالت خیابان", onBack = { if (active) confirm = true else onExit() }) { padding ->
        Column(Modifier.padding(padding)) {
            when (val s = ui) {
                ScenarioUi.Loading -> LoadingState()
                is ScenarioUi.Failed -> ErrorState(s.messageFa, onRetry = { vm.load() })
                is ScenarioUi.Active -> ActiveStep(s, vm)
                is ScenarioUi.Finished -> FinishedScenario(s, onExit)
            }
        }
    }
    if (confirm) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("خروج از سناریو؟") },
            text = { Text("پاسخ‌های داده‌شده ذخیره شده‌اند، اما این سناریو کامل ثبت نمی‌شود.") },
            confirmButton = { androidx.compose.material3.TextButton(onClick = { confirm = false; onExit() }) { Text("خروج") } },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { confirm = false }) { Text("ادامه") } }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ActiveStep(s: ScenarioUi.Active, vm: ScenarioViewModel) {
    val step = s.step
    val fb = s.feedback
    var revealText by rememberSaveable(step.id) { mutableStateOf(false) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Tag("گام ${s.stepNumber.fa()}", color = MaterialTheme.colorScheme.secondary)
        Text(step.situationFa, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (step.partnerLine != null) {
            AppCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val hide = step.kind == ScenarioStepKind.LISTEN_CHOICE && !revealText && fb == null
                    if (hide) {
                        Text("گوینده چیزی می‌گوید. اول گوش کنید.", style = MaterialTheme.typography.bodyMedium)
                        SecondaryButton("نمایش متن", { revealText = true })
                    } else {
                        EnglishText(step.partnerLine, Modifier.fillMaxWidth(), MaterialTheme.typography.titleLarge)
                    }
                    AudioPlayRow(step.audioAssetId, autoPlay = true)
                }
            }
        }
        when (step.kind) {
            ScenarioStepKind.CHOICE, ScenarioStepKind.LISTEN_CHOICE -> {
                step.options.forEachIndexed { i, o ->
                    val picked = fb?.chosen == o.text
                    val border = when {
                        fb != null && picked && o.quality == OptionQuality.BAD -> Danger
                        fb != null && o.quality == OptionQuality.BEST -> Success
                        fb != null && picked -> MaterialTheme.colorScheme.secondary
                        else -> MaterialTheme.colorScheme.outline
                    }
                    OutlinedButton(
                        onClick = { vm.chooseOption(i) }, modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium,
                        border = BorderStroke(if (fb != null && (picked || o.quality == OptionQuality.BEST)) 2.dp else 1.dp, border)
                    ) { Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) { EnglishText(o.text, Modifier.fillMaxWidth(), MaterialTheme.typography.bodyLarge, MaterialTheme.colorScheme.onSurface) } }
                }
            }
            ScenarioStepKind.TYPED, ScenarioStepKind.FILL -> {
                var text by rememberSaveable(step.id) { mutableStateOf("") }
                if (step.kind == ScenarioStepKind.FILL && step.prompt != null) {
                    AppCard(Modifier.fillMaxWidth()) { EnglishText(step.prompt, Modifier.fillMaxWidth(), MaterialTheme.typography.titleMedium) }
                }
                if (step.hintFa != null) Text("راهنما: ${step.hintFa}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(
                    value = text, onValueChange = { if (fb == null) text = it.take(120) }, enabled = fb == null, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), label = { Text(if (step.kind == ScenarioStepKind.FILL) "کلمه‌ی گمشده" else "پاسخ شما به انگلیسی") },
                    textStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Ltr, textAlign = TextAlign.Left),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, autoCorrectEnabled = false, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { if (fb == null && text.isNotBlank()) vm.submitText(text) })
                )
                if (fb == null) PrimaryButton("بررسی پاسخ", { vm.submitText(text) }, Modifier.fillMaxWidth(), enabled = text.isNotBlank())
            }
            ScenarioStepKind.ORDER -> {
                val picked = remember(step.id) { mutableStateListOf<Int>() }
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        AppCard(Modifier.fillMaxWidth()) {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (picked.isEmpty()) Text("کلمه‌ها را به ترتیب انتخاب کنید…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                picked.forEach { i -> AssistChip(onClick = { if (fb == null) picked.remove(i) }, label = { Text(step.tokens[i]) }) }
                            }
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            step.tokens.forEachIndexed { i, t -> if (i !in picked) AssistChip(onClick = { if (fb == null) picked.add(i) }, label = { Text(t) }) }
                        }
                    }
                }
                if (fb == null) PrimaryButton("بررسی پاسخ", { vm.submitOrder(picked.map { step.tokens[it] }) }, Modifier.fillMaxWidth(), enabled = picked.isNotEmpty())
            }
        }

        if (fb != null) {
            val color = when (fb.quality) { OptionQuality.BEST -> Success; OptionQuality.OK -> MaterialTheme.colorScheme.secondary; OptionQuality.BAD -> Danger }
            AppCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(when (fb.quality) { OptionQuality.BEST -> "پاسخ عالی"; OptionQuality.OK -> "قابل‌قبول، ولی بهتر هم می‌شد"; OptionQuality.BAD -> "مناسب نبود" },
                        style = MaterialTheme.typography.titleMedium, color = color)
                    Text(fb.messageFa, style = MaterialTheme.typography.bodyLarge)
                    if (fb.correctAnswer != null && fb.quality == OptionQuality.BAD) {
                        Text("پاسخ نمونه:", style = MaterialTheme.typography.labelLarge)
                        EnglishText(fb.correctAnswer, Modifier.fillMaxWidth(), MaterialTheme.typography.bodyLarge)
                    }
                    Text("سطح رسمی بودن: ${step.formalityFa}", style = MaterialTheme.typography.bodyMedium)
                    if (step.alternatives.isNotEmpty()) {
                        Text("جایگزین‌ها:", style = MaterialTheme.typography.labelLarge)
                        step.alternatives.forEach { EnglishText(it, Modifier.fillMaxWidth(), MaterialTheme.typography.bodyMedium) }
                    }
                    if (!step.avoidFa.isNullOrBlank()) Text("اشتباه رایج: ${step.avoidFa}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (fb.xp > 0) Text("+${fb.xp.fa()} امتیاز", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                    PrimaryButton(if (fb.nextStepId == null) "پایان سناریو" else "ادامه‌ی گفتگو", vm::next, Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun FinishedScenario(s: ScenarioUi.Finished, onExit: () -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(s.scenario.titleFa, style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("نمره‌ی گفتگو", percentFa(s.scorePercent / 100.0), Modifier.weight(1f))
            StatTile("امتیاز", (s.summary.xp + s.bonusXp).fa(), Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
        }
        AppCard(Modifier.fillMaxWidth()) {
            Text(
                if (s.scorePercent >= 80) "گفتگوی طبیعی و روانی داشتید. این نمره بر اساس کیفیت پاسخ‌هایتان در همین سناریو است."
                else if (s.scorePercent >= 50) "خوب بود. بازخوردهای هر گام را مرور کنید و دوباره امتحان کنید تا پاسخ‌های بهتری بدهید."
                else "این گفتگو سخت بود و اشکالی ندارد. دوباره امتحان کنید؛ بازخورد هر گام کمک می‌کند.",
                style = MaterialTheme.typography.bodyLarge
            )
        }
        com.thuglife.app.domain.engine.Achievements.all.filter { it.id in s.summary.newAchievements }.forEach { a ->
            AppCard(Modifier.fillMaxWidth()) { Column { Text("🏅 ${a.titleFa}", style = MaterialTheme.typography.titleSmall); Text(a.descFa, style = MaterialTheme.typography.bodySmall) } }
        }
        PrimaryButton("بازگشت", onExit, Modifier.fillMaxWidth())
    }
}
