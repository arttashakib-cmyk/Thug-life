package com.thuglife.app.core

import kotlin.math.roundToInt

private const val FA_ZERO = '\u06F0'

/** Converts ASCII digits to Persian digits. */
fun String.toFa(): String {
    val sb = StringBuilder(length)
    for (c in this) {
        if (c in '0'..'9') sb.append((FA_ZERO + (c - '0'))) else sb.append(c)
    }
    return sb.toString()
}

fun Int.fa(): String = toString().toFa()
fun Long.fa(): String = toString().toFa()

fun percentFa(ratio: Double): String = "${(ratio * 100).roundToInt().fa()}٪"

/** Wraps an English fragment in Unicode isolates so it keeps LTR order inside Persian text. */
fun ltr(text: String): String = "\u2066$text\u2069"

fun durationFa(totalSeconds: Long): String {
    val s = if (totalSeconds < 0) 0 else totalSeconds
    val h = s / 3600
    val m = (s % 3600) / 60
    return when {
        h > 0 -> "${h.fa()} ساعت و ${m.fa()} دقیقه"
        m > 0 -> "${m.fa()} دقیقه"
        else -> "${s.fa()} ثانیه"
    }
}

fun java.time.DayOfWeek.faShort(): String = when (this) {
    java.time.DayOfWeek.SATURDAY -> "ش"
    java.time.DayOfWeek.SUNDAY -> "ی"
    java.time.DayOfWeek.MONDAY -> "د"
    java.time.DayOfWeek.TUESDAY -> "س"
    java.time.DayOfWeek.WEDNESDAY -> "چ"
    java.time.DayOfWeek.THURSDAY -> "پ"
    java.time.DayOfWeek.FRIDAY -> "ج"
}
