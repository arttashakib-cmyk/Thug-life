package com.thuglife.app.domain.engine

data class AttemptSample(val correct: Boolean, val assisted: Boolean)

data class SkillLevelState(val level: Int, val samples: Int, val lastAdjustSamples: Int)

/**
 * Per-skill difficulty level (1..5) driven only by recorded performance. To avoid oscillation a level can
 * change at most once per 10 new attempts, by exactly one step, and only when 10 recent samples exist:
 * accuracy >= 85% with at most 2 assisted answers moves up; accuracy <= 50% moves down.
 */
object AdaptiveDifficulty {
    const val WINDOW = 10

    fun adjust(state: SkillLevelState, recentNewestFirst: List<AttemptSample>): SkillLevelState {
        if (state.samples - state.lastAdjustSamples < WINDOW || recentNewestFirst.size < WINDOW) return state
        val window = recentNewestFirst.take(WINDOW)
        val accuracy = window.count { it.correct }.toDouble() / WINDOW
        val assisted = window.count { it.assisted }
        val level = when {
            accuracy >= 0.85 && assisted <= 2 -> minOf(5, state.level + 1)
            accuracy <= 0.5 -> maxOf(1, state.level - 1)
            else -> state.level
        }
        return state.copy(level = level, lastAdjustSamples = state.samples)
    }

    /** Initial level from a diagnostic: needs >= 2 samples, otherwise the self-reported level is kept. */
    fun initialLevel(selfReported: Int, correct: Int, total: Int): Int {
        if (total < 2) return selfReported.coerceIn(1, 5)
        val acc = correct.toDouble() / total
        val delta = when {
            acc >= 0.85 -> 1
            acc <= 0.35 -> -1
            else -> 0
        }
        return (selfReported + delta).coerceIn(1, 5)
    }
}
