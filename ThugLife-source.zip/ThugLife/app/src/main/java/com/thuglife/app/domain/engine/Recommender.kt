package com.thuglife.app.domain.engine

import com.thuglife.app.core.fa
import com.thuglife.app.core.percentFa
import com.thuglife.app.domain.LearningGoal
import com.thuglife.app.domain.Skill

data class SkillAccuracy(val samples: Int, val correct: Int) {
    val accuracy: Double get() = if (samples == 0) 0.0 else correct.toDouble() / samples
}

data class LearnerSnapshot(
    val dueCount: Int,
    val overdueCount: Int,
    val inProgressLessonId: String?,
    val inProgressLessonTitle: String?,
    val nextLessonId: String?,
    val nextLessonTitle: String?,
    val skillAccuracy: Map<Skill, SkillAccuracy>,
    val goal: LearningGoal,
    val lessonsCompleted: Int,
    val scenariosCompleted: Int,
    val hasUnfinishedScenarios: Boolean,
    val xpToday: Int,
    val dailyTargetXp: Int
)

sealed interface RecAction {
    data object StartReview : RecAction
    data class OpenLesson(val lessonId: String) : RecAction
    data class Weakness(val skill: Skill) : RecAction
    data object OpenStreet : RecAction
    data object OpenArena : RecAction
}

data class Recommendation(val titleFa: String, val reasonFa: String, val action: RecAction)

/**
 * Deterministic, explainable recommendation. The first matching rule wins and the reason always cites the
 * recorded numbers it used. With no data it falls back to a plain suggestion instead of pretending to be smart.
 */
object Recommender {
    const val MIN_SKILL_SAMPLES = 8
    const val WEAK_ACCURACY = 0.6

    fun recommend(s: LearnerSnapshot): Recommendation {
        if (s.dueCount >= 8 || (s.dueCount > 0 && s.overdueCount >= 5)) {
            return Recommendation(
                "مرور عبارت‌های سررسید",
                "${s.dueCount.fa()} عبارت موعد مرور دارند و ${s.overdueCount.fa()} مورد از آن‌ها بیش از یک روز عقب افتاده‌اند؛ مرور به‌موقع جلوی فراموشی را می‌گیرد.",
                RecAction.StartReview
            )
        }
        val weakest = s.skillAccuracy.filter { it.value.samples >= MIN_SKILL_SAMPLES && it.value.accuracy < WEAK_ACCURACY }
            .minByOrNull { it.value.accuracy }
        if (weakest != null) {
            return Recommendation(
                "تمرین هدفمند: ${weakest.key.fa}",
                "در ${s.skillAccuracy[weakest.key]!!.samples.fa()} تلاش اخیر، دقت شما در مهارت «${weakest.key.fa}» ${percentFa(weakest.value.accuracy)} بوده است.",
                RecAction.Weakness(weakest.key)
            )
        }
        if (s.inProgressLessonId != null) {
            return Recommendation("ادامه‌ی درس «${s.inProgressLessonTitle ?: ""}»", "این درس را شروع کرده‌اید و هنوز تمام نشده است.", RecAction.OpenLesson(s.inProgressLessonId))
        }
        if (s.dueCount > 0) {
            return Recommendation("مرور ${s.dueCount.fa()} عبارت", "این عبارت‌ها همین حالا موعد مرور دارند.", RecAction.StartReview)
        }
        if (s.goal == LearningGoal.CONVERSATION && s.hasUnfinishedScenarios && s.scenariosCompleted < s.lessonsCompleted) {
            return Recommendation("یک سناریوی حالت خیابان", "هدف شما مکالمه است و تا امروز ${s.lessonsCompleted.fa()} درس اما فقط ${s.scenariosCompleted.fa()} سناریو کامل کرده‌اید.", RecAction.OpenStreet)
        }
        if (s.nextLessonId != null) {
            val why = if (s.lessonsCompleted == 0) "اولین درس مناسب سطح و سلیقه‌ی شما." else "درس بعدی در مسیر انتخابی شما."
            return Recommendation("درس «${s.nextLessonTitle ?: ""}»", why, RecAction.OpenLesson(s.nextLessonId))
        }
        if (s.hasUnfinishedScenarios) {
            return Recommendation("یک سناریوی حالت خیابان", "همه‌ی درس‌های مسیر شما را دیده‌اید؛ حالا در گفتگو به‌کارشان ببرید.", RecAction.OpenStreet)
        }
        return Recommendation("چالش آزاد", "درس تازه‌ای باقی نمانده؛ با چالش‌ها مهارت‌هایتان را محک بزنید.", RecAction.OpenArena)
    }
}
