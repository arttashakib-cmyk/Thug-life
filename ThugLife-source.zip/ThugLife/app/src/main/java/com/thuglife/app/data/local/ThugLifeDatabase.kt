package com.thuglife.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration

/**
 * Schema version 1 is the first released schema. Future changes must bump [version], add a Migration to
 * [Migrations.ALL] and keep exported schemas in app/schemas. The database never uses destructive fallback:
 * learner progress must survive upgrades.
 */
@Database(
    entities = [
        ExpressionEntity::class, LessonEntity::class, LessonExpressionEntity::class, AudioAssetEntity::class,
        ExerciseEntity::class, ScenarioEntity::class, ScenarioStepEntity::class,
        ReviewStateEntity::class, SessionEntity::class, AttemptEntity::class, XpEventEntity::class,
        LessonProgressEntity::class, ScenarioProgressEntity::class, SkillProfileEntity::class, AchievementEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class ThugLifeDatabase : RoomDatabase() {
    abstract fun contentDao(): ContentDao
    abstract fun reviewDao(): ReviewDao
    abstract fun activityDao(): ActivityDao
    abstract fun progressDao(): ProgressDao

    companion object {
        const val NAME = "thuglife.db"

        fun build(context: Context): ThugLifeDatabase =
            Room.databaseBuilder(context.applicationContext, ThugLifeDatabase::class.java, NAME)
                .addMigrations(*Migrations.ALL)
                .build()
    }
}

object Migrations {
    /** Empty until schema 2 exists. Add new Migration(1, 2) objects here. */
    val ALL: Array<Migration> = emptyArray()
}
