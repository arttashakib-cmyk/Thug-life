package com.thuglife.app.core

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator

/** Short haptic and tone feedback, each independently switchable in Settings. Uses system tones: no audio files. */
class FeedbackPlayer(context: Context) {
    private val appContext = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())

    fun result(correct: Boolean, sound: Boolean, haptics: Boolean) {
        if (haptics) vibrate(if (correct) 20L else 60L)
        if (sound) beep(correct)
    }

    private fun vibrate(ms: Long) {
        val v = appContext.getSystemService(Vibrator::class.java) ?: return
        if (v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun beep(correct: Boolean) {
        try {
            val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 40)
            tone.startTone(if (correct) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK, 150)
            handler.postDelayed({ tone.release() }, 400L)
        } catch (e: RuntimeException) {
            // The device refused to create a tone generator; feedback is optional, so we stay silent.
        }
    }
}
