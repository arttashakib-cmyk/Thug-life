package com.thuglife.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import com.thuglife.app.data.prefs.ThemeMode
import com.thuglife.app.domain.Pathway

val Violet = Color(0xFF8B5CF6)
val VioletDeep = Color(0xFF5B34C7)
val Orange = Color(0xFFFF8A3D)
val Charcoal = Color(0xFF121214)
val CharcoalRaised = Color(0xFF1B1B21)
val CharcoalHigh = Color(0xFF25252D)
val Success = Color(0xFF34D399)
val Danger = Color(0xFFFF6B6B)

private val DarkScheme = darkColorScheme(
    primary = Violet, onPrimary = Color.White, primaryContainer = Color(0xFF2E2250), onPrimaryContainer = Color(0xFFE6DDFF),
    secondary = Orange, onSecondary = Color(0xFF2B1400), secondaryContainer = Color(0xFF3D2410), onSecondaryContainer = Color(0xFFFFDCC2),
    tertiary = Color(0xFF2DD4BF), onTertiary = Color(0xFF00201C),
    background = Charcoal, onBackground = Color(0xFFEDEDF2),
    surface = CharcoalRaised, onSurface = Color(0xFFEDEDF2),
    surfaceVariant = CharcoalHigh, onSurfaceVariant = Color(0xFFB4B4C0),
    outline = Color(0xFF3F3F4A), outlineVariant = Color(0xFF2D2D36),
    error = Danger, onError = Color(0xFF3B0000)
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF6D3FD8), onPrimary = Color.White, primaryContainer = Color(0xFFE9DEFF), onPrimaryContainer = Color(0xFF22005D),
    secondary = Color(0xFFC25A0E), onSecondary = Color.White, secondaryContainer = Color(0xFFFFDCC2), onSecondaryContainer = Color(0xFF2B1400),
    tertiary = Color(0xFF0F766E), onTertiary = Color.White,
    background = Color(0xFFF7F5FB), onBackground = Color(0xFF1B1B21),
    surface = Color.White, onSurface = Color(0xFF1B1B21),
    surfaceVariant = Color(0xFFEBE7F3), onSurfaceVariant = Color(0xFF4A4856),
    outline = Color(0xFF7B7889), outlineVariant = Color(0xFFD5D0E0),
    error = Color(0xFFBA1A1A), onError = Color.White
)

private fun style(size: Int, line: Int, weight: FontWeight = FontWeight.Normal) =
    TextStyle(fontSize = size.sp, lineHeight = line.sp, fontWeight = weight)

// Larger line heights than Latin defaults so Persian diacritics and mixed English never clip.
private val AppTypography = Typography(
    displaySmall = style(34, 46, FontWeight.ExtraBold),
    headlineLarge = style(30, 42, FontWeight.ExtraBold),
    headlineMedium = style(26, 38, FontWeight.Bold),
    headlineSmall = style(22, 34, FontWeight.Bold),
    titleLarge = style(20, 30, FontWeight.Bold),
    titleMedium = style(17, 27, FontWeight.SemiBold),
    titleSmall = style(15, 24, FontWeight.SemiBold),
    bodyLarge = style(16, 27),
    bodyMedium = style(14, 24),
    bodySmall = style(12, 20),
    labelLarge = style(14, 22, FontWeight.SemiBold),
    labelMedium = style(12, 20, FontWeight.Medium),
    labelSmall = style(11, 18, FontWeight.Medium)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp), medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(24.dp)
)

/** Visual identity per pathway; STREET is used by Street Mode. */
data class PathwayLook(val start: Color, val end: Color, val emoji: String) {
    val brush: Brush get() = Brush.linearGradient(listOf(start, end))
}

fun Pathway.look(): PathwayLook = when (this) {
    Pathway.RAP -> PathwayLook(Color(0xFF7C3AED), Color(0xFFFF8A3D), "🎤")
    Pathway.ROCK -> PathwayLook(Color(0xFFB91C1C), Color(0xFF3B0D12), "🎸")
    Pathway.POP -> PathwayLook(Color(0xFFD946EF), Color(0xFF6D3FD8), "✨")
    Pathway.EVERYDAY -> PathwayLook(Color(0xFF0E9AA7), Color(0xFF2563EB), "💬")
}

val StreetLook = PathwayLook(Color(0xFFFF8A3D), Color(0xFFE0533D), "🏙️")

@Composable
fun ThugLifeTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    // The whole interface is Persian, so the layout direction is forced to RTL regardless of the device locale.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, typography = AppTypography, shapes = AppShapes, content = content)
    }
}
