package com.thuglife.app.domain.engine

import java.time.LocalDate

data class StreakInfo(val current: Int, val longest: Int, val activeToday: Boolean)

object StreakCalculator {
    /**
     * Streaks use local calendar dates recorded with each attempt. The current streak stays alive through
     * today if yesterday was active, so a learner is never "broken" before the day has ended. Dates later than
     * [today] (possible after travelling to an earlier time zone) are treated as today.
     */
    fun compute(activeDays: Collection<LocalDate>, today: LocalDate): StreakInfo {
        val days = activeDays.map { if (it.isAfter(today)) today else it }.toSortedSet()
        if (days.isEmpty()) return StreakInfo(0, 0, false)
        var longest = 0
        var run = 0
        var prev: LocalDate? = null
        for (d in days) {
            run = if (prev != null && prev.plusDays(1) == d) run + 1 else 1
            if (run > longest) longest = run
            prev = d
        }
        val activeToday = days.contains(today)
        var cursor = if (activeToday) today else today.minusDays(1)
        var current = 0
        while (days.contains(cursor)) {
            current++
            cursor = cursor.minusDays(1)
        }
        return StreakInfo(current, maxOf(longest, current), activeToday)
    }
}
