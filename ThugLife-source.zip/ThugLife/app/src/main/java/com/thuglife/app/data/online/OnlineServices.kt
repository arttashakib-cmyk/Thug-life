package com.thuglife.app.data.online

/**
 * Optional online features live behind these interfaces. This release ships only the "not configured"
 * implementations: no network permission is declared, no endpoint is invented and no secret is embedded.
 * To enable them later: add the INTERNET permission, provide a backend that holds any credentials, implement
 * these interfaces and swap them in AppContainer. The learning engine never calls them.
 */
sealed interface OnlineResult<out T> {
    data class Success<T>(val value: T) : OnlineResult<T>
    data object NotConfigured : OnlineResult<Nothing>
    data object Offline : OnlineResult<Nothing>
    data class Failure(val message: String) : OnlineResult<Nothing>
}

data class ContentPackInfo(val id: String, val titleFa: String, val sizeBytes: Long)

interface ContentPackService {
    val isConfigured: Boolean
    suspend fun availablePacks(): OnlineResult<List<ContentPackInfo>>
}

interface ConversationFeedbackService {
    val isConfigured: Boolean
    suspend fun feedbackOn(userText: String, scenarioId: String): OnlineResult<String>
}

class UnconfiguredContentPackService : ContentPackService {
    override val isConfigured: Boolean = false
    override suspend fun availablePacks(): OnlineResult<List<ContentPackInfo>> = OnlineResult.NotConfigured
}

class UnconfiguredFeedbackService : ConversationFeedbackService {
    override val isConfigured: Boolean = false
    override suspend fun feedbackOn(userText: String, scenarioId: String): OnlineResult<String> = OnlineResult.NotConfigured
}

class OnlineServices(
    val packs: ContentPackService = UnconfiguredContentPackService(),
    val feedback: ConversationFeedbackService = UnconfiguredFeedbackService()
) {
    val anyConfigured: Boolean get() = packs.isConfigured || feedback.isConfigured
}
