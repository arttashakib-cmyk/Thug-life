package com.thuglife.app.domain.engine

import com.thuglife.app.domain.Skill
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * XP policy.
 *  - Only correct answers earn XP; wrong answers earn 0.
 *  - Base XP by skill: recognition 4, listening 6, context 6, recall 8, production 10.
 *  - Difficulty multiplier 1.0 + 0.1 per level above 1. Near-misses and hint use earn half.
 *  - Optional timed mode: answering within half of the limit adds 25%. Speed bonus never applies to wrong answers.
 *  - Repetition guard (enforced by the repository with unique keys): an exercise earns XP at most once per
 *    local day, a lesson / scenario completion once per day each, the daily goal bonus once per day.
 * Level = floor(sqrt(totalXp / 50)) + 1, so level n starts at 50 * (n - 1)^2 XP.
 */
object XpPolicy {
    const val LESSON_COMPLETE = 30
    const val SCENARIO_COMPLETE = 25
    const val DAILY_GOAL_BONUS = 20
    const val REVIEW_SESSION_BONUS = 10

    fun baseXp(skill: Skill): Int = when (skill) {
        Skill.RECOGNITION -> 4
        Skill.LISTENING -> 6
        Skill.CONTEXT -> 6
        Skill.RECALL -> 8
        Skill.PRODUCTION -> 10
    }

    fun exerciseXp(skill: Skill, correct: Boolean, assisted: Boolean, difficulty: Int, timed: Boolean, responseMs: Long, limitMs: Long?): Int {
        if (!correct) return 0
        var xp = baseXp(skill) * (1.0 + 0.1 * (difficulty.coerceIn(1, 5) - 1))
        if (assisted) xp *= 0.5
        if (timed && limitMs != null && limitMs > 0 && responseMs <= limitMs / 2) xp *= 1.25
        return max(1, xp.roundToInt())
    }

    fun level(totalXp: Int): Int = if (totalXp <= 0) 1 else sqrt(totalXp / 50.0).toInt() + 1
    fun xpForLevel(level: Int): Int = if (level <= 1) 0 else (level - 1) * (level - 1) * 50
    fun levelProgress(totalXp: Int): Float {
        val l = level(totalXp)
        val start = xpForLevel(l)
        val end = xpForLevel(l + 1)
        return ((totalXp - start).toFloat() / (end - start).toFloat()).coerceIn(0f, 1f)
    }
}
