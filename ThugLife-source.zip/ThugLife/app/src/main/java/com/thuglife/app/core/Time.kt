package com.thuglife.app.core

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Injectable time source so scheduling and streak logic can be tested deterministically. */
fun interface Clock {
    fun now(): Long
}

object SystemTimeClock : Clock {
    override fun now(): Long = System.currentTimeMillis()
}

const val MINUTE_MS: Long = 60_000L
const val HOUR_MS: Long = 3_600_000L
const val DAY_MS: Long = 86_400_000L

fun Long.toLocalDate(zone: ZoneId = ZoneId.systemDefault()): LocalDate =
    Instant.ofEpochMilli(this).atZone(zone).toLocalDate()

/** yyyy-MM-dd in the device's current time zone; stored with each attempt so streaks survive tz changes. */
fun Long.toDateString(zone: ZoneId = ZoneId.systemDefault()): String = toLocalDate(zone).toString()
