package com.thuglife.app.audio

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.IOException

sealed interface RecorderState {
    data object Idle : RecorderState
    data object Recording : RecorderState
    data object Recorded : RecorderState
    data class Failed(val messageFa: String) : RecorderState
}

/**
 * Records a short practice clip to app-private cache storage so learners can compare their voice with the model.
 * Recordings are never uploaded; they are deleted on demand and when the practice screen closes.
 */
class VoiceRecorder(context: Context) {
    private val appContext = context.applicationContext
    private val _state = MutableStateFlow<RecorderState>(RecorderState.Idle)
    val state: StateFlow<RecorderState> = _state.asStateFlow()
    private var recorder: MediaRecorder? = null
    val file: File get() = File(File(appContext.cacheDir, "practice").apply { mkdirs() }, "recording.m4a")

    fun start() {
        stopInternal(keepFile = false)
        try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(appContext) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setMaxDuration(15_000)
            r.setOutputFile(file.absolutePath)
            r.setOnInfoListener { _, what, _ -> if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) stop() }
            r.prepare()
            r.start()
            recorder = r
            _state.value = RecorderState.Recording
        } catch (e: IOException) {
            _state.value = RecorderState.Failed("ضبط شروع نشد؛ فضای ذخیره‌سازی یا میکروفون را بررسی کنید.")
            stopInternal(keepFile = false)
        } catch (e: IllegalStateException) {
            _state.value = RecorderState.Failed("ضبط شروع نشد؛ ممکن است برنامه‌ی دیگری از میکروفون استفاده کند.")
            stopInternal(keepFile = false)
        } catch (e: RuntimeException) {
            _state.value = RecorderState.Failed("ضبط روی این دستگاه ممکن نشد.")
            stopInternal(keepFile = false)
        }
    }

    fun stop() {
        val had = recorder != null
        stopInternal(keepFile = true)
        if (had && file.exists() && file.length() > 0L) _state.value = RecorderState.Recorded
        else if (had) _state.value = RecorderState.Failed("چیزی ضبط نشد.")
    }

    /** Deletes the clip and returns to idle. */
    fun delete() {
        stopInternal(keepFile = false)
        _state.value = RecorderState.Idle
    }

    private fun stopInternal(keepFile: Boolean) {
        recorder?.let {
            try { it.stop() } catch (e: RuntimeException) { /* stop() throws when nothing was captured */ }
            it.release()
        }
        recorder = null
        if (!keepFile) file.delete()
    }
}
