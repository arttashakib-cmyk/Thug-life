package com.thuglife.app.data.content

import android.content.Context
import androidx.room.withTransaction
import com.thuglife.app.data.local.AudioAssetEntity
import com.thuglife.app.data.local.ExerciseEntity
import com.thuglife.app.data.local.ExpressionEntity
import com.thuglife.app.data.local.LessonEntity
import com.thuglife.app.data.local.LessonExpressionEntity
import com.thuglife.app.data.local.ScenarioEntity
import com.thuglife.app.data.local.ScenarioStepEntity
import com.thuglife.app.data.local.ThugLifeDatabase
import com.thuglife.app.data.local.optStringOrNull
import com.thuglife.app.data.local.toJsonString
import com.thuglife.app.data.local.toStringListOrEmpty
import com.thuglife.app.data.prefs.PreferencesRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class ParsedContent(
    val version: Int,
    val audio: List<AudioAssetEntity>,
    val expressions: List<ExpressionEntity>,
    val lessons: List<LessonEntity>,
    val lessonExpressions: List<LessonExpressionEntity>,
    val exercises: List<ExerciseEntity>,
    val scenarios: List<ScenarioEntity>,
    val steps: List<ScenarioStepEntity>
)

object ContentParser {
    fun parse(json: String): ParsedContent {
        val root = JSONObject(json)
        val audio = root.getJSONArray("audioAssets").map { a ->
            AudioAssetEntity(a.getString("id"), a.getString("kind"), a.optStringOrNull("text"), a.optStringOrNull("resource"),
                a.optString("locale", "en-US"), a.optStringOrNull("attribution"))
        }
        val expressions = root.getJSONArray("expressions").map { e ->
            val bad = if (e.isNull("unnatural")) null else e.getJSONObject("unnatural")
            ExpressionEntity(
                e.getString("id"), e.getString("english"), e.getString("persian"), e.getString("context"), e.getString("register"),
                e.getString("topic"), e.getInt("difficulty"), e.getJSONArray("examples").toStringListOrEmpty().toJsonString(),
                e.getJSONArray("alternatives").toStringListOrEmpty().toJsonString(), e.optStringOrNull("warning"),
                e.optStringOrNull("pronunciation"), e.optStringOrNull("audio"), e.optStringOrNull("source"),
                e.getJSONArray("tags").toStringListOrEmpty().toJsonString(), e.getString("pathway"), e.optStringOrNull("situationFa"),
                bad?.getString("text"), bad?.getString("reasonFa")
            )
        }
        val lessons = root.getJSONArray("lessons").map { l ->
            val ne = l.getJSONObject("newExample")
            LessonEntity(l.getString("id"), l.getString("pathway"), l.getInt("order"), l.getString("titleFa"), l.getString("titleEn"),
                l.getString("descFa"), l.getString("introFa"), l.getInt("difficulty"), l.getInt("minutes"),
                l.getJSONArray("lyric").toStringListOrEmpty().toJsonString(), l.getString("lyricAttribution"),
                ne.getString("en"), ne.getString("fa"))
        }
        val le = root.getJSONArray("lessonExpressions").map { r ->
            LessonExpressionEntity(r.getString("lesson"), r.getString("expr"), r.getInt("pos"))
        }
        val exercises = root.getJSONArray("exercises").map { x ->
            ExerciseEntity(x.getString("id"), x.getString("type"), x.getString("skill"), x.optStringOrNull("expr"), x.optStringOrNull("lesson"),
                x.getInt("diff"), x.getString("promptFa"), x.optStringOrNull("promptEn"),
                (if (x.isNull("options")) JSONArray() else x.getJSONArray("options")).toStringListOrEmpty().toJsonString(),
                x.getJSONArray("accepted").toStringListOrEmpty().toJsonString(),
                (if (x.isNull("tokens")) JSONArray() else x.getJSONArray("tokens")).toStringListOrEmpty().toJsonString(),
                x.getString("explanationFa"), x.optStringOrNull("audio"),
                if (x.isNull("timeLimit")) null else x.getInt("timeLimit"), x.optInt("order", 0))
        }
        val scenarios = root.getJSONArray("scenarios").map { s ->
            ScenarioEntity(s.getString("id"), s.getString("titleFa"), s.getString("titleEn"), s.getString("descFa"),
                s.getInt("diff"), s.getString("topic"), s.getString("start"), s.getInt("steps"))
        }
        val steps = root.getJSONArray("scenarioSteps").map { s ->
            val opts = JSONArray()
            if (!s.isNull("options")) {
                val src = s.getJSONArray("options")
                for (i in 0 until src.length()) opts.put(src.getJSONObject(i))
            }
            ScenarioStepEntity(s.getString("id"), s.getString("scenario"), s.getInt("pos"), s.getString("kind"), s.getString("situationFa"),
                s.optStringOrNull("partner"), s.optStringOrNull("audio"), opts.toString(),
                (if (s.isNull("accepted")) JSONArray() else s.getJSONArray("accepted")).toStringListOrEmpty().toJsonString(),
                (if (s.isNull("tokens")) JSONArray() else s.getJSONArray("tokens")).toStringListOrEmpty().toJsonString(),
                s.optStringOrNull("prompt"), s.optStringOrNull("okFa"), s.optStringOrNull("badFa"), s.optStringOrNull("hint"),
                s.getString("formalFa"), s.getJSONArray("alts").toStringListOrEmpty().toJsonString(), s.optStringOrNull("avoidFa"),
                s.optStringOrNull("next"), s.optStringOrNull("expr"))
        }
        return ParsedContent(root.getInt("version"), audio, expressions, lessons, le, exercises, scenarios, steps)
    }

    private inline fun <T> JSONArray.map(f: (JSONObject) -> T): List<T> = List(length()) { f(getJSONObject(it)) }
}

/**
 * Imports the bundled curriculum into Room. Only content tables are upserted by stable id, so learner tables
 * (review states, attempts, XP, progress) are never touched. Runs when the bundled content version is newer
 * than the stored one, or when the content tables are empty.
 */
class ContentImporter(
    private val context: Context,
    private val db: ThugLifeDatabase,
    private val prefs: PreferencesRepository
) {
    suspend fun ensureImported(): Boolean = withContext(Dispatchers.IO) {
        val stored = prefs.current().contentVersion
        val empty = db.contentDao().countExpressions() == 0
        val text = context.assets.open(ASSET_PATH).bufferedReader(Charsets.UTF_8).use { it.readText() }
        val parsed = ContentParser.parse(text)
        if (!empty && stored >= parsed.version) return@withContext false
        importParsed(parsed)
        prefs.setContentVersion(parsed.version)
        true
    }

    suspend fun importParsed(parsed: ParsedContent) {
        val dao = db.contentDao()
        db.withTransaction {
            dao.upsertAudio(parsed.audio)
            dao.upsertExpressions(parsed.expressions)
            dao.upsertLessons(parsed.lessons)
            dao.upsertLessonExpressions(parsed.lessonExpressions)
            dao.upsertExercises(parsed.exercises)
            dao.upsertScenarios(parsed.scenarios)
            dao.upsertSteps(parsed.steps)
        }
    }

    companion object { const val ASSET_PATH = "content/curriculum.json" }
}
