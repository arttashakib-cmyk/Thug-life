package com.thuglife.app.ui.screens.onboarding

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.thuglife.app.core.fa
import com.thuglife.app.domain.EnglishLevel
import com.thuglife.app.domain.LearningGoal
import com.thuglife.app.domain.Pathway
import com.thuglife.app.ui.components.AppCard
import com.thuglife.app.ui.components.LocalContainer
import com.thuglife.app.ui.components.PrimaryButton
import com.thuglife.app.ui.components.ProgressLine
import com.thuglife.app.ui.components.ScreenScaffold
import com.thuglife.app.ui.components.SecondaryButton
import com.thuglife.app.work.ReminderScheduler
import kotlinx.coroutines.launch

private const val STEPS = 7

@Composable
fun OnboardingScreen(onFinished: (startDiagnostic: Boolean) -> Unit) {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var step by rememberSaveable { mutableIntStateOf(0) }
    var name by rememberSaveable { mutableStateOf("") }
    var level by rememberSaveable { mutableStateOf(EnglishLevel.BEGINNER.name) }
    var goal by rememberSaveable { mutableStateOf(LearningGoal.CONVERSATION.name) }
    var genresCsv by rememberSaveable { mutableStateOf("") }
    var minutes by rememberSaveable { mutableIntStateOf(10) }
    var target by rememberSaveable { mutableIntStateOf(60) }
    var reminders by rememberSaveable { mutableStateOf(false) }
    var online by rememberSaveable { mutableStateOf(false) }
    var saving by rememberSaveable { mutableStateOf(false) }

    val genres: Set<String> = if (genresCsv.isBlank()) emptySet() else genresCsv.split(",").toSet()
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> reminders = granted }

    fun finish(diagnostic: Boolean) {
        if (saving) return
        saving = true
        scope.launch {
            c.prefs.saveOnboarding(
                name, EnglishLevel.fromName(level), LearningGoal.fromName(goal),
                genres.mapNotNull { Pathway.fromName(it) }.toSet(), minutes, target, reminders, online
            )
            ReminderScheduler.apply(ctx, reminders, 19)
            onFinished(diagnostic)
        }
    }

    ScreenScaffold(title = "خوش آمدید") { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            ProgressLine((step + 1).toFloat() / STEPS)
            Spacer(Modifier.height(12.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (step) {
                    0 -> {
                        Text("Thug Life", style = MaterialTheme.typography.displaySmall)
                        Text("انگلیسیِ زنده را از رپ، راک، پاپ و گفتگوی خیابانی یاد بگیرید. همه‌چیز بدون ثبت‌نام و بدون اینترنت کار می‌کند و پیشرفت شما فقط روی همین دستگاه می‌ماند.", style = MaterialTheme.typography.bodyLarge)
                        OutlinedTextField(
                            value = name, onValueChange = { name = it.take(24) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                            label = { Text("نام یا لقب شما (اختیاری)") }, keyboardOptions = KeyboardOptions.Default
                        )
                    }
                    1 -> {
                        Text("سطح فعلی انگلیسی شما؟", style = MaterialTheme.typography.headlineSmall)
                        Text("یک تخمین کلی کافی است؛ بعداً با عملکرد واقعی‌تان دقیق‌تر می‌شود.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        EnglishLevel.entries.forEach { l -> Choice(l.fa, level == l.name) { level = l.name } }
                    }
                    2 -> {
                        Text("هدف اصلی شما؟", style = MaterialTheme.typography.headlineSmall)
                        LearningGoal.entries.forEach { g -> Choice(g.fa, goal == g.name) { goal = g.name } }
                    }
                    3 -> {
                        Text("کدام سبک‌ها را بیشتر دوست دارید؟", style = MaterialTheme.typography.headlineSmall)
                        Text("می‌توانید چند مورد انتخاب کنید؛ درس‌های پیشنهادی از این سبک‌ها شروع می‌شوند.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Pathway.entries.forEach { p ->
                            Choice("${p.fa} — ${p.subtitleFa}", p.name in genres) {
                                val set = genres.toMutableSet()
                                if (!set.add(p.name)) set.remove(p.name)
                                genresCsv = set.joinToString(",")
                            }
                        }
                    }
                    4 -> {
                        Text("طول جلسه و هدف روزانه", style = MaterialTheme.typography.headlineSmall)
                        Text("طول دلخواه هر جلسه", style = MaterialTheme.typography.labelLarge)
                        listOf(5, 10, 15, 20).forEach { m -> Choice("${m.fa()} دقیقه", minutes == m) { minutes = m } }
                        Text("هدف امتیاز روزانه", style = MaterialTheme.typography.labelLarge)
                        listOf(30 to "سبک", 60 to "متعادل", 100 to "جدی", 150 to "پرتلاش").forEach { (t, l) -> Choice("${t.fa()} امتیاز — $l", target == t) { target = t } }
                    }
                    5 -> {
                        Text("گزینه‌های اختیاری", style = MaterialTheme.typography.headlineSmall)
                        AppCard(Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("یادآور روزانه", style = MaterialTheme.typography.titleSmall)
                                    Text("در صورت نیاز به اجازه‌ی اعلان، همین‌جا پرسیده می‌شود.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = reminders, onCheckedChange = { on ->
                                    if (on && Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else reminders = on
                                })
                            }
                        }
                        AppCard(Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("امکانات آنلاین", style = MaterialTheme.typography.titleSmall)
                                    Text("در این نسخه هیچ سرویس آنلاینی فعال نیست؛ این گزینه فقط ترجیح شما را ذخیره می‌کند.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = online, onCheckedChange = { online = it })
                            }
                        }
                    }
                    else -> {
                        Text("ارزیابی اولیه (اختیاری)", style = MaterialTheme.typography.headlineSmall)
                        Text("۱۰ تمرین کوتاه شنیداری، تشخیص، بافت، یادآوری و چینش جمله. نتیجه فقط یک تخمین اولیه برای تنظیم سختی است و گواهی سطح نیست. می‌توانید ردش کنید و بعداً هر تنظیمی را عوض کنید.", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                if (step > 0) SecondaryButton("قبلی", { step -= 1 }, Modifier.weight(1f), enabled = !saving)
                if (step < STEPS - 1) PrimaryButton("بعدی", { step += 1 }, Modifier.weight(1f))
                else {
                    SecondaryButton("رد کردن", { finish(false) }, Modifier.weight(1f), enabled = !saving)
                    PrimaryButton("شروع ارزیابی", { finish(true) }, Modifier.weight(1f), enabled = !saving)
                }
            }
        }
    }
}

@Composable
private fun Choice(label: String, selected: Boolean, onClick: () -> Unit) {
    AppCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
            Text(if (selected) "✔" else "○", style = MaterialTheme.typography.titleMedium, color = if (selected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
