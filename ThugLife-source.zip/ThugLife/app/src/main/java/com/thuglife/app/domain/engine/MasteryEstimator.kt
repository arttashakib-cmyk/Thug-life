package com.thuglife.app.domain.engine

import com.thuglife.app.domain.LearningState
import com.thuglife.app.domain.ReviewState

enum class MasteryLevel(val fa: String) {
    VIEWED("فقط دیده‌شده"),
    LEARNING("در حال یادگیری"),
    RECALLED("با موفقیت یادآوری‌شده"),
    RETAINED("احتمالاً تثبیت‌شده (تخمین)")
}

object MasteryEstimator {
    const val EXPLANATION_FA =
        "«دیده‌شده» یعنی عبارت را فقط مشاهده کرده‌اید. «یادآوری‌شده» یعنی دست‌کم یک بار بدون کمک درست جواب داده‌اید " +
            "و برنامه‌ی مرور آن را زمان‌بندی کرده است. «احتمالاً تثبیت‌شده» یعنی دست‌کم پنج بار پیاپی و با فاصله‌ی " +
            "دست‌کم سه هفته درست یادآوری شده است. این‌ها تخمین هستند، نه گواهی روانی یا یادگیری همیشگی."

    fun estimate(state: ReviewState): MasteryLevel = when {
        state.successfulRecalls == 0 -> MasteryLevel.VIEWED
        state.learningState == LearningState.MASTERED -> MasteryLevel.RETAINED
        state.learningState == LearningState.REVIEW -> MasteryLevel.RECALLED
        else -> MasteryLevel.LEARNING
    }
}
