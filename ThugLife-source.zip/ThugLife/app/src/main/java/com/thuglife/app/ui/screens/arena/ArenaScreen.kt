package com.thuglife.app.ui.screens.arena

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.thuglife.app.core.fa
import com.thuglife.app.domain.ChallengeKind
import com.thuglife.app.ui.components.AppCard
import com.thuglife.app.ui.components.PrimaryButton
import com.thuglife.app.ui.components.ScreenScaffold
import com.thuglife.app.ui.components.Tag

@Composable
fun ArenaScreen(onStart: (ChallengeKind, Boolean) -> Unit) {
    var timed by rememberSaveable { mutableStateOf(false) }
    ScreenScaffold(title = "میدان چالش") { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("حالت زمان‌دار (اختیاری)", style = MaterialTheme.typography.titleMedium)
                                Text("برای هر سؤال شمارنده‌ی زمان می‌گذارد. پاسخ سریعِ غلط هیچ امتیازی ندارد و هرگز نشانه‌ی تسلط نیست؛ دقت و سرعت جداگانه ثبت می‌شوند.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = timed, onCheckedChange = { timed = it })
                        }
                    }
                }
            }
            items(ChallengeKind.entries.toList(), key = { it.name }) { kind ->
                AppCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Tag(if (timed) "زمان‌دار · ${kind.defaultTimedSeconds.fa()} ثانیه برای هر سؤال" else "بدون محدودیت زمان", color = MaterialTheme.colorScheme.secondary)
                        }
                        Text(kind.titleFa, style = MaterialTheme.typography.titleLarge)
                        Text(kind.rulesFa, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        PrimaryButton("شروع چالش", { onStart(kind, timed) }, Modifier.fillMaxWidth())
                    }
                }
            }
        }
    }
}
