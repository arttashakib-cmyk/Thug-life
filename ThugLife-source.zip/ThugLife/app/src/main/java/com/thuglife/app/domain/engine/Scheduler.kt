package com.thuglife.app.domain.engine

import com.thuglife.app.core.DAY_MS
import com.thuglife.app.core.MINUTE_MS
import com.thuglife.app.domain.LearningState
import com.thuglife.app.domain.ReviewRating
import com.thuglife.app.domain.ReviewState
import kotlin.math.max
import kotlin.math.min

/**
 * SM-2-style scheduler adapted for conversational expressions. Fully deterministic (no fuzz).
 *
 * Policy (documented in docs/LEARNING_ENGINE.md and covered by SchedulerTest):
 *  - Ratings: AGAIN (wrong), HARD (correct but slow/assisted/near), GOOD, EASY (only from explicit self-rating).
 *  - Ease starts at 2.5, range 1.3..3.0. AGAIN -0.20, HARD -0.15, GOOD 0, EASY +0.15.
 *  - AGAIN (lapse): repetitions reset, state RELEARNING (or LEARNING if never recalled), due in 10 minutes
 *    (5 minutes once an item has 4+ lapses). The carried interval becomes max(1 day, half the old interval).
 *  - First successes: rep 1 -> 1 day (HARD 0.5, EASY 3); rep 2 -> 3 days (HARD 2, EASY 6);
 *    later: GOOD = interval * ease, HARD = interval * 1.2, EASY = interval * ease * 1.3.
 *  - Leaving RELEARNING: carried interval (HARD x0.8 but >= 1 day, EASY x1.3).
 *  - Reviewing early (before due) never grows the interval by more than 15% (EASY) and otherwise keeps it.
 *  - A success within 20 minutes of the previous review, while the item is not yet due (same practice session),
 *    counts as a recall but does not advance the schedule, so a ten-question lesson cannot inflate intervals.
 *    A relearning item that is due (10 minutes after a lapse) is graduated normally.
 *  - MASTERED means 5+ repetitions and an interval of 21+ days. It is an estimate, never a guarantee.
 */
object Scheduler {
    const val MIN_EASE = 1.3
    const val MAX_EASE = 3.0
    const val DEFAULT_EASE = 2.5
    const val RELEARN_MINUTES = 10L
    const val LEECH_RELEARN_MINUTES = 5L
    const val LEECH_THRESHOLD = 4
    const val SESSION_WINDOW_MS = 20 * MINUTE_MS
    const val MAX_INTERVAL_DAYS = 365.0

    fun review(s: ReviewState, rating: ReviewRating, now: Long): ReviewState =
        if (rating == ReviewRating.AGAIN) lapse(s, now) else success(s, rating, now)

    fun isDue(s: ReviewState, now: Long): Boolean {
        if (s.learningState == LearningState.NEW) return false
        val next = s.nextReviewAt ?: return false
        return next <= now
    }

    private fun lapse(s: ReviewState, now: Long): ReviewState {
        val wasKnown = s.repetitions > 0 || s.learningState == LearningState.REVIEW ||
            s.learningState == LearningState.MASTERED || s.learningState == LearningState.RELEARNING
        val lapses = s.failedRecalls + 1
        val minutes = if (lapses >= LEECH_THRESHOLD) LEECH_RELEARN_MINUTES else RELEARN_MINUTES
        return s.copy(
            failedRecalls = lapses,
            firstSeenAt = if (s.firstSeenAt == 0L) now else s.firstSeenAt,
            lastReviewedAt = now,
            nextReviewAt = now + minutes * MINUTE_MS,
            easeFactor = max(MIN_EASE, s.easeFactor - 0.2),
            intervalDays = if (wasKnown) max(1.0, s.intervalDays * 0.5) else 1.0,
            repetitions = 0,
            learningState = if (wasKnown) LearningState.RELEARNING else LearningState.LEARNING,
            recentQuality = ReviewRating.AGAIN.quality
        )
    }

    private fun success(s: ReviewState, rating: ReviewRating, now: Long): ReviewState {
        val first = if (s.firstSeenAt == 0L) now else s.firstSeenAt
        val last = s.lastReviewedAt
        val notYetDue = s.nextReviewAt != null && now < s.nextReviewAt
        if (s.learningState != LearningState.NEW && last != null && now - last < SESSION_WINDOW_MS && notYetDue) {
            return s.copy(successfulRecalls = s.successfulRecalls + 1, firstSeenAt = first, recentQuality = rating.quality)
        }
        val early = s.learningState != LearningState.NEW && s.nextReviewAt != null && now < s.nextReviewAt
        val ease = min(MAX_EASE, max(MIN_EASE, s.easeFactor + when (rating) {
            ReviewRating.HARD -> -0.15
            ReviewRating.EASY -> 0.15
            else -> 0.0
        }))
        val reps = s.repetitions + 1
        val normal: Double = when {
            s.learningState == LearningState.RELEARNING -> {
                val carried = max(1.0, s.intervalDays)
                when (rating) {
                    ReviewRating.HARD -> max(1.0, carried * 0.8)
                    ReviewRating.EASY -> carried * 1.3
                    else -> carried
                }
            }
            reps == 1 -> when (rating) { ReviewRating.HARD -> 0.5; ReviewRating.EASY -> 3.0; else -> 1.0 }
            reps == 2 -> when (rating) { ReviewRating.HARD -> 2.0; ReviewRating.EASY -> 6.0; else -> 3.0 }
            else -> when (rating) {
                ReviewRating.HARD -> s.intervalDays * 1.2
                ReviewRating.EASY -> s.intervalDays * ease * 1.3
                else -> s.intervalDays * ease
            }
        }
        var interval = normal
        if (early) {
            val cap = if (rating == ReviewRating.EASY) s.intervalDays * 1.15 else s.intervalDays
            interval = min(normal, max(cap, 0.5))
        }
        interval = min(MAX_INTERVAL_DAYS, max(0.5, interval))
        val state = when {
            reps >= 5 && interval >= 21.0 -> LearningState.MASTERED
            reps >= 2 || interval >= 3.0 || s.learningState == LearningState.RELEARNING -> LearningState.REVIEW
            else -> LearningState.LEARNING
        }
        return s.copy(
            successfulRecalls = s.successfulRecalls + 1,
            firstSeenAt = first,
            lastReviewedAt = now,
            nextReviewAt = now + (interval * DAY_MS).toLong(),
            easeFactor = ease,
            intervalDays = interval,
            repetitions = reps,
            learningState = state,
            recentQuality = rating.quality
        )
    }
}
