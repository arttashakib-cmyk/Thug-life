package com.thuglife.app.data.repository

import androidx.room.withTransaction
import com.thuglife.app.core.Clock
import com.thuglife.app.core.DAY_MS
import com.thuglife.app.core.toDateString
import com.thuglife.app.core.toLocalDate
import com.thuglife.app.data.local.AchievementEntity
import com.thuglife.app.data.local.AttemptEntity
import com.thuglife.app.data.local.LessonProgressEntity
import com.thuglife.app.data.local.ScenarioProgressEntity
import com.thuglife.app.data.local.SessionEntity
import com.thuglife.app.data.local.SkillAggregate
import com.thuglife.app.data.local.SkillProfileEntity
import com.thuglife.app.data.local.ThugLifeDatabase
import com.thuglife.app.data.local.XpEventEntity
import com.thuglife.app.data.prefs.PreferencesRepository
import com.thuglife.app.domain.ExerciseType
import com.thuglife.app.domain.LearningState
import com.thuglife.app.domain.Pathway
import com.thuglife.app.domain.ReviewRating
import com.thuglife.app.domain.ReviewState
import com.thuglife.app.domain.Skill
import com.thuglife.app.domain.engine.AchievementFacts
import com.thuglife.app.domain.engine.Achievements
import com.thuglife.app.domain.engine.AdaptiveDifficulty
import com.thuglife.app.domain.engine.AttemptSample
import com.thuglife.app.domain.engine.LearnerSnapshot
import com.thuglife.app.domain.engine.RatingPolicy
import com.thuglife.app.domain.engine.Scheduler
import com.thuglife.app.domain.engine.SkillAccuracy
import com.thuglife.app.domain.engine.SkillLevelState
import com.thuglife.app.domain.engine.StreakCalculator
import com.thuglife.app.domain.engine.StreakInfo
import com.thuglife.app.domain.engine.XpPolicy
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.util.UUID

data class AttemptInput(
    val sessionId: String,
    val ordinal: Int,
    val itemId: String,
    val expressionId: String?,
    val skill: Skill,
    val type: ExerciseType,
    val correct: Boolean,
    val assisted: Boolean,
    val userAnswer: String,
    val responseMs: Long,
    val timed: Boolean,
    val difficulty: Int,
    val timeLimitMs: Long?,
    val selfRating: ReviewRating? = null,
    val updateReview: Boolean = true
)

data class AttemptOutcome(
    val duplicate: Boolean,
    val xpAwarded: Int,
    val reviewState: ReviewState?,
    val levelBefore: Int,
    val levelAfter: Int
)

data class SessionSummary(
    val sessionId: String,
    val total: Int,
    val correct: Int,
    val xp: Int,
    val activeSeconds: Long,
    val newAchievements: List<String>
)

data class SkillStat(val skill: Skill, val total: Int, val correct: Int, val avgCorrectMs: Double?, val level: Int) {
    val accuracy: Double get() = if (total == 0) 0.0 else correct.toDouble() / total
}

data class DayStat(val date: LocalDate, val total: Int, val correct: Int)

data class ProgressStats(
    val totalXp: Int,
    val level: Int,
    val levelProgress: Float,
    val streak: StreakInfo,
    val encountered: Int,
    val recalled: Int,
    val retained: Int,
    val due: Int,
    val overdue: Int,
    val skills: List<SkillStat>,
    val weekly: List<DayStat>,
    val totalSessionSeconds: Long,
    val sessionsCompleted: Int,
    val attempts: Int,
    val avgCorrectResponseMs: Double?,
    val unlockedAchievements: Set<String>
)

class ProgressRepository(
    private val db: ThugLifeDatabase,
    private val prefs: PreferencesRepository,
    private val clock: Clock
) {
    private val activity = db.activityDao()
    private val review = db.reviewDao()
    private val progress = db.progressDao()
    private val content = db.contentDao()

    // ---------------------------------------------------------------- sessions
    suspend fun startSession(mode: String, refId: String?, titleFa: String, sessionId: String = UUID.randomUUID().toString()): String {
        if (activity.getSession(sessionId) == null) {
            activity.upsertSession(SessionEntity(sessionId, mode, refId, titleFa, clock.now(), null, 0, 0, 0, 0, false))
        }
        return sessionId
    }

    suspend fun finishSession(sessionId: String): SessionSummary {
        val totals = activity.sessionTotals(sessionId)
        val s = activity.getSession(sessionId)
        val active = totals.ms / 1000
        if (s != null) {
            activity.upsertSession(s.copy(endedAt = clock.now(), durationSeconds = active, attempts = totals.total, correct = totals.correct, xpEarned = totals.xp, completed = true))
        }
        val newOnes = if (totals.total > 0) checkAchievements() else emptyList()
        return SessionSummary(sessionId, totals.total, totals.correct, totals.xp, active, newOnes)
    }

    // ---------------------------------------------------------------- attempts
    /**
     * One transaction per answer: insert the attempt (a repeated submit hits the primary key and changes nothing),
     * update the expression's review state, award XP through the deduplicated ledger, and update the skill level.
     */
    suspend fun recordAttempt(input: AttemptInput): AttemptOutcome {
        val dailyTarget = prefs.current().dailyTargetXp
        val defaultLevel = prefs.current().level.skillLevel
        return db.withTransaction {
            val now = clock.now()
            val date = now.toDateString()
            val xpBefore = activity.totalXp()
            val levelBefore = XpPolicy.level(xpBefore)
            val attemptId = "${input.sessionId}:${input.ordinal}:${input.itemId}"
            val inserted = activity.insertAttempt(
                AttemptEntity(attemptId, input.sessionId, input.itemId, input.expressionId, input.skill.name, input.type.name, input.correct,
                    input.assisted, input.userAnswer.take(300), input.responseMs, input.timed, now, date, 0)
            )
            if (inserted == -1L) return@withTransaction AttemptOutcome(true, 0, null, levelBefore, levelBefore)

            var newState: ReviewState? = null
            val exprId = input.expressionId
            if (exprId != null && input.updateReview) {
                val rating = input.selfRating ?: RatingPolicy.rate(input.correct, input.assisted, false, input.responseMs, input.type)
                val existing = review.get(exprId)?.toDomain() ?: ReviewState(expressionId = exprId, firstSeenAt = now)
                newState = Scheduler.review(existing, rating, now)
                review.upsert(newState.toEntity())
            }

            var awarded = 0
            val xp = XpPolicy.exerciseXp(input.skill, input.correct, input.assisted, input.difficulty, input.timed, input.responseMs, input.timeLimitMs)
            if (xp > 0 && activity.insertXp(XpEventEntity("ex:${input.itemId}:$date", xp, "exercise", now, date)) != -1L) {
                awarded = xp
                activity.setAttemptXp(attemptId, xp)
            }
            updateSkill(input.skill, input.correct, input.assisted, defaultLevel)
            if (activity.xpOn(date) >= dailyTarget) {
                if (activity.insertXp(XpEventEntity("goal:$date", XpPolicy.DAILY_GOAL_BONUS, "daily_goal", now, date)) != -1L) {
                    awarded += XpPolicy.DAILY_GOAL_BONUS
                }
            }
            AttemptOutcome(false, awarded, newState, levelBefore, XpPolicy.level(xpBefore + awarded))
        }
    }

    private suspend fun updateSkill(skill: Skill, correct: Boolean, assisted: Boolean, defaultLevel: Int) {
        val current = progress.getSkillProfile(skill.name)
        val state = SkillLevelState(current?.level ?: defaultLevel, (current?.samples ?: 0) + 1, current?.lastAdjustSamples ?: 0)
        val recent = activity.recentForSkill(skill.name, AdaptiveDifficulty.WINDOW).map { AttemptSample(it.isCorrect, it.assisted) }
        val adjusted = AdaptiveDifficulty.adjust(state, recent)
        progress.upsertSkillProfile(SkillProfileEntity(skill.name, adjusted.level, adjusted.samples, adjusted.lastAdjustSamples))
    }

    suspend fun skillLevels(): Map<Skill, Int> {
        val default = prefs.current().level.skillLevel
        val stored = progress.getSkillProfiles().associate { it.skill to it.level }
        return Skill.entries.associateWith { stored[it.name] ?: default }
    }

    /** Sets the starting level of each skill from the diagnostic (does not count as practice attempts). */
    suspend fun applyDiagnostic(results: Map<Skill, Pair<Int, Int>>) {
        val selfLevel = prefs.current().level.skillLevel
        db.withTransaction {
            for (skill in Skill.entries) {
                val (correct, total) = results[skill] ?: (0 to 0)
                val level = AdaptiveDifficulty.initialLevel(selfLevel, correct, total)
                val existing = progress.getSkillProfile(skill.name)
                progress.upsertSkillProfile(SkillProfileEntity(skill.name, level, existing?.samples ?: 0, existing?.samples ?: 0))
            }
        }
    }

    // ---------------------------------------------------------------- lessons and scenarios
    suspend fun markLessonStarted(lessonId: String) {
        val now = clock.now()
        val p = progress.getLessonProgress(lessonId)
        if (p == null) progress.upsertLessonProgress(LessonProgressEntity(lessonId, "IN_PROGRESS", 0, 0, null, now))
        else progress.upsertLessonProgress(p.copy(lastActiveAt = now, status = if (p.status == "COMPLETED") "COMPLETED" else "IN_PROGRESS"))
    }

    /** Returns XP awarded. Completion XP needs at least 50% on the mastery check and is paid once per lesson per day. */
    suspend fun completeLesson(lessonId: String, scorePercent: Int): Int = db.withTransaction {
        val now = clock.now()
        val date = now.toDateString()
        val p = progress.getLessonProgress(lessonId)
        progress.upsertLessonProgress(
            LessonProgressEntity(lessonId, "COMPLETED", maxOf(p?.bestScorePercent ?: 0, scorePercent), (p?.completions ?: 0) + 1, now, now)
        )
        if (scorePercent >= 50 && activity.insertXp(XpEventEntity("lesson:$lessonId:$date", XpPolicy.LESSON_COMPLETE, "lesson", now, date)) != -1L) XpPolicy.LESSON_COMPLETE else 0
    }

    suspend fun completeScenario(scenarioId: String, scorePercent: Int): Int = db.withTransaction {
        val now = clock.now()
        val date = now.toDateString()
        val p = progress.getScenarioProgress(scenarioId)
        progress.upsertScenarioProgress(ScenarioProgressEntity(scenarioId, (p?.completions ?: 0) + 1, maxOf(p?.bestScorePercent ?: 0, scorePercent), now))
        if (scorePercent >= 50 && activity.insertXp(XpEventEntity("scenario:$scenarioId:$date", XpPolicy.SCENARIO_COMPLETE, "scenario", now, date)) != -1L) XpPolicy.SCENARIO_COMPLETE else 0
    }

    // ---------------------------------------------------------------- review queues
    suspend fun dueStates(limit: Int): List<ReviewState> = review.due(clock.now(), limit).map { it.toDomain() }
    suspend fun aheadStates(limit: Int): List<ReviewState> = review.ahead(clock.now(), limit).map { it.toDomain() }
    suspend fun reviewedBefore(hoursAgo: Int, limit: Int): List<ReviewState> =
        review.reviewedBefore(clock.now() - hoursAgo * 3_600_000L, limit).map { it.toDomain() }
    /** Records that an expression was viewed (state NEW). Viewing alone never counts as recall and is never "due". */
    suspend fun markSeen(expressionId: String) {
        if (review.get(expressionId) == null) review.upsert(ReviewState(expressionId = expressionId, firstSeenAt = clock.now()).toEntity())
    }
    suspend fun reviewState(expressionId: String): ReviewState? = review.get(expressionId)?.toDomain()
    suspend fun recentMistakeExpressionIds(limit: Int): List<String> = activity.recentMistakeExpressions(limit)
    fun observeReviewStates(): Flow<List<ReviewState>> = review.observeAll().map { list -> list.map { it.toDomain() } }

    // ---------------------------------------------------------------- statistics
    fun observeStats(): Flow<ProgressStats> {
        val part1 = combine(activity.observeTotalXp(), activity.observeActiveDates(), activity.observeSkillAggregates(), review.observeAll()) { xp, dates, skills, states ->
            Part1(xp, dates, skills, states)
        }
        val part2 = combine(activity.observeDaily(clock.now().toLocalDate().minusDays(6).toString()), activity.observeTotalSessionSeconds(),
            activity.observeCompletedSessions(), activity.observeAttemptCount(), progress.observeAchievements()) { daily, secs, done, attempts, ach ->
            Part2(daily, secs, done, attempts, ach.map { it.id }.toSet())
        }
        val levels = progress.observeSkillProfiles()
        return combine(part1, part2, levels) { a, b, profiles ->
            val now = clock.now()
            val today = now.toLocalDate()
            val streak = StreakCalculator.compute(a.dates.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }, today)
            val aggBySkill = a.skills.associateBy { it.skill }
            val levelBySkill = profiles.associate { it.skill to it.level }
            val skillStats = Skill.entries.map { sk ->
                val g = aggBySkill[sk.name]
                SkillStat(sk, g?.total ?: 0, g?.correct ?: 0, g?.avgCorrectMs, levelBySkill[sk.name] ?: 1)
            }
            val dayMap = b.daily.associateBy { it.localDate }
            val weekly = (6 downTo 0).map { back ->
                val d = today.minusDays(back.toLong())
                val agg = dayMap[d.toString()]
                DayStat(d, agg?.total ?: 0, agg?.correct ?: 0)
            }
            val due = a.states.count { Scheduler.isDue(it.toDomain(), now) }
            val overdue = a.states.count { s -> s.learningState != LearningState.NEW.name && (s.nextReviewAt ?: Long.MAX_VALUE) <= now - DAY_MS }
            val totalCorrectMs = a.skills.sumOf { (it.avgCorrectMs ?: 0.0) * it.correct }
            val totalCorrect = a.skills.sumOf { it.correct }
            ProgressStats(
                totalXp = a.xp, level = XpPolicy.level(a.xp), levelProgress = XpPolicy.levelProgress(a.xp),
                streak = streak,
                encountered = a.states.size,
                recalled = a.states.count { it.successfulRecalls > 0 },
                retained = a.states.count { it.learningState == LearningState.MASTERED.name },
                due = due, overdue = overdue, skills = skillStats, weekly = weekly,
                totalSessionSeconds = b.secs, sessionsCompleted = b.done, attempts = b.attempts,
                avgCorrectResponseMs = if (totalCorrect == 0) null else totalCorrectMs / totalCorrect,
                unlockedAchievements = b.achievements
            )
        }
    }

    fun observeXpToday(): Flow<Int> = activity.observeXpOn(clock.now().toDateString())
    fun observeSessions(limit: Int): Flow<List<SessionEntity>> = activity.observeSessions(limit)

    private data class Part1(val xp: Int, val dates: List<String>, val skills: List<SkillAggregate>, val states: List<com.thuglife.app.data.local.ReviewStateEntity>)
    private data class Part2(val daily: List<com.thuglife.app.data.local.DayAggregate>, val secs: Long, val done: Int, val attempts: Int, val achievements: Set<String>)

    suspend fun streak(): StreakInfo {
        val dates = activity.activeDates().mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }
        return StreakCalculator.compute(dates, clock.now().toLocalDate())
    }

    // ---------------------------------------------------------------- recommendation input
    suspend fun snapshot(
        inProgressLesson: Pair<String, String>?, nextLesson: Pair<String, String>?, hasUnfinishedScenarios: Boolean
    ): LearnerSnapshot {
        val p = prefs.current()
        val now = clock.now()
        val skillAcc = HashMap<Skill, SkillAccuracy>()
        for (g in activity.recentSkillAggregates(100)) {
            val sk = Skill.fromName(g.skill) ?: continue
            skillAcc[sk] = SkillAccuracy(g.total, g.correct)
        }
        return LearnerSnapshot(
            dueCount = review.dueCount(now),
            overdueCount = review.overdueCount(now - DAY_MS),
            inProgressLessonId = inProgressLesson?.first, inProgressLessonTitle = inProgressLesson?.second,
            nextLessonId = nextLesson?.first, nextLessonTitle = nextLesson?.second,
            skillAccuracy = skillAcc, goal = p.goal,
            lessonsCompleted = progress.getAllLessonProgress().count { it.status == "COMPLETED" },
            scenariosCompleted = progress.getAllScenarioProgress().count { it.completions > 0 },
            hasUnfinishedScenarios = hasUnfinishedScenarios,
            xpToday = activity.xpOn(now.toDateString()), dailyTargetXp = p.dailyTargetXp
        )
    }

    suspend fun xpToday(): Int = activity.xpOn(clock.now().toDateString())

    // ---------------------------------------------------------------- achievements
    suspend fun checkAchievements(): List<String> {
        val lessons = progress.getAllLessonProgress()
        val completed = lessons.filter { it.status == "COMPLETED" }
        val pathwaysByLesson = content.getLessons().associate { it.id to it.pathway }
        val touched = completed.mapNotNull { pathwaysByLesson[it.lessonId] }.mapNotNull { Pathway.fromName(it) }.toSet().size
        val states = review.getAll()
        val streak = streak()
        val listening = activity.recentForSkill(Skill.LISTENING.name, 500).count { it.isCorrect }
        val facts = AchievementFacts(
            lessonsCompleted = completed.size,
            scenariosCompleted = progress.getAllScenarioProgress().count { it.completions > 0 },
            recalledExpressions = states.count { it.successfulRecalls > 0 },
            currentStreak = streak.current, longestStreak = streak.longest,
            totalXp = activity.totalXp(),
            perfectLesson = lessons.any { it.bestScorePercent >= 100 },
            pathwaysTouched = touched,
            sessionsCompleted = 0,
            listeningCorrect = listening
        )
        val sessionsDone = activity.recentSessionsCompletedCount()
        val earned = Achievements.unlocked(facts.copy(sessionsCompleted = sessionsDone))
        val have = progress.achievementIds().toSet()
        val fresh = earned - have
        val now = clock.now()
        for (id in fresh) progress.insertAchievement(AchievementEntity(id, now))
        return fresh.toList()
    }

    // ---------------------------------------------------------------- data management
    suspend fun resetProgress() {
        db.withTransaction {
            review.deleteAll()
            activity.deleteAttempts()
            activity.deleteXp()
            activity.deleteSessions()
            progress.deleteLessonProgress()
            progress.deleteScenarioProgress()
            progress.deleteSkillProfiles()
            progress.deleteAchievements()
        }
    }
}
