package com.thuglife.app.ui.screens.settings

import android.Manifest
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.thuglife.app.BuildConfig
import com.thuglife.app.core.fa
import com.thuglife.app.data.prefs.ThemeMode
import com.thuglife.app.data.prefs.UserPreferences
import com.thuglife.app.domain.EnglishLevel
import com.thuglife.app.domain.LearningGoal
import com.thuglife.app.ui.components.AppCard
import com.thuglife.app.ui.components.LocalContainer
import com.thuglife.app.ui.components.ScreenScaffold
import com.thuglife.app.ui.components.SecondaryButton
import com.thuglife.app.ui.components.SectionTitle
import com.thuglife.app.ui.theme.Danger
import com.thuglife.app.work.ReminderScheduler
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs by c.prefs.preferences.collectAsStateWithLifecycle(initialValue = UserPreferences())
    var confirmReset by rememberSaveable { mutableStateOf(false) }
    var message by rememberSaveable { mutableStateOf<String?>(null) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        scope.launch {
            if (granted) {
                c.prefs.setReminders(true)
                ReminderScheduler.apply(ctx, true, c.prefs.current().reminderHour)
            } else {
                c.prefs.setReminders(false)
                message = "برای یادآور روزانه باید اجازه‌ی اعلان داده شود. می‌توانید بعداً از تنظیمات دستگاه آن را فعال کنید."
            }
        }
    }

    ScreenScaffold(title = "تنظیمات", onBack = onBack) { padding ->
        Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            message?.let { AppCard(Modifier.fillMaxWidth()) { Text(it, style = MaterialTheme.typography.bodyMedium) } }

            SectionTitle("ظاهر")
            AppCard(Modifier.fillMaxWidth()) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { m ->
                        FilterChip(selected = prefs.theme == m, onClick = { scope.launch { c.prefs.setTheme(m) } }, label = { Text(m.fa) })
                    }
                }
            }

            SectionTitle("هدف و سطح یادگیری")
            AppCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("سطح انگلیسی", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        EnglishLevel.entries.forEach { l -> FilterChip(selected = prefs.level == l, onClick = { scope.launch { c.prefs.setLevel(l) } }, label = { Text(l.fa) }) }
                    }
                    Text("هدف اصلی", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LearningGoal.entries.forEach { g -> FilterChip(selected = prefs.goal == g, onClick = { scope.launch { c.prefs.setGoal(g) } }, label = { Text(g.fa) }) }
                    }
                    Text("هدف روزانه (امتیاز)", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(30, 60, 100, 150).forEach { t -> FilterChip(selected = prefs.dailyTargetXp == t, onClick = { scope.launch { c.prefs.setDailyTarget(t) } }, label = { Text(t.fa()) }) }
                    }
                }
            }

            SectionTitle("صدا")
            AppCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("سرعت پیش‌فرض پخش", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0.75f to "۰٫۷۵x", 1f to "۱x", 1.25f to "۱٫۲۵x").forEach { (v, label) ->
                            FilterChip(selected = kotlin.math.abs(prefs.playbackSpeed - v) < 0.01f, onClick = { scope.launch { c.prefs.setPlaybackSpeed(v) } }, label = { Text(label) })
                        }
                    }
                    ToggleRow("پخش خودکار صدای عبارت‌ها", prefs.autoPlayAudio) { scope.launch { c.prefs.setAutoPlay(it) } }
                    ToggleRow("افکت صوتی پاسخ درست و غلط", prefs.soundEffects) { scope.launch { c.prefs.setSoundEffects(it) } }
                    ToggleRow("لرزش (بازخورد لمسی)", prefs.haptics) { scope.launch { c.prefs.setHaptics(it) } }
                    Text("صدای انگلیسی با موتور تبدیل متن به گفتار خود دستگاه پخش می‌شود. اگر صدا شنیده نشد، در تنظیمات دستگاه زبان انگلیسی را برای «تبدیل متن به گفتار» نصب کنید.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            SectionTitle("یادآور روزانه (اختیاری)")
            AppCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ToggleRow("فعال‌سازی یادآور", prefs.remindersEnabled) { on ->
                        if (!on) {
                            scope.launch { c.prefs.setReminders(false); ReminderScheduler.apply(ctx, false, prefs.reminderHour) }
                        } else if (Build.VERSION.SDK_INT >= 33) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            scope.launch { c.prefs.setReminders(true); ReminderScheduler.apply(ctx, true, prefs.reminderHour) }
                        }
                    }
                    if (prefs.remindersEnabled) {
                        Text("ساعت یادآور", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(8, 12, 18, 20, 22).forEach { h ->
                                FilterChip(selected = prefs.reminderHour == h, onClick = { scope.launch { c.prefs.setReminderHour(h); ReminderScheduler.apply(ctx, true, h) } }, label = { Text("${h.fa()}:۰۰") })
                            }
                        }
                        Text("اگر آن روز تمرین کرده باشید، اعلانی نمی‌آید.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            SectionTitle("امکانات آنلاین (اختیاری)")
            AppCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ToggleRow("اجازه‌ی استفاده از سرویس‌های آنلاین", prefs.onlineEnabled) { scope.launch { c.prefs.setOnline(it) } }
                    Text(
                        if (c.online.anyConfigured) "سرویس آنلاین پیکربندی شده است."
                        else "در این نسخه هیچ سرویس آنلاینی (بسته‌ی محتوا یا بازخورد گفتگو) پیکربندی نشده و برنامه اصلاً مجوز اینترنت ندارد. همه‌ی آموزش‌ها بدون اینترنت کار می‌کنند. این گزینه فقط ترجیح شما را برای نسخه‌های بعدی ذخیره می‌کند.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            SectionTitle("داده‌ها")
            AppCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("همه‌ی پیشرفت شما فقط روی همین دستگاه ذخیره می‌شود. چیزی ارسال نمی‌شود و همگام‌سازی بین دستگاه‌ها وجود ندارد.", style = MaterialTheme.typography.bodyMedium)
                    SecondaryButton("حذف ضبط‌های تمرین تلفظ", {
                        val dir = File(ctx.cacheDir, "practice")
                        val n = dir.listFiles()?.count { it.delete() } ?: 0
                        message = if (n > 0) "ضبط‌های موقت حذف شد." else "ضبطی برای حذف وجود نداشت."
                    }, Modifier.fillMaxWidth())
                    SecondaryButton("بازنشانی پیشرفت", { confirmReset = true }, Modifier.fillMaxWidth())
                }
            }

            SectionTitle("حریم خصوصی")
            AppCard(Modifier.fillMaxWidth()) {
                Text(
                    "این برنامه حساب کاربری و اینترنت نمی‌خواهد. میکروفون فقط وقتی که خودتان در بخش تمرین تلفظ اجازه بدهید و دکمه را بزنید استفاده می‌شود. ضبط‌ها فقط در حافظه‌ی موقت برنامه می‌مانند، آپلود نمی‌شوند و با بستن صفحه یا با دکمه‌ی حذف پاک می‌شوند. تشخیص گفتار را سرویس تشخیص گفتار خود دستگاه انجام می‌دهد و ممکن است آن سرویس (نه این برنامه) از اینترنت استفاده کند.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            SectionTitle("درباره و منابع محتوا")
            AppCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Thug Life نسخه‌ی ${BuildConfig.VERSION_NAME}".replace("1.0.0", "۱٫۰٫۰"), style = MaterialTheme.typography.titleSmall)
                    Text("همه‌ی عبارت‌ها، توضیح‌ها، مثال‌ها، گفتگوها و بندهای ترانه‌ی این برنامه اصیل‌اند و برای همین برنامه نوشته شده‌اند. هیچ ترانه‌ی دارای حق نشر یا ضبط تجاری در برنامه نیست.", style = MaterialTheme.typography.bodyMedium)
                    Text("صدا: موتور تبدیل متن به گفتار دستگاه شما. هیچ فایل صوتی همراه برنامه نیست؛ برای افزودن صدای مجاز در آینده، ساختار پشتیبانی از فایل‌های Media3 آماده است (ر.ک. docs/AUDIO.md).", style = MaterialTheme.typography.bodyMedium)
                    Text("تشخیص گفتار فقط می‌گوید موتور چه کلمه‌هایی شنیده است؛ نمره‌ی تلفظ نیست.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("بازنشانی همه‌ی پیشرفت؟") },
            text = { Text("امتیاز، رشته‌ی روزها، برنامه‌ی مرور، تاریخچه‌ی جلسه‌ها و نشان‌ها برای همیشه پاک می‌شوند. این کار قابل بازگشت نیست. تنظیمات شما حفظ می‌شود.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    scope.launch { c.progress.resetProgress(); message = "پیشرفت بازنشانی شد." }
                }) { Text("بله، پاک کن", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
