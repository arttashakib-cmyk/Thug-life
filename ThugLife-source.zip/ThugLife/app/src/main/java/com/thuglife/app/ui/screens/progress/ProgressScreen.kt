package com.thuglife.app.ui.screens.progress

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.thuglife.app.AppContainer
import com.thuglife.app.core.durationFa
import com.thuglife.app.core.fa
import com.thuglife.app.core.faShort
import com.thuglife.app.core.percentFa
import com.thuglife.app.core.toFa
import com.thuglife.app.data.local.SessionEntity
import com.thuglife.app.data.repository.ProgressStats
import com.thuglife.app.domain.engine.Achievements
import com.thuglife.app.domain.engine.MasteryEstimator
import com.thuglife.app.ui.components.AppCard
import com.thuglife.app.ui.components.EmptyState
import com.thuglife.app.ui.components.ErrorState
import com.thuglife.app.ui.components.LoadingState
import com.thuglife.app.ui.components.ProgressLine
import com.thuglife.app.ui.components.ScreenScaffold
import com.thuglife.app.ui.components.SecondaryButton
import com.thuglife.app.ui.components.SectionTitle
import com.thuglife.app.ui.components.StatTile
import com.thuglife.app.ui.components.containerViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

sealed interface ProgressState {
    data object Loading : ProgressState
    data object Failed : ProgressState
    data class Ready(val stats: ProgressStats, val xpToday: Int) : ProgressState
}

class ProgressViewModel(c: AppContainer) : ViewModel() {
    val state: StateFlow<ProgressState> = combine(c.progress.observeStats(), c.progress.observeXpToday()) { s, x ->
        ProgressState.Ready(s, x) as ProgressState
    }.catch { emit(ProgressState.Failed) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ProgressState.Loading)
}

@Composable
fun ProgressScreen(onBack: () -> Unit, onOpenHistory: () -> Unit) {
    val vm = containerViewModel { c, _ -> ProgressViewModel(c) }
    val state by vm.state.collectAsStateWithLifecycle()
    ScreenScaffold(title = "پیشرفت من", onBack = onBack) { padding ->
        Column(Modifier.padding(padding)) {
            when (val s = state) {
                ProgressState.Loading -> LoadingState()
                ProgressState.Failed -> ErrorState("بارگذاری آمار ممکن نشد.")
                is ProgressState.Ready -> ProgressContent(s.stats, s.xpToday, onOpenHistory)
            }
        }
    }
}

@Composable
private fun ProgressContent(st: ProgressStats, xpToday: Int, onOpenHistory: () -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AppCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("سطح ${st.level.fa()}  ·  ${st.totalXp.fa()} امتیاز", style = MaterialTheme.typography.titleLarge)
                ProgressLine(st.levelProgress)
                Text("امتیاز امروز: ${xpToday.fa()}  ·  رشته‌ی فعلی: ${st.streak.current.fa()} روز  ·  بلندترین رشته: ${st.streak.longest.fa()} روز", style = MaterialTheme.typography.bodyMedium)
                Text("سطح بعدی از ${(com.thuglife.app.domain.engine.XpPolicy.xpForLevel(st.level + 1)).fa()} امتیاز شروع می‌شود (فرمول: ۵۰ × (سطح − ۱)²). روز بدون تمرین چیزی را از شما نمی‌گیرد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("عبارت دیده‌شده", st.encountered.fa(), Modifier.weight(1f))
            StatTile("با موفقیت یادآوری‌شده", st.recalled.fa(), Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("احتمالاً تثبیت‌شده (تخمین)", st.retained.fa(), Modifier.weight(1f), MaterialTheme.colorScheme.tertiary)
            StatTile("سررسید / عقب‌افتاده", "${st.due.fa()} / ${st.overdue.fa()}", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("میانگین زمان پاسخ درست", st.avgCorrectResponseMs?.let { "${(it / 1000.0).let { s -> String.format(java.util.Locale.US, "%.1f", s).toFa() }} ثانیه" } ?: "—", Modifier.weight(1f))
            StatTile("زمان کل تمرین", durationFa(st.totalSessionSeconds), Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
        }

        SectionTitle("مهارت‌ها")
        AppCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                st.skills.forEach { sk ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(sk.skill.fa, style = MaterialTheme.typography.titleSmall)
                            Text(if (sk.total == 0) "هنوز داده‌ای نیست" else "${percentFa(sk.accuracy)} دقت · ${sk.total.fa()} تلاش · سطح ${sk.level.fa()}", style = MaterialTheme.typography.bodySmall)
                        }
                        ProgressLine(if (sk.total == 0) 0f else sk.accuracy.toFloat(), color = MaterialTheme.colorScheme.primary)
                        if (sk.avgCorrectMs != null) Text("میانگین زمان پاسخ درست: ${String.format(java.util.Locale.US, "%.1f", sk.avgCorrectMs / 1000.0).toFa()} ثانیه (جدا از دقت)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                val rated = st.skills.filter { it.total >= 5 }
                if (rated.size >= 2) {
                    val best = rated.maxByOrNull { it.accuracy }!!
                    val worst = rated.minByOrNull { it.accuracy }!!
                    if (best.skill != worst.skill) Text("قوی‌ترین مهارت تا الان: ${best.skill.fa}. بیشترین جا برای رشد: ${worst.skill.fa}.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    Text("برای تحلیل نقاط قوت و ضعف دست‌کم ۵ تلاش در دو مهارت لازم است.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        SectionTitle("فعالیت ۷ روز اخیر")
        AppCard(Modifier.fillMaxWidth()) {
            val max = (st.weekly.maxOfOrNull { it.total } ?: 0).coerceAtLeast(1)
            Row(Modifier.fillMaxWidth().height(96.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                st.weekly.forEach { d ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(d.total.fa(), style = MaterialTheme.typography.labelSmall)
                        Box(Modifier.size(width = 24.dp, height = (6 + 48 * d.total.toFloat() / max).dp).clip(RoundedCornerShape(6.dp)).background(if (d.total > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant))
                        Text(d.date.dayOfWeek.faShort(), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        SectionTitle("نشان‌ها")
        AppCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Achievements.all.forEach { a ->
                    val on = a.id in st.unlockedAchievements
                    Text((if (on) "🏅 " else "▫️ ") + a.titleFa + " — " + a.descFa, style = MaterialTheme.typography.bodyMedium,
                        color = if (on) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        SectionTitle("تسلط چطور تخمین زده می‌شود؟")
        AppCard(Modifier.fillMaxWidth()) { Text(MasteryEstimator.EXPLANATION_FA, style = MaterialTheme.typography.bodyMedium) }
        SecondaryButton("تاریخچه‌ی جلسه‌ها", onOpenHistory, Modifier.fillMaxWidth())
    }
}

@Composable
fun HistoryScreen(onBack: () -> Unit) {
    val vm = containerViewModel { c, _ -> HistoryViewModel(c) }
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    ScreenScaffold(title = "تاریخچه‌ی جلسه‌ها", onBack = onBack) { padding ->
        Column(Modifier.padding(padding)) {
            val list = sessions
            when {
                list == null -> LoadingState()
                list.isEmpty() -> EmptyState("هنوز جلسه‌ای ثبت نشده است.")
                else -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list, key = { it.id }) { s -> SessionRow(s) }
                }
            }
        }
    }
}

class HistoryViewModel(c: AppContainer) : ViewModel() {
    val sessions: StateFlow<List<SessionEntity>?> = c.progress.observeSessions(100).map<List<SessionEntity>, List<SessionEntity>?> { l -> l }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
}

private val dateFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd  HH:mm")

@Composable
private fun SessionRow(s: SessionEntity) {
    AppCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(s.titleFa, style = MaterialTheme.typography.titleSmall)
            Text(Instant.ofEpochMilli(s.startedAt).atZone(ZoneId.systemDefault()).format(dateFormat).toFa() + " (میلادی)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                if (s.completed) "${s.correct.fa()} درست از ${s.attempts.fa()} · ${s.xpEarned.fa()} امتیاز · ${durationFa(s.durationSeconds)}"
                else "نیمه‌کاره (پاسخ‌های داده‌شده ذخیره شده‌اند)",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
