package com.thuglife.app.ui.screens.session

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.thuglife.app.AppContainer
import com.thuglife.app.data.repository.AttemptInput
import com.thuglife.app.data.repository.SessionSummary
import com.thuglife.app.domain.ChallengeKind
import com.thuglife.app.domain.Exercise
import com.thuglife.app.domain.InputKind
import com.thuglife.app.domain.ReviewRating
import com.thuglife.app.domain.ReviewState
import com.thuglife.app.domain.SessionMode
import com.thuglife.app.domain.Skill
import com.thuglife.app.domain.engine.AnswerValidator
import com.thuglife.app.domain.engine.ValidationResult
import com.thuglife.app.domain.engine.Verdict
import com.thuglife.app.domain.engine.XpPolicy
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class AnswerFeedback(
    val correct: Boolean,
    val near: Boolean,
    val timedOut: Boolean,
    val userAnswer: String,
    val correctAnswer: String,
    val explanationFa: String,
    val xp: Int,
    val review: ReviewState?,
    val duplicate: Boolean
)

sealed interface SessionUi {
    data object Loading : SessionUi
    data class Empty(val messageFa: String) : SessionUi
    data class Error(val messageFa: String) : SessionUi
    data class Active(
        val exercise: Exercise, val index: Int, val total: Int, val timed: Boolean,
        val timeLeftSec: Int?, val feedback: AnswerFeedback?
    ) : SessionUi
    data class Finished(
        val titleFa: String, val summary: SessionSummary, val leveledUp: Boolean, val newLevel: Int,
        val lessonScore: Int?, val bonusXp: Int, val diagnosticSkills: Map<Skill, Pair<Int, Int>>
    ) : SessionUi
}

class ExerciseSessionViewModel(private val c: AppContainer, private val handle: SavedStateHandle) : ViewModel() {
    private val mode: SessionMode = SessionMode.entries.firstOrNull { it.name == handle.get<String>("mode") } ?: SessionMode.CHALLENGE
    private val ref: String = handle.get<String>("ref") ?: "-"
    private val timedRequested: Boolean = handle.get<Boolean>("timed") ?: false

    private val _ui = MutableStateFlow<SessionUi>(SessionUi.Loading)
    val ui: StateFlow<SessionUi> = _ui.asStateFlow()

    private var sessionId: String = handle.get<String>("sid") ?: UUID.randomUUID().toString().also { handle["sid"] = it }
    private var exercises: List<Exercise> = emptyList()
    private var index: Int = handle.get<Int>("idx") ?: 0
    private var shownAt: Long = 0L
    private var locked = false
    private var timerJob: Job? = null
    private var startLevel = 1
    private var sessionTitle = ""
    private val diagnostic = HashMap<Skill, Pair<Int, Int>>()

    init { load() }

    fun retry() { _ui.value = SessionUi.Loading; load() }

    private fun load() {
        viewModelScope.launch {
            try {
                startLevel = XpPolicy.level(c.database.activityDao().totalXp())
                val seed = sessionId.hashCode().toLong()
                val (list, title) = when (mode) {
                    SessionMode.LESSON -> {
                        c.progress.markLessonStarted(ref)
                        val l = c.content.lesson(ref)
                        c.planner.lessonPractice(ref, seed) to "آزمون درس «${l?.lesson?.titleFa ?: ""}»"
                    }
                    SessionMode.CHALLENGE -> {
                        val kind = ChallengeKind.fromName(ref) ?: ChallengeKind.RAPID_MEANING
                        c.planner.challenge(kind, 10, seed) to kind.titleFa
                    }
                    SessionMode.REVIEW -> c.planner.review(false, 15) to "مرور عبارت‌های سررسید"
                    SessionMode.REVIEW_AHEAD -> c.planner.review(true, 10) to "مرور پیش‌رو"
                    SessionMode.DIAGNOSTIC -> c.planner.diagnostic() to "ارزیابی اولیه"
                    SessionMode.WEAKNESS -> {
                        val skill = Skill.fromName(ref) ?: Skill.RECALL
                        c.planner.weakness(skill, 10, seed) to "تمرین هدفمند: ${skill.fa}"
                    }
                }
                sessionTitle = title
                if (list.isEmpty()) {
                    _ui.value = SessionUi.Empty(emptyMessage())
                    return@launch
                }
                exercises = list
                c.progress.startSession(mode.name, ref, title, sessionId)
                if (index >= exercises.size) finish() else present()
            } catch (e: Exception) {
                _ui.value = SessionUi.Error("بارگذاری تمرین‌ها با خطا مواجه شد. دوباره تلاش کنید.")
            }
        }
    }

    private fun emptyMessage(): String = when (mode) {
        SessionMode.REVIEW -> "الان هیچ عبارتی موعد مرور ندارد. بعد از یاد گرفتن چند عبارت در «آزمایشگاه موسیقی»، برنامه‌ی مرور شما اینجا ساخته می‌شود."
        SessionMode.REVIEW_AHEAD -> "هنوز عبارتی برای مرور پیش‌رو ندارید. ابتدا یک درس را کامل کنید."
        SessionMode.CHALLENGE -> if (ref == ChallengeKind.DELAYED_RECALL.name) "یادآوری با تأخیر به عبارت‌هایی نیاز دارد که دست‌کم شش ساعت پیش مرور کرده‌اید. اول یک درس بخوانید و بعد برگردید."
            else "تمرینی برای این چالش پیدا نشد."
        else -> "تمرینی برای این بخش پیدا نشد."
    }

    private fun present() {
        timerJob?.cancel()
        locked = false
        val ex = exercises[index]
        shownAt = c.clock.now()
        val timed = timedRequested && mode == SessionMode.CHALLENGE
        val limit = if (timed) (ex.timeLimitSec ?: 20) else null
        _ui.value = SessionUi.Active(ex, index, exercises.size, timed, limit, null)
        if (limit != null) {
            timerJob = viewModelScope.launch {
                var left = limit
                while (left > 0) {
                    delay(1000)
                    left--
                    _ui.update { s -> if (s is SessionUi.Active && s.exercise.id == ex.id && s.feedback == null) s.copy(timeLeftSec = left) else s }
                }
                onTimeout(ex)
            }
        }
    }

    private fun onTimeout(ex: Exercise) {
        val s = _ui.value
        if (s is SessionUi.Active && s.exercise.id == ex.id && s.feedback == null) record(ex, "", ValidationResult(Verdict.WRONG), null, timedOut = true)
    }

    /** [answer] is the chosen option or typed text; [ordered] the chosen tokens for sentence reconstruction. */
    fun submit(answer: String, ordered: List<String> = emptyList()) {
        val s = _ui.value as? SessionUi.Active ?: return
        if (locked || s.feedback != null) return
        val ex = s.exercise
        val result = when (ex.type.input) {
            InputKind.CHOICE, InputKind.BINARY -> AnswerValidator.validateChoice(answer, ex.accepted)
            InputKind.TYPED -> AnswerValidator.validateTyped(answer, ex.accepted, allowContains = ex.type == com.thuglife.app.domain.ExerciseType.TYPED_PRODUCTION)
            InputKind.ORDER -> AnswerValidator.validateOrder(ordered, ex.accepted)
            InputKind.REVEAL -> return
        }
        if (result.verdict == Verdict.EMPTY) return
        record(ex, if (ex.type.input == InputKind.ORDER) ordered.joinToString(" ") else answer, result, null, false)
    }

    fun selfRate(rating: ReviewRating) {
        val s = _ui.value as? SessionUi.Active ?: return
        if (locked || s.feedback != null || s.exercise.type.input != InputKind.REVEAL) return
        record(s.exercise, rating.name, ValidationResult(if (rating == ReviewRating.AGAIN) Verdict.WRONG else if (rating == ReviewRating.HARD) Verdict.NEAR else Verdict.CORRECT), rating, false)
    }

    private fun record(ex: Exercise, answer: String, result: ValidationResult, rating: ReviewRating?, timedOut: Boolean) {
        if (locked) return
        locked = true
        timerJob?.cancel()
        val responseMs = (c.clock.now() - shownAt).coerceAtLeast(0L)
        val correct = result.isAccepted
        val near = result.verdict == Verdict.NEAR
        val ordinal = index
        viewModelScope.launch {
            val timed = timedRequested && mode == SessionMode.CHALLENGE
            val outcome = c.progress.recordAttempt(
                AttemptInput(
                    sessionId = sessionId, ordinal = ordinal, itemId = ex.id, expressionId = ex.expressionId, skill = ex.skill, type = ex.type,
                    correct = correct, assisted = near, userAnswer = answer, responseMs = responseMs, timed = timed,
                    difficulty = ex.difficulty, timeLimitMs = ex.timeLimitSec?.let { it * 1000L }, selfRating = rating,
                    updateReview = mode != SessionMode.DIAGNOSTIC
                )
            )
            if (mode == SessionMode.DIAGNOSTIC) {
                val prev = diagnostic[ex.skill] ?: (0 to 0)
                diagnostic[ex.skill] = (prev.first + if (correct) 1 else 0) to (prev.second + 1)
            }
            val prefs = c.prefs.current()
            c.feedback.result(correct, prefs.soundEffects, prefs.haptics)
            _ui.update { s ->
                if (s is SessionUi.Active && s.exercise.id == ex.id) s.copy(
                    feedback = AnswerFeedback(correct, near, timedOut, answer, ex.accepted.firstOrNull() ?: "", ex.explanationFa,
                        outcome.xpAwarded, outcome.reviewState, outcome.duplicate),
                    timeLeftSec = null
                ) else s
            }
        }
    }

    fun next() {
        val s = _ui.value as? SessionUi.Active ?: return
        if (s.feedback == null) return
        index += 1
        handle["idx"] = index
        if (index >= exercises.size) finish() else present()
    }

    private fun finish() {
        timerJob?.cancel()
        viewModelScope.launch {
            try {
                var score: Int? = null
                var bonus = 0
                if (mode == SessionMode.LESSON) {
                    val totals = c.database.activityDao().sessionTotals(sessionId)
                    score = if (totals.total == 0) 0 else (totals.correct * 100) / totals.total
                    bonus = c.progress.completeLesson(ref, score)
                }
                if (mode == SessionMode.DIAGNOSTIC) c.progress.applyDiagnostic(diagnostic)
                val summary = c.progress.finishSession(sessionId)
                val newLevel = XpPolicy.level(c.database.activityDao().totalXp())
                _ui.value = SessionUi.Finished(sessionTitle, summary, newLevel > startLevel, newLevel, score, bonus, diagnostic.toMap())
            } catch (e: Exception) {
                _ui.value = SessionUi.Error("ذخیره‌ی نتیجه با خطا مواجه شد، اما پاسخ‌های قبلی شما ذخیره شده‌اند.")
            }
        }
    }

    override fun onCleared() {
        timerJob?.cancel()
        super.onCleared()
    }
}
