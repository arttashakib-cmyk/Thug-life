package com.thuglife.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

data class SkillAggregate(val skill: String, val total: Int, val correct: Int, val avgCorrectMs: Double?, val avgAllMs: Double?)
data class SessionTotals(val total: Int, val correct: Int, val xp: Int, val ms: Long)
data class DayAggregate(val localDate: String, val total: Int, val correct: Int)

@Dao
interface ContentDao {
    @Upsert suspend fun upsertExpressions(items: List<ExpressionEntity>)
    @Upsert suspend fun upsertLessons(items: List<LessonEntity>)
    @Upsert suspend fun upsertLessonExpressions(items: List<LessonExpressionEntity>)
    @Upsert suspend fun upsertAudio(items: List<AudioAssetEntity>)
    @Upsert suspend fun upsertExercises(items: List<ExerciseEntity>)
    @Upsert suspend fun upsertScenarios(items: List<ScenarioEntity>)
    @Upsert suspend fun upsertSteps(items: List<ScenarioStepEntity>)

    @Query("SELECT COUNT(*) FROM expressions") suspend fun countExpressions(): Int
    @Query("SELECT COUNT(*) FROM exercises") suspend fun countExercises(): Int

    @Query("SELECT * FROM lessons ORDER BY pathway, orderIndex") fun observeLessons(): Flow<List<LessonEntity>>
    @Query("SELECT * FROM lessons ORDER BY pathway, orderIndex") suspend fun getLessons(): List<LessonEntity>
    @Query("SELECT * FROM lessons WHERE id = :id") suspend fun getLesson(id: String): LessonEntity?
    @Query("SELECT COUNT(*) FROM lesson_expressions WHERE lessonId = :lessonId") suspend fun countLessonExpressions(lessonId: String): Int
    @Query("SELECT lessonId, COUNT(*) AS n FROM lesson_expressions GROUP BY lessonId")
    suspend fun lessonExpressionCounts(): List<LessonCount>

    @Query("SELECT e.* FROM expressions e INNER JOIN lesson_expressions le ON le.expressionId = e.id WHERE le.lessonId = :lessonId ORDER BY le.position")
    suspend fun expressionsForLesson(lessonId: String): List<ExpressionEntity>
    @Query("SELECT * FROM expressions WHERE id = :id") suspend fun getExpression(id: String): ExpressionEntity?
    @Query("SELECT * FROM expressions WHERE id IN (:ids)") suspend fun getExpressions(ids: List<String>): List<ExpressionEntity>
    @Query("SELECT * FROM expressions ORDER BY difficulty, id") suspend fun getAllExpressions(): List<ExpressionEntity>

    @Query("SELECT * FROM exercises WHERE id = :id") suspend fun getExercise(id: String): ExerciseEntity?
    @Query("SELECT * FROM exercises WHERE id IN (:ids)") suspend fun getExercises(ids: List<String>): List<ExerciseEntity>
    @Query("SELECT * FROM exercises WHERE lessonId = :lessonId ORDER BY orderIndex, id") suspend fun exercisesForLesson(lessonId: String): List<ExerciseEntity>
    @Query("SELECT * FROM exercises WHERE expressionId = :expressionId ORDER BY orderIndex, id") suspend fun exercisesForExpression(expressionId: String): List<ExerciseEntity>
    @Query("SELECT * FROM exercises WHERE type IN (:types) ORDER BY id") suspend fun exercisesByTypes(types: List<String>): List<ExerciseEntity>
    @Query("SELECT * FROM exercises WHERE skill = :skill ORDER BY id") suspend fun exercisesBySkill(skill: String): List<ExerciseEntity>

    @Query("SELECT * FROM audio_assets WHERE id = :id") suspend fun getAudio(id: String): AudioAssetEntity?

    @Query("SELECT * FROM scenarios ORDER BY difficulty, id") fun observeScenarios(): Flow<List<ScenarioEntity>>
    @Query("SELECT * FROM scenarios ORDER BY difficulty, id") suspend fun getScenarios(): List<ScenarioEntity>
    @Query("SELECT * FROM scenarios WHERE id = :id") suspend fun getScenario(id: String): ScenarioEntity?
    @Query("SELECT * FROM scenario_steps WHERE scenarioId = :scenarioId ORDER BY position") suspend fun stepsForScenario(scenarioId: String): List<ScenarioStepEntity>
}

data class LessonCount(val lessonId: String, val n: Int)

@Dao
interface ReviewDao {
    @Query("SELECT * FROM expression_review_states WHERE expressionId = :id") suspend fun get(id: String): ReviewStateEntity?
    @Upsert suspend fun upsert(item: ReviewStateEntity)
    @Query("SELECT * FROM expression_review_states") fun observeAll(): Flow<List<ReviewStateEntity>>
    @Query("SELECT * FROM expression_review_states") suspend fun getAll(): List<ReviewStateEntity>
    @Query("SELECT * FROM expression_review_states WHERE learningState != 'NEW' AND nextReviewAt IS NOT NULL AND nextReviewAt <= :now ORDER BY nextReviewAt ASC LIMIT :limit")
    suspend fun due(now: Long, limit: Int): List<ReviewStateEntity>
    @Query("SELECT * FROM expression_review_states WHERE learningState != 'NEW' AND nextReviewAt IS NOT NULL AND nextReviewAt > :now ORDER BY nextReviewAt ASC LIMIT :limit")
    suspend fun ahead(now: Long, limit: Int): List<ReviewStateEntity>
    @Query("SELECT COUNT(*) FROM expression_review_states WHERE learningState != 'NEW' AND nextReviewAt IS NOT NULL AND nextReviewAt <= :now")
    suspend fun dueCount(now: Long): Int
    @Query("SELECT COUNT(*) FROM expression_review_states WHERE learningState != 'NEW' AND nextReviewAt IS NOT NULL AND nextReviewAt <= :cutoff")
    suspend fun overdueCount(cutoff: Long): Int
    @Query("SELECT * FROM expression_review_states WHERE lastReviewedAt IS NOT NULL AND lastReviewedAt <= :before AND successfulRecalls > 0 ORDER BY lastReviewedAt ASC LIMIT :limit")
    suspend fun reviewedBefore(before: Long, limit: Int): List<ReviewStateEntity>
    @Query("DELETE FROM expression_review_states") suspend fun deleteAll()
}

@Dao
interface ActivityDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertAttempt(item: AttemptEntity): Long
    @Query("UPDATE exercise_attempts SET xpAwarded = :xp WHERE id = :id") suspend fun setAttemptXp(id: String, xp: Int)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertXp(item: XpEventEntity): Long

    @Query("SELECT COALESCE(SUM(amount), 0) FROM xp_events") fun observeTotalXp(): Flow<Int>
    @Query("SELECT COALESCE(SUM(amount), 0) FROM xp_events") suspend fun totalXp(): Int
    @Query("SELECT COALESCE(SUM(amount), 0) FROM xp_events WHERE localDate = :date") fun observeXpOn(date: String): Flow<Int>
    @Query("SELECT COALESCE(SUM(amount), 0) FROM xp_events WHERE localDate = :date") suspend fun xpOn(date: String): Int

    @Query("SELECT DISTINCT localDate FROM exercise_attempts") fun observeActiveDates(): Flow<List<String>>
    @Query("SELECT DISTINCT localDate FROM exercise_attempts") suspend fun activeDates(): List<String>
    @Query("SELECT COUNT(*) FROM exercise_attempts") fun observeAttemptCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM exercise_attempts WHERE localDate = :date") suspend fun attemptsOn(date: String): Int

    @Query("SELECT skill, COUNT(*) AS total, SUM(isCorrect) AS correct, AVG(CASE WHEN isCorrect = 1 THEN responseTimeMs END) AS avgCorrectMs, AVG(responseTimeMs) AS avgAllMs FROM exercise_attempts GROUP BY skill")
    fun observeSkillAggregates(): Flow<List<SkillAggregate>>
    @Query("SELECT skill, COUNT(*) AS total, SUM(isCorrect) AS correct, AVG(CASE WHEN isCorrect = 1 THEN responseTimeMs END) AS avgCorrectMs, AVG(responseTimeMs) AS avgAllMs FROM (SELECT * FROM exercise_attempts ORDER BY timestamp DESC LIMIT :n) GROUP BY skill")
    suspend fun recentSkillAggregates(n: Int): List<SkillAggregate>
    @Query("SELECT localDate, COUNT(*) AS total, SUM(isCorrect) AS correct FROM exercise_attempts WHERE localDate >= :from GROUP BY localDate ORDER BY localDate")
    fun observeDaily(from: String): Flow<List<DayAggregate>>
    @Query("SELECT * FROM exercise_attempts WHERE skill = :skill ORDER BY timestamp DESC LIMIT :limit")
    suspend fun recentForSkill(skill: String, limit: Int): List<AttemptEntity>
    @Query("SELECT expressionId FROM exercise_attempts WHERE isCorrect = 0 AND expressionId IS NOT NULL GROUP BY expressionId ORDER BY MAX(timestamp) DESC LIMIT :limit")
    suspend fun recentMistakeExpressions(limit: Int): List<String>
    @Query("SELECT COUNT(DISTINCT expressionId) FROM exercise_attempts WHERE expressionId IS NOT NULL AND isCorrect = 1 AND assisted = 0 AND type != 'FLASHCARD_REVEAL'")
    fun observeCorrectExpressionCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSession(item: SessionEntity)
    @Query("SELECT * FROM learning_sessions WHERE id = :id") suspend fun getSession(id: String): SessionEntity?
    @Query("SELECT * FROM learning_sessions ORDER BY startedAt DESC LIMIT :limit") fun observeSessions(limit: Int): Flow<List<SessionEntity>>
    @Query("SELECT COALESCE(SUM(durationSeconds), 0) FROM learning_sessions") fun observeTotalSessionSeconds(): Flow<Long>
    @Query("SELECT COUNT(*) FROM learning_sessions WHERE completed = 1") fun observeCompletedSessions(): Flow<Int>
    @Query("SELECT COUNT(*) FROM learning_sessions WHERE completed = 1") suspend fun recentSessionsCompletedCount(): Int

    @Query("SELECT COUNT(*) AS total, COALESCE(SUM(isCorrect), 0) AS correct, COALESCE(SUM(xpAwarded), 0) AS xp, COALESCE(SUM(responseTimeMs), 0) AS ms FROM exercise_attempts WHERE sessionId = :id")
    suspend fun sessionTotals(id: String): SessionTotals
    @Query("SELECT COUNT(*) FROM exercise_attempts WHERE isCorrect = 1 AND type != 'FLASHCARD_REVEAL'") suspend fun correctAttemptCount(): Int
    @Query("DELETE FROM exercise_attempts") suspend fun deleteAttempts()
    @Query("DELETE FROM xp_events") suspend fun deleteXp()
    @Query("DELETE FROM learning_sessions") suspend fun deleteSessions()
}

@Dao
interface ProgressDao {
    @Query("SELECT * FROM lesson_progress") fun observeLessonProgress(): Flow<List<LessonProgressEntity>>
    @Query("SELECT * FROM lesson_progress") suspend fun getAllLessonProgress(): List<LessonProgressEntity>
    @Query("SELECT * FROM lesson_progress WHERE lessonId = :id") suspend fun getLessonProgress(id: String): LessonProgressEntity?
    @Upsert suspend fun upsertLessonProgress(item: LessonProgressEntity)

    @Query("SELECT * FROM scenario_progress") fun observeScenarioProgress(): Flow<List<ScenarioProgressEntity>>
    @Query("SELECT * FROM scenario_progress") suspend fun getAllScenarioProgress(): List<ScenarioProgressEntity>
    @Query("SELECT * FROM scenario_progress WHERE scenarioId = :id") suspend fun getScenarioProgress(id: String): ScenarioProgressEntity?
    @Upsert suspend fun upsertScenarioProgress(item: ScenarioProgressEntity)

    @Query("SELECT * FROM skill_profiles") fun observeSkillProfiles(): Flow<List<SkillProfileEntity>>
    @Query("SELECT * FROM skill_profiles") suspend fun getSkillProfiles(): List<SkillProfileEntity>
    @Query("SELECT * FROM skill_profiles WHERE skill = :skill") suspend fun getSkillProfile(skill: String): SkillProfileEntity?
    @Upsert suspend fun upsertSkillProfile(item: SkillProfileEntity)

    @Query("SELECT * FROM achievements") fun observeAchievements(): Flow<List<AchievementEntity>>
    @Query("SELECT id FROM achievements") suspend fun achievementIds(): List<String>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertAchievement(item: AchievementEntity): Long

    @Query("DELETE FROM lesson_progress") suspend fun deleteLessonProgress()
    @Query("DELETE FROM scenario_progress") suspend fun deleteScenarioProgress()
    @Query("DELETE FROM skill_profiles") suspend fun deleteSkillProfiles()
    @Query("DELETE FROM achievements") suspend fun deleteAchievements()
}
