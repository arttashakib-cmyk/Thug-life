package com.thuglife.app.ui.screens.speaking

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.thuglife.app.AppContainer
import com.thuglife.app.audio.RecorderState
import com.thuglife.app.audio.SpeechUiState
import com.thuglife.app.core.ltr
import com.thuglife.app.core.percentFa
import com.thuglife.app.domain.Expression
import com.thuglife.app.domain.engine.AnswerValidator
import com.thuglife.app.domain.engine.SpeechComparison
import com.thuglife.app.domain.engine.Verdict
import com.thuglife.app.ui.components.AppCard
import com.thuglife.app.ui.components.AudioPlayRow
import com.thuglife.app.ui.components.EnglishText
import com.thuglife.app.ui.components.ErrorState
import com.thuglife.app.ui.components.LoadingState
import com.thuglife.app.ui.components.LocalContainer
import com.thuglife.app.ui.components.PrimaryButton
import com.thuglife.app.ui.components.ScreenScaffold
import com.thuglife.app.ui.components.SecondaryButton
import com.thuglife.app.ui.components.SectionTitle
import com.thuglife.app.ui.components.containerViewModel
import com.thuglife.app.ui.theme.Danger
import com.thuglife.app.ui.theme.Success
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface SpeakingUi {
    data object Loading : SpeakingUi
    data object Failed : SpeakingUi
    data class Ready(val expression: Expression) : SpeakingUi
}

class SpeakingViewModel(private val c: AppContainer, handle: SavedStateHandle) : ViewModel() {
    private val id = handle.get<String>("id") ?: ""
    private val _ui = MutableStateFlow<SpeakingUi>(SpeakingUi.Loading)
    val ui: StateFlow<SpeakingUi> = _ui.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            val e = try { c.content.expression(id) } catch (ex: Exception) { null }
            _ui.value = if (e == null) SpeakingUi.Failed else SpeakingUi.Ready(e)
        }
    }
}

@Composable
fun SpeakingScreen(onBack: () -> Unit) {
    val vm = containerViewModel { c, h -> SpeakingViewModel(c, h) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val c = LocalContainer.current
    DisposableEffect(Unit) {
        onDispose { c.speech.destroy(); c.recorder.delete(); c.audio.stop() }
    }
    ScreenScaffold(title = "تمرین تلفظ", onBack = onBack) { padding ->
        Column(Modifier.padding(padding)) {
            when (val s = ui) {
                SpeakingUi.Loading -> LoadingState()
                SpeakingUi.Failed -> ErrorState("این عبارت پیدا نشد.", onRetry = { vm.load() })
                is SpeakingUi.Ready -> SpeakingContent(s.expression)
            }
        }
    }
}

@Composable
private fun SpeakingContent(e: Expression) {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val speechState by c.speech.state.collectAsStateWithLifecycle()
    val recState by c.recorder.state.collectAsStateWithLifecycle()
    val availability = remember { c.speech.availability() }
    var permissionMessage by rememberSaveable { mutableStateOf<String?>(null) }
    var pending by rememberSaveable { mutableStateOf("") }
    val target = e.english.replace("…", "").trim()

    fun hasMic() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    fun runPending(kind: String) {
        c.audio.stop()
        if (kind == "speech") c.speech.start() else c.recorder.start()
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { permissionMessage = null; runPending(pending) }
        else permissionMessage = "اجازه‌ی میکروفون داده نشد. می‌توانید با تایپ‌کردن تمرین کنید؛ بقیه‌ی برنامه به میکروفون نیاز ندارد."
    }
    fun requestMic(kind: String) {
        if (hasMic()) runPending(kind) else { pending = kind; launcher.launch(Manifest.permission.RECORD_AUDIO) }
    }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AppCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("۱. اول بشنوید", style = MaterialTheme.typography.titleMedium)
                EnglishText(e.english, Modifier.fillMaxWidth(), MaterialTheme.typography.headlineMedium)
                Text(e.persian, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary)
                AudioPlayRow(e.audioAssetId)
                if (!e.pronunciation.isNullOrBlank()) Text(e.pronunciation, style = MaterialTheme.typography.bodyMedium)
            }
        }
        permissionMessage?.let { Text(it, color = Danger, style = MaterialTheme.typography.bodyMedium) }

        AppCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("۲. تکرار کنید و ببینید چه شنیده شد", style = MaterialTheme.typography.titleMedium)
                Text(availability.noteFa, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                val busyRecording = recState is RecorderState.Recording
                PrimaryButton(
                    if (speechState is SpeechUiState.Listening) "در حال گوش دادن… (ضربه برای لغو)" else "شروع گفتن",
                    { if (speechState is SpeechUiState.Listening) c.speech.reset() else requestMic("speech") },
                    Modifier.fillMaxWidth(), enabled = availability.available && !busyRecording
                )
                when (val s = speechState) {
                    is SpeechUiState.Failed -> Text(s.messageFa, color = Danger, style = MaterialTheme.typography.bodyMedium)
                    is SpeechUiState.Result -> {
                        val cmp = remember(s.text, target) { SpeechComparison.compare(target, s.text) }
                        Text("موتور تشخیص این را شنید:", style = MaterialTheme.typography.labelLarge)
                        EnglishText(s.text, Modifier.fillMaxWidth(), MaterialTheme.typography.titleMedium)
                        Text("کلمه‌های درست شنیده‌شده: ${ltr(cmp.matchedWords.joinToString(" "))}", style = MaterialTheme.typography.bodyMedium, color = Success)
                        if (cmp.missingWords.isNotEmpty()) Text("کلمه‌های شنیده‌نشده: ${ltr(cmp.missingWords.joinToString(" "))}", style = MaterialTheme.typography.bodyMedium, color = Danger)
                        if (cmp.extraWords.isNotEmpty()) Text("کلمه‌های اضافه: ${ltr(cmp.extraWords.joinToString(" "))}", style = MaterialTheme.typography.bodyMedium)
                        Text("${percentFa(cmp.completion)} از کلمه‌های عبارت شنیده شد. توجه: این نمره‌ی تلفظ نیست؛ فقط مقایسه‌ی متن تشخیص‌داده‌شده با عبارت هدف است و به لهجه، میکروفون و موتور تشخیص بستگی دارد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    else -> Unit
                }
            }
        }

        AppCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("۳. صدای خودتان را ضبط و مقایسه کنید", style = MaterialTheme.typography.titleMedium)
                Text("ضبط فقط روی همین دستگاه می‌ماند، آپلود نمی‌شود و با بستن صفحه پاک می‌شود. ضبط را با صدای نمونه مقایسه کنید.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    when (recState) {
                        RecorderState.Recording -> PrimaryButton("توقف ضبط", { c.recorder.stop() }, Modifier.weight(1f))
                        else -> PrimaryButton("ضبط (حداکثر ۱۵ ثانیه)", { requestMic("record") }, Modifier.weight(1f), enabled = speechState !is SpeechUiState.Listening)
                    }
                    if (recState is RecorderState.Recorded) {
                        SecondaryButton("پخش ضبط من", { c.audio.playRecording(c.recorder.file) }, Modifier.weight(1f))
                    }
                }
                if (recState is RecorderState.Recorded) SecondaryButton("حذف ضبط", { c.audio.stop(); c.recorder.delete() }, Modifier.fillMaxWidth())
                (recState as? RecorderState.Failed)?.let { Text(it.messageFa, color = Danger, style = MaterialTheme.typography.bodyMedium) }
            }
        }

        TypingFallback(target)
    }
}

@Composable
private fun TypingFallback(target: String) {
    var text by rememberSaveable(target) { mutableStateOf("") }
    var checked by rememberSaveable(target) { mutableStateOf(false) }
    AppCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("۴. جایگزین تایپی (بدون میکروفون)", style = MaterialTheme.typography.titleMedium)
            Text("عبارت را بشنوید و از حفظ تایپ کنید. این مسیر همیشه کار می‌کند.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(
                value = text, onValueChange = { text = it.take(80); checked = false }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("عبارت انگلیسی") },
                textStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Ltr, textAlign = TextAlign.Left),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, autoCorrectEnabled = false, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { checked = text.isNotBlank() })
            )
            PrimaryButton("بررسی", { checked = true }, Modifier.fillMaxWidth(), enabled = text.isNotBlank())
            if (checked) {
                val r = AnswerValidator.validateTyped(text, listOf(target))
                when (r.verdict) {
                    Verdict.CORRECT -> Text("درست نوشتید ✔", color = Success, style = MaterialTheme.typography.titleSmall)
                    Verdict.NEAR -> Text("تقریباً درست؛ غلط املایی کوچک. شکل درست: ${ltr(target)}", style = MaterialTheme.typography.bodyMedium)
                    else -> Text("درست نبود. عبارت هدف: ${ltr(target)}", color = Danger, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
