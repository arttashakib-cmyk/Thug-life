package com.thuglife.app.audio

import android.content.Context
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.thuglife.app.domain.AudioAsset
import com.thuglife.app.domain.AudioKind
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.io.IOException
import java.util.Locale

enum class AudioStatus { IDLE, LOADING, PLAYING, ERROR, UNAVAILABLE }

data class AudioUiState(
    val activeId: String? = null,
    val status: AudioStatus = AudioStatus.IDLE,
    val messageFa: String? = null,
    val speed: Float = 1f,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    /** TTS cannot pause (only stop and replay); Media3 playback can pause and seek. */
    val canPauseAndSeek: Boolean = false
)

/**
 * Single audio subsystem. Lesson audio is spoken by the device's own text-to-speech engine (no audio files are
 * bundled in this release; see docs/AUDIO.md). Bundled files (assets/audio/*) and recordings are played with
 * Media3 ExoPlayer, which supports pause, seek and speed. Every call must be made on the main thread.
 */
class AudioController(private val context: Context) {
    private val appContext = context.applicationContext
    private val _state = MutableStateFlow(AudioUiState())
    val state: StateFlow<AudioUiState> = _state.asStateFlow()

    private val handler = Handler(Looper.getMainLooper())
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focusRequest: AudioFocusRequest? = null

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsFailureFa: String? = null
    private var pendingTts: Pair<AudioAsset, Float>? = null

    private var player: ExoPlayer? = null
    private val ticker = object : Runnable {
        override fun run() {
            val p = player ?: return
            if (_state.value.status == AudioStatus.PLAYING) {
                _state.update { it.copy(positionMs = p.currentPosition, durationMs = if (p.duration > 0) p.duration else it.durationMs) }
                handler.postDelayed(this, 250L)
            }
        }
    }

    // ------------------------------------------------------------------ public API
    fun play(asset: AudioAsset, speed: Float) {
        stop()
        when (asset.kind) {
            AudioKind.TTS -> playTts(asset, speed)
            AudioKind.BUNDLED -> playBundled(asset, speed)
        }
    }

    fun playRecording(file: File, speed: Float = 1f) {
        stop()
        if (!file.exists() || file.length() == 0L) {
            _state.value = AudioUiState(activeId = "recording", status = AudioStatus.UNAVAILABLE, messageFa = "ضبطی برای پخش وجود ندارد.")
            return
        }
        startExo("recording", Uri.fromFile(file), speed)
    }

    /** Pause/resume for Media3 playback; for TTS a "pause" is a stop (the engine cannot resume mid-phrase). */
    fun togglePause() {
        val p = player
        if (p != null && _state.value.canPauseAndSeek) {
            if (p.isPlaying) {
                p.pause()
                _state.update { it.copy(status = AudioStatus.IDLE) }
            } else {
                p.play()
                _state.update { it.copy(status = AudioStatus.PLAYING) }
                handler.post(ticker)
            }
        } else {
            stop()
        }
    }

    fun seekTo(ms: Long) {
        if (_state.value.canPauseAndSeek) {
            player?.seekTo(ms.coerceAtLeast(0L))
            _state.update { it.copy(positionMs = ms) }
        }
    }

    fun setSpeed(speed: Float) {
        _state.update { it.copy(speed = speed) }
        player?.playbackParameters = PlaybackParameters(speed)
    }

    fun stop() {
        handler.removeCallbacks(ticker)
        pendingTts = null
        tts?.stop()
        player?.let { it.stop(); it.clearMediaItems() }
        abandonFocus()
        _state.value = AudioUiState(speed = _state.value.speed)
    }

    /** Releases the engines. Call when the UI is gone (Activity.onDestroy); they are recreated lazily. */
    fun release() {
        stop()
        player?.release(); player = null
        tts?.shutdown(); tts = null; ttsReady = false
    }

    // ------------------------------------------------------------------ TTS
    private fun playTts(asset: AudioAsset, speed: Float) {
        val text = asset.text
        if (text.isNullOrBlank()) {
            _state.value = AudioUiState(asset.id, AudioStatus.UNAVAILABLE, "متنی برای پخش این صوت وجود ندارد.", speed)
            return
        }
        ttsFailureFa?.let {
            _state.value = AudioUiState(asset.id, AudioStatus.UNAVAILABLE, it, speed)
            return
        }
        if (ttsReady) { speakNow(asset, speed); return }
        _state.value = AudioUiState(asset.id, AudioStatus.LOADING, null, speed)
        pendingTts = asset to speed
        if (tts == null) {
            tts = TextToSpeech(appContext) { status -> handler.post { onTtsInit(status) } }
        }
    }

    private fun onTtsInit(status: Int) {
        val engine = tts
        if (status != TextToSpeech.SUCCESS || engine == null) {
            ttsFailureFa = "موتور تبدیل متن به گفتار روی این دستگاه در دسترس نیست. می‌توانید متن عبارت‌ها را بخوانید و تمرین‌های غیرشنیداری را انجام دهید."
            failPending()
            return
        }
        val r = engine.setLanguage(Locale.US)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            ttsFailureFa = "صدای انگلیسی روی دستگاه نصب نیست. از تنظیمات دستگاه، بخش «تبدیل متن به گفتار»، زبان انگلیسی را نصب کنید."
            failPending()
            return
        }
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { handler.post { finishIf(utteranceId, AudioStatus.IDLE, null) } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { handler.post { finishIf(utteranceId, AudioStatus.ERROR, "پخش صدا با خطا مواجه شد.") } }
            override fun onError(utteranceId: String?, errorCode: Int) { handler.post { finishIf(utteranceId, AudioStatus.ERROR, "پخش صدا با خطا مواجه شد.") } }
        })
        ttsReady = true
        pendingTts?.let { (a, s) -> pendingTts = null; speakNow(a, s) }
    }

    private fun failPending() {
        val p = pendingTts
        pendingTts = null
        if (p != null) _state.value = AudioUiState(p.first.id, AudioStatus.UNAVAILABLE, ttsFailureFa, p.second)
    }

    private fun speakNow(asset: AudioAsset, speed: Float) {
        val engine = tts ?: return
        requestFocus()
        engine.setSpeechRate(speed)
        val result = engine.speak(asset.text, TextToSpeech.QUEUE_FLUSH, null, asset.id)
        _state.value = if (result == TextToSpeech.SUCCESS) AudioUiState(asset.id, AudioStatus.PLAYING, null, speed)
        else AudioUiState(asset.id, AudioStatus.ERROR, "پخش صدا شروع نشد.", speed)
    }

    private fun finishIf(utteranceId: String?, status: AudioStatus, message: String?) {
        if (_state.value.activeId == utteranceId) {
            abandonFocus()
            _state.value = AudioUiState(utteranceId, status, message, _state.value.speed)
        }
    }

    // ------------------------------------------------------------------ Media3
    private fun playBundled(asset: AudioAsset, speed: Float) {
        val name = asset.resourceName
        val exists = name != null && try { appContext.assets.open("audio/$name").close(); true } catch (e: IOException) { false }
        if (!exists) {
            _state.value = AudioUiState(asset.id, AudioStatus.UNAVAILABLE, "فایل صوتی این بخش پیدا نشد.", speed)
            return
        }
        startExo(asset.id, Uri.parse("asset:///audio/$name"), speed)
    }

    private fun startExo(id: String, uri: Uri, speed: Float) {
        _state.value = AudioUiState(id, AudioStatus.LOADING, null, speed, canPauseAndSeek = true)
        val p = player ?: ExoPlayer.Builder(appContext).build().also { exo ->
            exo.setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_SPEECH).build(), true
            )
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    when (playbackState) {
                        Player.STATE_READY -> if (_state.value.status == AudioStatus.LOADING) {
                            _state.update { it.copy(status = AudioStatus.PLAYING, durationMs = exo.duration.coerceAtLeast(0L)) }
                            handler.post(ticker)
                        }
                        Player.STATE_ENDED -> _state.update { it.copy(status = AudioStatus.IDLE, positionMs = 0L) }
                        else -> Unit
                    }
                }
                override fun onPlayerError(error: PlaybackException) {
                    _state.update { it.copy(status = AudioStatus.ERROR, messageFa = "این فایل صوتی پخش نشد (قالب یا فایل نامعتبر).") }
                }
            })
            player = exo
        }
        p.setMediaItem(MediaItem.fromUri(uri))
        p.playbackParameters = PlaybackParameters(speed)
        p.prepare()
        p.play()
    }

    // ------------------------------------------------------------------ audio focus
    private fun requestFocus() {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(
                android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setOnAudioFocusChangeListener { change ->
                if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) handler.post { stop() }
            }.build()
        focusRequest = req
        audioManager.requestAudioFocus(req)
    }

    private fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        focusRequest = null
    }
}
