package com.thuglife.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.lifecycle.createSavedStateHandle
import com.thuglife.app.AppContainer
import com.thuglife.app.core.fa
import com.thuglife.app.data.prefs.UserPreferences
import com.thuglife.app.audio.AudioStatus
import com.thuglife.app.domain.AudioAsset
import com.thuglife.app.ui.theme.PathwayLook

val LocalContainer = staticCompositionLocalOf<AppContainer> { error("AppContainer not provided") }

/** Bottom navigation bar for the five main tabs; empty on every other screen. */
val LocalBottomBar = staticCompositionLocalOf<@Composable () -> Unit> { {} }

@Composable
inline fun <reified VM : ViewModel> containerViewModel(key: String? = null, crossinline create: (AppContainer, SavedStateHandle) -> VM): VM {
    val container = LocalContainer.current
    return viewModel(key = key, factory = viewModelFactory { initializer { create(container, createSavedStateHandle()) } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenScaffold(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable () -> Unit = {},
    bottomBar: (@Composable () -> Unit)? = null,
    content: @Composable (PaddingValues) -> Unit
) {
    val tabBar = LocalBottomBar.current
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1) },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                        }
                    }
                },
                actions = { actions() },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = bottomBar ?: tabBar,
        content = content
    )
}

@Composable
fun AppCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    val border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    if (onClick != null) {
        Card(onClick = onClick, modifier = modifier, colors = colors, border = border, shape = MaterialTheme.shapes.medium) {
            Box(Modifier.padding(16.dp)) { content() }
        }
    } else {
        Card(modifier = modifier, colors = colors, border = border, shape = MaterialTheme.shapes.medium) {
            Box(Modifier.padding(16.dp)) { content() }
        }
    }
}

@Composable
fun GradientCard(look: PathwayLook, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val shape = MaterialTheme.shapes.large
    val base = modifier.clip(shape).background(look.brush)
    Box(if (onClick != null) base.clickable(role = Role.Button, onClick = onClick) else base) {
        Box(Modifier.padding(18.dp)) { content() }
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = 52.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
    ) { Text(text, style = MaterialTheme.typography.titleSmall) }
}

@Composable
fun SecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    OutlinedButton(onClick = onClick, enabled = enabled, modifier = modifier.heightIn(min = 52.dp), shape = RoundedCornerShape(16.dp)) {
        Text(text, style = MaterialTheme.typography.titleSmall)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = modifier.semantics { contentDescription = text })
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier, accent: Color = MaterialTheme.colorScheme.primary) {
    AppCard(modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, color = accent)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun ProgressLine(progress: Float, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.secondary) {
    LinearProgressIndicator(
        progress = { progress.coerceIn(0f, 1f) },
        modifier = modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
        color = color, trackColor = MaterialTheme.colorScheme.surfaceVariant
    )
}

@Composable
fun LoadingState(modifier: Modifier = Modifier, message: String = "در حال بارگذاری…") {
    Column(modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        CircularProgressIndicator()
        Spacer(Modifier.height(12.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun EmptyState(message: String, modifier: Modifier = Modifier, actionText: String? = null, onAction: (() -> Unit)? = null) {
    Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🎧", style = MaterialTheme.typography.displaySmall)
        Spacer(Modifier.height(8.dp))
        Text(message, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (actionText != null && onAction != null) {
            Spacer(Modifier.height(16.dp))
            PrimaryButton(actionText, onAction)
        }
    }
}

@Composable
fun ErrorState(message: String, onRetry: (() -> Unit)? = null, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("⚠️", style = MaterialTheme.typography.displaySmall)
        Spacer(Modifier.height(8.dp))
        Text(message, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.error)
        if (onRetry != null) {
            Spacer(Modifier.height(16.dp))
            SecondaryButton("تلاش دوباره", onRetry)
        }
    }
}

/** English text always renders left-to-right, even inside the RTL Persian layout. */
@Composable
fun EnglishText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = MaterialTheme.typography.titleLarge,
    color: Color = Color.Unspecified,
    textAlign: TextAlign = TextAlign.Start
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Text(text, modifier = modifier, style = style, color = color, textAlign = textAlign)
    }
}

@Composable
fun Tag(text: String, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary) {
    Box(
        modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 3.dp)
    ) { Text(text, style = MaterialTheme.typography.labelMedium, color = color) }
}

@Composable
fun starsFa(difficulty: Int): String = "★".repeat(difficulty.coerceIn(1, 5)) + "☆".repeat(5 - difficulty.coerceIn(1, 5)) + " (${difficulty.fa()})"

/**
 * Audio control for one asset. Shows loading, error and unavailable states (never a dead button), replay,
 * speed chips and, for Media3 playback only, a seek bar. TTS cannot pause or seek; the row says so by omission.
 */
@Composable
fun AudioPlayRow(audioId: String?, modifier: Modifier = Modifier, autoPlay: Boolean = false) {
    if (audioId == null) return
    val c = LocalContainer.current
    val prefs by c.prefs.preferences.collectAsStateWithLifecycle(initialValue = UserPreferences())
    val loaded by produceState<Pair<Boolean, AudioAsset?>>(initialValue = false to null, audioId) { value = true to c.content.audio(audioId) }
    val state by c.audio.state.collectAsStateWithLifecycle()
    var speedChoice by rememberSaveable { mutableFloatStateOf(0f) }
    val speed = if (speedChoice > 0f) speedChoice else prefs.playbackSpeed
    val asset = loaded.second
    val mine = asset != null && state.activeId == asset.id

    LaunchedEffect(asset?.id, autoPlay, prefs.autoPlayAudio) {
        if (autoPlay && prefs.autoPlayAudio && asset != null) c.audio.play(asset, speed)
    }
    DisposableEffect(audioId) { onDispose { if (c.audio.state.value.activeId == audioId) c.audio.stop() } }

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val playing = mine && state.status == AudioStatus.PLAYING
            val loading = mine && state.status == AudioStatus.LOADING
            Box(
                Modifier.size(52.dp).clip(CircleShape)
                    .background(if (asset == null) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                IconButton(
                    onClick = {
                        if (asset != null) {
                            if (mine && state.canPauseAndSeek) c.audio.togglePause()
                            else if (playing || loading) c.audio.stop()
                            else c.audio.play(asset, speed)
                        }
                    },
                    enabled = asset != null,
                    modifier = Modifier.size(52.dp).semantics { contentDescription = if (playing) "توقف صدا" else "پخش صدا" }
                ) {
                    if (loading) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = Color.White)
                    else Icon(if (playing) AppIcons.Stop else AppIcons.Play, null, tint = Color.White)
                }
            }
            Column(Modifier.weight(1f)) {
                val label = when {
                    !loaded.first -> "در حال آماده‌سازی صدا…"
                    asset == null -> "صدا برای این مورد موجود نیست."
                    mine && state.status == AudioStatus.UNAVAILABLE -> state.messageFa ?: "صدا در دسترس نیست."
                    mine && state.status == AudioStatus.ERROR -> state.messageFa ?: "خطا در پخش صدا."
                    mine && state.status == AudioStatus.PLAYING -> "در حال پخش…"
                    mine && state.status == AudioStatus.LOADING -> "در حال بارگذاری…"
                    else -> "پخش (صدای دستگاه)"
                }
                Text(label, style = MaterialTheme.typography.bodyMedium,
                    color = if (mine && (state.status == AudioStatus.ERROR || state.status == AudioStatus.UNAVAILABLE)) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(0.75f, 1f, 1.25f).forEach { s ->
                FilterChip(
                    selected = kotlin.math.abs(speed - s) < 0.01f,
                    onClick = { speedChoice = s; if (mine) c.audio.setSpeed(s) },
                    label = { Text("${s}x".replace("0.75x", "۰٫۷۵x").replace("1.25x", "۱٫۲۵x").replace("1.0x", "۱x")) }
                )
            }
        }
        if (mine && state.canPauseAndSeek && state.durationMs > 0) {
            Slider(
                value = state.positionMs.toFloat(), onValueChange = { c.audio.seekTo(it.toLong()) },
                valueRange = 0f..state.durationMs.toFloat()
            )
        }
    }
}


/** Small speaker button that reads any English text aloud with the device voice (no stored audio file). */
@Composable
fun SpeakTextButton(text: String, modifier: Modifier = Modifier) {
    val c = LocalContainer.current
    val prefs by c.prefs.preferences.collectAsStateWithLifecycle(initialValue = UserPreferences())
    val state by c.audio.state.collectAsStateWithLifecycle()
    val id = "dyn_" + text.hashCode()
    val mine = state.activeId == id
    val active = mine && (state.status == AudioStatus.PLAYING || state.status == AudioStatus.LOADING)
    DisposableEffect(id) { onDispose { if (c.audio.state.value.activeId == id) c.audio.stop() } }
    Column(modifier) {
        IconButton(
            onClick = {
                if (active) c.audio.stop()
                else c.audio.play(AudioAsset(id, com.thuglife.app.domain.AudioKind.TTS, text, null, "en-US", null), prefs.playbackSpeed)
            },
            modifier = Modifier.size(48.dp).semantics { contentDescription = "پخش این جمله" }
        ) { Icon(if (active) AppIcons.Stop else AppIcons.Volume, null, tint = MaterialTheme.colorScheme.primary) }
        if (mine && (state.status == AudioStatus.UNAVAILABLE || state.status == AudioStatus.ERROR)) {
            Text(state.messageFa ?: "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
    }
}
