package com.thuglife.app.data.local

import org.json.JSONArray
import org.json.JSONObject

/** Tiny org.json helpers (org.json ships with Android, so no extra dependency or reflection is needed). */
fun List<String>.toJsonString(): String {
    val a = JSONArray()
    for (s in this) a.put(s)
    return a.toString()
}

fun String.toStringList(): List<String> {
    if (isBlank()) return emptyList()
    return try {
        val a = JSONArray(this)
        List(a.length()) { a.getString(it) }
    } catch (e: org.json.JSONException) {
        emptyList()
    }
}

fun JSONObject.optStringOrNull(key: String): String? =
    if (isNull(key) || !has(key)) null else getString(key)

fun JSONArray?.toStringListOrEmpty(): List<String> =
    if (this == null) emptyList() else List(length()) { getString(it) }
