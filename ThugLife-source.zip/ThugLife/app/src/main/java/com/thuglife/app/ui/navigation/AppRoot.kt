package com.thuglife.app.ui.navigation

import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.thuglife.app.AppContainer
import com.thuglife.app.data.prefs.UserPreferences
import com.thuglife.app.domain.SessionMode
import com.thuglife.app.ui.components.ErrorState
import com.thuglife.app.ui.components.LoadingState
import com.thuglife.app.ui.components.AppIcons
import com.thuglife.app.ui.components.LocalBottomBar
import com.thuglife.app.ui.components.LocalContainer
import com.thuglife.app.ui.components.containerViewModel
import com.thuglife.app.ui.screens.arena.ArenaScreen
import com.thuglife.app.ui.screens.home.HomeScreen
import com.thuglife.app.ui.screens.memory.MemoryScreen
import com.thuglife.app.ui.screens.music.LessonScreen
import com.thuglife.app.ui.screens.music.MusicLabScreen
import com.thuglife.app.ui.screens.onboarding.OnboardingScreen
import com.thuglife.app.ui.screens.progress.HistoryScreen
import com.thuglife.app.ui.screens.progress.ProgressScreen
import com.thuglife.app.ui.screens.session.ExerciseSessionScreen
import com.thuglife.app.ui.screens.settings.SettingsScreen
import com.thuglife.app.ui.screens.speaking.SpeakingScreen
import com.thuglife.app.ui.screens.street.ScenarioScreen
import com.thuglife.app.ui.screens.street.StreetScreen
import com.thuglife.app.ui.theme.ThugLifeTheme
import com.thuglife.app.work.ReminderScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface StartState {
    data object Loading : StartState
    data class Failed(val message: String) : StartState
    data class Ready(val onboardingDone: Boolean) : StartState
}

/** Seeds the database (never overwrites learner tables) and decides whether to show onboarding. */
class AppStartViewModel(private val c: AppContainer, private val appContext: android.content.Context) : ViewModel() {
    private val _state = MutableStateFlow<StartState>(StartState.Loading)
    val state: StateFlow<StartState> = _state.asStateFlow()

    init { start() }

    fun start() {
        _state.value = StartState.Loading
        viewModelScope.launch {
            try {
                c.importer.ensureImported()
                val p = c.prefs.current()
                ReminderScheduler.apply(appContext, p.remindersEnabled, p.reminderHour)
                _state.value = StartState.Ready(p.onboardingCompleted)
            } catch (e: Exception) {
                _state.value = StartState.Failed("آماده‌سازی محتوای آموزشی با خطا مواجه شد. اگر فضای ذخیره‌سازی دستگاه پر است، مقداری آزاد کنید و دوباره تلاش کنید.")
            }
        }
    }
}

@Composable
fun AppRoot(container: AppContainer, appContext: android.content.Context) {
    CompositionLocalProvider(LocalContainer provides container) {
        val prefs by container.prefs.preferences.collectAsStateWithLifecycle(initialValue = UserPreferences())
        val activity = androidx.compose.ui.platform.LocalContext.current as? androidx.activity.ComponentActivity
        val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
        val dark = when (prefs.theme) {
            com.thuglife.app.data.prefs.ThemeMode.DARK -> true
            com.thuglife.app.data.prefs.ThemeMode.LIGHT -> false
            com.thuglife.app.data.prefs.ThemeMode.SYSTEM -> systemDark
        }
        androidx.compose.runtime.SideEffect {
            val style = if (dark) androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
            else androidx.activity.SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
            activity?.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
        }
        ThugLifeTheme(prefs.theme) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                val vm = containerViewModel { c, _ -> AppStartViewModel(c, appContext) }
                val state by vm.state.collectAsStateWithLifecycle()
                when (val s = state) {
                    StartState.Loading -> LoadingState(message = "در حال آماده‌سازی محتوای آموزشی…")
                    is StartState.Failed -> ErrorState(s.message, onRetry = { vm.start() })
                    is StartState.Ready -> ThugLifeNav(if (s.onboardingDone) Routes.HOME else Routes.ONBOARDING)
                }
            }
        }
    }
}

private data class BottomItem(val route: String, val label: String, val icon: ImageVector)

private val bottomItems = listOf(
    BottomItem(Routes.HOME, "خانه", AppIcons.Home),
    BottomItem(Routes.MUSIC, "موسیقی", AppIcons.Music),
    BottomItem(Routes.STREET, "خیابان", AppIcons.Chat),
    BottomItem(Routes.ARENA, "چالش", AppIcons.Trophy),
    BottomItem(Routes.MEMORY, "حافظه", AppIcons.Cards)
)

@Composable
private fun AppBottomBar(nav: NavHostController, current: String?) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        bottomItems.forEach { item ->
            NavigationBarItem(
                selected = current == item.route,
                onClick = {
                    if (current != item.route) nav.navigate(item.route) {
                        popUpTo(Routes.HOME) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label, style = MaterialTheme.typography.labelSmall) }
            )
        }
    }
}

private fun NavBackStackEntry.arg(name: String): String = arguments?.getString(name) ?: ""

@Composable
fun ThugLifeNav(startRoute: String) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route
    val showBar = current in Routes.bottomBarRoutes

    val bar: @Composable () -> Unit = if (showBar) {{ AppBottomBar(nav, current) }} else {{ }}
    CompositionLocalProvider(LocalBottomBar provides bar) {
        Box(Modifier.fillMaxSize()) {
            NavHost(nav, startDestination = startRoute) {
                composable(Routes.ONBOARDING) {
                    OnboardingScreen(onFinished = { diagnostic ->
                        nav.navigate(if (diagnostic) Routes.session(SessionMode.DIAGNOSTIC) else Routes.HOME) {
                            popUpTo(Routes.ONBOARDING) { inclusive = true }
                        }
                    })
                }
                composable(Routes.HOME) {
                    HomeScreen(
                        onNavigate = { route -> nav.navigate(route) },
                        onSettings = { nav.navigate(Routes.SETTINGS) },
                        onProgress = { nav.navigate(Routes.PROGRESS) }
                    )
                }
                composable(Routes.MUSIC) { MusicLabScreen(onOpenLesson = { nav.navigate(Routes.lesson(it)) }) }
                composable(Routes.STREET) { StreetScreen(onOpenScenario = { nav.navigate(Routes.scenario(it)) }) }
                composable(Routes.ARENA) {
                    ArenaScreen(onStart = { kind, timed -> nav.navigate(Routes.session(SessionMode.CHALLENGE, kind.name, timed)) })
                }
                composable(Routes.MEMORY) {
                    MemoryScreen(onStartReview = { ahead -> nav.navigate(Routes.session(if (ahead) SessionMode.REVIEW_AHEAD else SessionMode.REVIEW)) },
                        onOpenMusic = { nav.navigate(Routes.MUSIC) })
                }
                composable(Routes.PROGRESS) { ProgressScreen(onBack = { nav.popBackStack() }, onOpenHistory = { nav.navigate(Routes.HISTORY) }) }
                composable(Routes.HISTORY) { HistoryScreen(onBack = { nav.popBackStack() }) }
                composable(Routes.SETTINGS) { SettingsScreen(onBack = { nav.popBackStack() }) }
                composable(Routes.LESSON, arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                    LessonScreen(
                        onBack = { nav.popBackStack() },
                        onStartPractice = { nav.navigate(Routes.session(SessionMode.LESSON, e.arg("id"))) },
                        onSpeak = { nav.navigate(Routes.speak(it)) }
                    )
                }
                composable(Routes.SCENARIO, arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                    ScenarioScreen(onExit = { nav.popBackStack() })
                }
                composable(Routes.SPEAK, arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                    SpeakingScreen(onBack = { nav.popBackStack() })
                }
                composable(
                    Routes.SESSION,
                    arguments = listOf(
                        navArgument("mode") { type = NavType.StringType },
                        navArgument("ref") { type = NavType.StringType },
                        navArgument("timed") { type = NavType.BoolType; defaultValue = false }
                    )
                ) { e ->
                    val mode = e.arg("mode")
                    val diagnostic = mode == SessionMode.DIAGNOSTIC.name
                    ExerciseSessionScreen(
                        onExit = {
                            if (diagnostic) nav.navigate(Routes.HOME) { popUpTo(0) } else nav.popBackStack()
                        },
                        onFinishedPrimary = {
                            if (diagnostic) nav.navigate(Routes.HOME) { popUpTo(0) } else nav.popBackStack()
                        },
                        finishedPrimaryLabel = if (diagnostic) "شروع یادگیری" else "بازگشت"
                    )
                }
            }
        }
    }
}
