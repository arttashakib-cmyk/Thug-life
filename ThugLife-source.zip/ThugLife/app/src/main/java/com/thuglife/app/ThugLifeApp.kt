package com.thuglife.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.StrictMode

class ThugLifeApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            // Development-only checks: surface accidental main-thread disk/network work in logcat.
            StrictMode.setThreadPolicy(StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build())
            StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().detectLeakedClosableObjects().detectLeakedSqlLiteObjects().penaltyLog().build())
        }
        container = AppContainer(this)
        val channel = NotificationChannel(REMINDER_CHANNEL, "یادآور تمرین روزانه", NotificationManager.IMPORTANCE_DEFAULT)
        channel.description = "یادآوری اختیاری برای تمرین روزانه"
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    companion object { const val REMINDER_CHANNEL = "daily_reminder" }
}
