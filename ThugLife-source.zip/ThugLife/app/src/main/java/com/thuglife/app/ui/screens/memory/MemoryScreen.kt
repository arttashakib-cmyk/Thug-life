package com.thuglife.app.ui.screens.memory

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.thuglife.app.AppContainer
import com.thuglife.app.core.fa
import com.thuglife.app.domain.Expression
import com.thuglife.app.domain.ReviewState
import com.thuglife.app.domain.engine.MasteryEstimator
import com.thuglife.app.domain.engine.MasteryLevel
import com.thuglife.app.domain.engine.Scheduler
import com.thuglife.app.ui.components.AppCard
import com.thuglife.app.ui.components.EmptyState
import com.thuglife.app.ui.components.EnglishText
import com.thuglife.app.ui.components.ErrorState
import com.thuglife.app.ui.components.LoadingState
import com.thuglife.app.ui.components.PrimaryButton
import com.thuglife.app.ui.components.ScreenScaffold
import com.thuglife.app.ui.components.SecondaryButton
import com.thuglife.app.ui.components.SectionTitle
import com.thuglife.app.ui.components.StatTile
import com.thuglife.app.ui.components.Tag
import com.thuglife.app.ui.components.containerViewModel
import com.thuglife.app.ui.screens.session.describeNextReview
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class UrgentItem(val expression: Expression, val state: ReviewState, val due: Boolean)

data class MemoryUi(
    val total: Int,
    val due: Int,
    val overdue: Int,
    val ahead: Int,
    val buckets: Map<MasteryLevel, Int>,
    val urgent: List<UrgentItem>
)

sealed interface MemoryState {
    data object Loading : MemoryState
    data object Failed : MemoryState
    data class Ready(val ui: MemoryUi) : MemoryState
}

class MemoryViewModel(private val c: AppContainer) : ViewModel() {
    val state: StateFlow<MemoryState> = c.progress.observeReviewStates().map { states ->
        val now = c.clock.now()
        val active = states.filter { it.learningState != com.thuglife.app.domain.LearningState.NEW }
        val due = active.filter { Scheduler.isDue(it, now) }
        val ahead = active.size - due.size
        val overdue = due.count { (it.nextReviewAt ?: now) <= now - 86_400_000L }
        val buckets = states.groupingBy { MasteryEstimator.estimate(it) }.eachCount()
        val sorted = active.sortedBy { it.nextReviewAt ?: Long.MAX_VALUE }.take(8)
        val exprs = c.content.expressions(sorted.map { it.expressionId }).associateBy { it.id }
        val urgent = sorted.mapNotNull { s -> exprs[s.expressionId]?.let { UrgentItem(it, s, Scheduler.isDue(s, now)) } }
        MemoryState.Ready(MemoryUi(states.size, due.size, overdue, ahead, buckets, urgent)) as MemoryState
    }.catch { emit(MemoryState.Failed) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MemoryState.Loading)
}

@Composable
fun MemoryScreen(onStartReview: (Boolean) -> Unit, onOpenMusic: () -> Unit) {
    val vm = containerViewModel { c, _ -> MemoryViewModel(c) }
    val state by vm.state.collectAsStateWithLifecycle()
    ScreenScaffold(title = "کارت‌های حافظه") { padding ->
        Column(Modifier.padding(padding)) {
            when (val s = state) {
                MemoryState.Loading -> LoadingState()
                MemoryState.Failed -> ErrorState("بارگذاری برنامه‌ی مرور ممکن نشد.")
                is MemoryState.Ready -> if (s.ui.total == 0) {
                    EmptyState("هنوز عبارتی ندیده‌اید. با یک درس در «آزمایشگاه موسیقی» شروع کنید تا برنامه‌ی مرور فاصله‌دار شما ساخته شود.", actionText = "رفتن به آزمایشگاه موسیقی", onAction = onOpenMusic)
                } else Content(s.ui, onStartReview)
            }
        }
    }
}

@Composable
private fun Content(ui: MemoryUi, onStartReview: (Boolean) -> Unit) {
    val c = com.thuglife.app.ui.components.LocalContainer.current
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("سررسید مرور", ui.due.fa(), Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
            StatTile("عقب‌افتاده (بیش از یک روز)", ui.overdue.fa(), Modifier.weight(1f))
        }
        PrimaryButton(if (ui.due > 0) "شروع مرور (${ui.due.fa()} عبارت)" else "الان چیزی برای مرور نیست", { onStartReview(false) }, Modifier.fillMaxWidth(), enabled = ui.due > 0)
        SecondaryButton("مرور پیش‌رو (${ui.ahead.fa()} عبارت زمان‌بندی‌شده)", { onStartReview(true) }, Modifier.fillMaxWidth(), enabled = ui.ahead > 0)
        Text("در مرور پیش‌رو، عبارت‌هایی را که هنوز موعدشان نرسیده می‌بینید؛ فاصله‌ی بعدی‌شان به‌خاطر زودهنگام بودن فقط کمی زیاد می‌شود.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        SectionTitle("وضعیت عبارت‌ها")
        AppCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                MasteryLevel.entries.forEach { m -> Text("${m.fa}: ${(ui.buckets[m] ?: 0).fa()}", style = MaterialTheme.typography.bodyLarge) }
                Text(MasteryEstimator.EXPLANATION_FA, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        SectionTitle("نزدیک‌ترین مرورها")
        ui.urgent.forEach { u ->
            AppCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Tag(MasteryEstimator.estimate(u.state).fa)
                        if (u.due) Tag("سررسید", color = MaterialTheme.colorScheme.secondary)
                    }
                    EnglishText(u.expression.english, Modifier.fillMaxWidth(), MaterialTheme.typography.titleMedium)
                    Text(u.expression.persian, style = MaterialTheme.typography.bodyMedium)
                    Text("درست: ${u.state.successfulRecalls.fa()} · غلط: ${u.state.failedRecalls.fa()}" + (describeNextReview(u.state, c.clock.now())?.let { " · $it" } ?: ""), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        SectionTitle("زمان‌بندی چطور کار می‌کند؟")
        AppCard(Modifier.fillMaxWidth()) {
            Text(
                "برنامه‌ی مرور شبیه SM-2 است: جواب غلط عبارت را بعد از ۱۰ دقیقه برمی‌گرداند و فاصله‌ی قبلی را نصف می‌کند؛ «سخت» فاصله را کم‌تر رشد می‌دهد؛ «خوب» حدود ضرب‌شدن در ضریب راحتی؛ «آسان» بیشتر. جواب درست در همان جلسه (کمتر از ۲۰ دقیقه) فقط ثبت می‌شود و فاصله را زیاد نمی‌کند. سرعت پاسخ هرگز بیشتر از «خوب» امتیاز نمی‌دهد.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
