package com.thuglife.app.ui.screens.street

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.thuglife.app.AppContainer
import com.thuglife.app.core.fa
import com.thuglife.app.core.percentFa
import com.thuglife.app.domain.ScenarioWithStatus
import com.thuglife.app.ui.components.AppCard
import com.thuglife.app.ui.components.EmptyState
import com.thuglife.app.ui.components.ErrorState
import com.thuglife.app.ui.components.LoadingState
import com.thuglife.app.ui.components.ScreenScaffold
import com.thuglife.app.ui.components.Tag
import com.thuglife.app.ui.components.containerViewModel
import com.thuglife.app.ui.components.starsFa
import com.thuglife.app.ui.theme.StreetLook
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

sealed interface StreetState {
    data object Loading : StreetState
    data object Failed : StreetState
    data class Ready(val items: List<ScenarioWithStatus>) : StreetState
}

class StreetViewModel(c: AppContainer) : ViewModel() {
    val state: StateFlow<StreetState> = c.content.scenariosWithStatus().map { StreetState.Ready(it) as StreetState }
        .catch { emit(StreetState.Failed) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StreetState.Loading)
}

@Composable
fun StreetScreen(onOpenScenario: (String) -> Unit) {
    val vm = containerViewModel { c, _ -> StreetViewModel(c) }
    val state by vm.state.collectAsStateWithLifecycle()
    ScreenScaffold(title = "حالت خیابان") { padding ->
        Column(Modifier.padding(padding)) {
            when (val s = state) {
                StreetState.Loading -> LoadingState()
                StreetState.Failed -> ErrorState("بارگذاری سناریوها ممکن نشد.")
                is StreetState.Ready -> if (s.items.isEmpty()) EmptyState("سناریویی موجود نیست.") else LazyColumn(
                    contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text("گفتگوهای واقعی با انتخاب پاسخ، تایپ و چینش جمله. بعد از هر پاسخ می‌بینید چرا جواب طبیعی بود یا نبود.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    items(s.items, key = { it.scenario.id }) { sc ->
                        AppCard(Modifier.fillMaxWidth(), onClick = { onOpenScenario(sc.scenario.id) }) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Tag("${StreetLook.emoji} ${starsFa(sc.scenario.difficulty)}", color = StreetLook.start)
                                    if (sc.completions > 0) Tag("${sc.completions.fa()} بار · بهترین ${percentFa(sc.bestScorePercent / 100.0)}", color = MaterialTheme.colorScheme.tertiary)
                                }
                                Text(sc.scenario.titleFa, style = MaterialTheme.typography.titleLarge)
                                Text(sc.scenario.titleEn, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(sc.scenario.descriptionFa, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}
