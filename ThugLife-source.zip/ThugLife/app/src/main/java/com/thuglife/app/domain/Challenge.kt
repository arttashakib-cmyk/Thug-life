package com.thuglife.app.domain

enum class SessionMode { LESSON, CHALLENGE, REVIEW, REVIEW_AHEAD, DIAGNOSTIC, WEAKNESS }

/** Challenge Arena definitions. Time limits are optional and never apply to lessons or reviews. */
enum class ChallengeKind(
    val titleFa: String,
    val rulesFa: String,
    val types: List<ExerciseType>,
    val defaultTimedSeconds: Int
) {
    RAPID_MEANING("تشخیص سریع معنا", "عبارت انگلیسی را ببینید و معنای درست را انتخاب کنید. ده سؤال.", listOf(ExerciseType.MEANING_RECOGNITION), 12),
    LISTEN_IDENTIFY("بشنو و شناسایی کن", "عبارت را می‌شنوید و باید همان را در گزینه‌ها پیدا کنید. هر چند بار که بخواهید می‌توانید دوباره بشنوید.", listOf(ExerciseType.LISTEN_IDENTIFY), 15),
    MISSING_PHRASE("عبارت گمشده", "جای خالی ترانه یا معنای فارسی را با عبارت انگلیسی درست کامل کنید.", listOf(ExerciseType.MISSING_PHRASE, ExerciseType.RECALL_TYPED), 25),
    WORD_ORDER("سرعت‌چینش کلمات", "کلمه‌های بههم‌ریخته را به ترتیب درست بچینید.", listOf(ExerciseType.SENTENCE_RECONSTRUCTION), 30),
    SLANG_DECODER("رمزگشای اسلنگ", "در جمله‌ی داده‌شده، منظور واقعی اسلنگ را پیدا کنید.", listOf(ExerciseType.SLANG_DECODER), 15),
    NATURAL_OR_UNNATURAL("طبیعی یا غیرطبیعی؟", "تصمیم بگیرید جمله‌ی انگلیسی طبیعی است یا نه.", listOf(ExerciseType.NATURAL_OR_UNNATURAL), 10),
    CONTEXT_MATCH("تطبیق بافت", "برای هر موقعیت، مناسب‌ترین عبارت را انتخاب کنید.", listOf(ExerciseType.CONTEXT_MATCH), 20),
    COMEBACK("پاسخ در مکالمه", "یک جمله از طرف مقابل می‌شنوید؛ بهترین جواب را انتخاب کنید.", listOf(ExerciseType.CONVERSATION_COMEBACK), 20),
    AUDIO_MEMORY("حافظه‌ی شنیداری", "جمله را بشنوید و همان‌طور که شنیدید تایپ کنید.", listOf(ExerciseType.AUDIO_MEMORY), 40),
    DELAYED_RECALL("یادآوری با تأخیر", "فقط عبارت‌هایی که دست‌کم شش ساعت پیش مرور کرده‌اید؛ معنی را ببینید و انگلیسی را بنویسید.", listOf(ExerciseType.RECALL_TYPED), 25);

    companion object { fun fromName(n: String?): ChallengeKind? = entries.firstOrNull { it.name == n } }
}
