package com.thuglife.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.thuglife.app.ui.navigation.AppRoot

class MainActivity : ComponentActivity() {
    private val container: AppContainer get() = (application as ThugLifeApp).container

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppRoot(container, applicationContext) }
    }

    override fun onStop() {
        // Never keep speaking or listening in the background.
        container.audio.stop()
        container.speech.cancel()
        super.onStop()
    }

    override fun onDestroy() {
        if (isFinishing) {
            container.audio.release()
            container.speech.destroy()
            container.recorder.delete()
        }
        super.onDestroy()
    }
}
