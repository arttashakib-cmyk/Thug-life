package com.thuglife.app.data.repository

import com.thuglife.app.data.local.AudioAssetEntity
import com.thuglife.app.data.local.ExerciseEntity
import com.thuglife.app.data.local.ExpressionEntity
import com.thuglife.app.data.local.LessonEntity
import com.thuglife.app.data.local.ReviewStateEntity
import com.thuglife.app.data.local.ScenarioEntity
import com.thuglife.app.data.local.ScenarioStepEntity
import com.thuglife.app.data.local.toStringList
import com.thuglife.app.domain.AudioAsset
import com.thuglife.app.domain.AudioKind
import com.thuglife.app.domain.Exercise
import com.thuglife.app.domain.ExerciseType
import com.thuglife.app.domain.Expression
import com.thuglife.app.domain.Lesson
import com.thuglife.app.domain.LearningState
import com.thuglife.app.domain.OptionQuality
import com.thuglife.app.domain.Pathway
import com.thuglife.app.domain.Register
import com.thuglife.app.domain.ReviewState
import com.thuglife.app.domain.Scenario
import com.thuglife.app.domain.ScenarioOption
import com.thuglife.app.domain.ScenarioStep
import com.thuglife.app.domain.ScenarioStepKind
import org.json.JSONArray
import org.json.JSONException

fun ExpressionEntity.toDomain() = Expression(
    id, english, persian, context, Register.fromName(register), topic, difficulty, examplesJson.toStringList(),
    alternativesJson.toStringList(), warning, pronunciation, audioAssetId, source, tagsJson.toStringList(),
    Pathway.fromName(pathway) ?: Pathway.EVERYDAY, situationFa
)

fun LessonEntity.toDomain() = Lesson(
    id, Pathway.fromName(pathway) ?: Pathway.EVERYDAY, orderIndex, titleFa, titleEn, descriptionFa, introFa, difficulty, minutes,
    lyricJson.toStringList(), lyricAttribution, newExampleEn, newExampleFa
)

/** Returns null for an unknown exercise type so a bad content row can never crash a session. */
fun ExerciseEntity.toDomain(): Exercise? {
    val t = ExerciseType.fromName(type) ?: return null
    return Exercise(id, t, expressionId, lessonId, difficulty, promptFa, promptEn, optionsJson.toStringList(), acceptedJson.toStringList(),
        tokensJson.toStringList(), explanationFa, audioAssetId, timeLimitSec, orderIndex)
}

fun AudioAssetEntity.toDomain() = AudioAsset(id, if (kind == "BUNDLED") AudioKind.BUNDLED else AudioKind.TTS, text, resourceName, locale, attribution)

fun ScenarioEntity.toDomain() = Scenario(id, titleFa, titleEn, descriptionFa, difficulty, topic, startStepId, stepCount)

fun ScenarioStepEntity.toDomain(): ScenarioStep {
    val opts = mutableListOf<ScenarioOption>()
    try {
        val arr = JSONArray(optionsJson)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val q = OptionQuality.entries.firstOrNull { it.name == o.optString("q") } ?: OptionQuality.BAD
            opts.add(ScenarioOption(o.getString("t"), q, o.getString("fb"), if (o.isNull("next")) null else o.getString("next")))
        }
    } catch (e: JSONException) {
        // malformed option list: the step simply has no options and is skipped by the player
    }
    return ScenarioStep(
        id, scenarioId, position, ScenarioStepKind.entries.firstOrNull { it.name == kind } ?: ScenarioStepKind.CHOICE,
        situationFa, partnerLine, audioAssetId, opts, acceptedJson.toStringList(), tokensJson.toStringList(), prompt, okFa, badFa,
        hintFa, formalityFa, alternativesJson.toStringList(), avoidFa, nextStepId, expressionId
    )
}

fun ReviewStateEntity.toDomain() = ReviewState(
    expressionId, successfulRecalls, failedRecalls, firstSeenAt, lastReviewedAt, nextReviewAt, easeFactor, intervalDays, repetitions,
    LearningState.fromName(learningState), recentQuality, contextTags
)

fun ReviewState.toEntity() = ReviewStateEntity(
    expressionId, successfulRecalls, failedRecalls, firstSeenAt, lastReviewedAt, nextReviewAt, easeFactor, intervalDays, repetitions,
    learningState.name, recentQuality, contextTags
)
