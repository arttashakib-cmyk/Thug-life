package com.thuglife.app.ui.screens.music

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.thuglife.app.AppContainer
import com.thuglife.app.core.fa
import com.thuglife.app.core.ltr
import com.thuglife.app.domain.Expression
import com.thuglife.app.domain.LessonDetail
import com.thuglife.app.ui.components.AppCard
import com.thuglife.app.ui.components.AudioPlayRow
import com.thuglife.app.ui.components.EnglishText
import com.thuglife.app.ui.components.ErrorState
import com.thuglife.app.ui.components.LoadingState
import com.thuglife.app.ui.components.PrimaryButton
import com.thuglife.app.ui.components.ProgressLine
import com.thuglife.app.ui.components.ScreenScaffold
import com.thuglife.app.ui.components.SecondaryButton
import com.thuglife.app.ui.components.SectionTitle
import com.thuglife.app.ui.components.SpeakTextButton
import com.thuglife.app.ui.components.Tag
import com.thuglife.app.ui.components.containerViewModel
import com.thuglife.app.ui.components.starsFa
import com.thuglife.app.ui.theme.Danger
import com.thuglife.app.ui.theme.look
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface LessonUi {
    data object Loading : LessonUi
    data object Failed : LessonUi
    data class Ready(val detail: LessonDetail, val page: Int) : LessonUi {
        val pageCount: Int get() = detail.expressions.size + 2
    }
}

/** Pages: 0 = context + original lyric fragment, 1..n = one expression each, n+1 = new example and start of the mastery check. */
class LessonViewModel(private val c: AppContainer, private val handle: SavedStateHandle) : ViewModel() {
    private val lessonId: String = handle.get<String>("id") ?: ""
    private val _ui = MutableStateFlow<LessonUi>(LessonUi.Loading)
    val ui: StateFlow<LessonUi> = _ui.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            try {
                val d = c.content.lesson(lessonId)
                if (d == null) { _ui.value = LessonUi.Failed; return@launch }
                c.progress.markLessonStarted(lessonId)
                val page = (handle.get<Int>("page") ?: 0).coerceIn(0, d.expressions.size + 1)
                _ui.value = LessonUi.Ready(d, page)
                markSeen(d, page)
            } catch (e: Exception) {
                _ui.value = LessonUi.Failed
            }
        }
    }

    fun go(delta: Int) {
        val s = _ui.value as? LessonUi.Ready ?: return
        val page = (s.page + delta).coerceIn(0, s.pageCount - 1)
        handle["page"] = page
        _ui.value = s.copy(page = page)
        viewModelScope.launch { markSeen(s.detail, page) }
    }

    private suspend fun markSeen(d: LessonDetail, page: Int) {
        if (page in 1..d.expressions.size) c.progress.markSeen(d.expressions[page - 1].id)
    }
}

@Composable
fun LessonScreen(onBack: () -> Unit, onStartPractice: () -> Unit, onSpeak: (String) -> Unit) {
    val vm = containerViewModel { c, h -> LessonViewModel(c, h) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    ScreenScaffold(title = (ui as? LessonUi.Ready)?.detail?.lesson?.titleFa ?: "درس", onBack = onBack) { padding ->
        Column(Modifier.padding(padding)) {
            when (val s = ui) {
                LessonUi.Loading -> LoadingState()
                LessonUi.Failed -> ErrorState("این درس بارگذاری نشد.", onRetry = { vm.load() })
                is LessonUi.Ready -> {
                    ProgressLine((s.page + 1).toFloat() / s.pageCount, Modifier.padding(horizontal = 16.dp))
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("مرحله ${(s.page + 1).fa()} از ${s.pageCount.fa()}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        when {
                            s.page == 0 -> IntroPage(s.detail)
                            s.page <= s.detail.expressions.size -> ExpressionPage(s.detail.expressions[s.page - 1], onSpeak)
                            else -> WrapUpPage(s.detail, onStartPractice)
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (s.page > 0) SecondaryButton("قبلی", { vm.go(-1) }, Modifier.weight(1f))
                        if (s.page < s.pageCount - 1) PrimaryButton("بعدی", { vm.go(1) }, Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun IntroPage(d: LessonDetail) {
    val look = d.lesson.pathway.look()
    Text("${look.emoji} ${d.lesson.pathway.fa}", style = MaterialTheme.typography.labelLarge, color = look.start)
    Text(d.lesson.titleFa, style = MaterialTheme.typography.headlineSmall)
    EnglishText(d.lesson.titleEn, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    AppCard(Modifier.fillMaxWidth()) { Text(d.lesson.introFa, style = MaterialTheme.typography.bodyLarge) }
    SectionTitle("بند ترانه‌ی اصیل برای این درس")
    AppCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            d.lesson.lyric.forEach { line ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    EnglishText(line, Modifier.weight(1f), MaterialTheme.typography.titleMedium)
                    SpeakTextButton(line)
                }
            }
            Text(d.lesson.lyricAttribution, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    Text("عبارت‌های این درس: " + d.expressions.joinToString("، ") { ltr(it.english) }, style = MaterialTheme.typography.bodyMedium)
}

@Composable
private fun ExpressionPage(e: Expression, onSpeak: (String) -> Unit) {
    val look = e.pathway.look()
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Tag(e.register.fa, color = look.start)
        Tag(starsFa(e.difficulty), color = MaterialTheme.colorScheme.secondary)
    }
    AppCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            EnglishText(e.english, Modifier.fillMaxWidth(), MaterialTheme.typography.headlineMedium)
            Text(e.persian, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.secondary)
            AudioPlayRow(e.audioAssetId, autoPlay = true)
        }
    }
    SectionTitle("معنی و کاربرد")
    AppCard(Modifier.fillMaxWidth()) { Text(e.context, style = MaterialTheme.typography.bodyLarge) }
    if (e.warning != null) {
        AppCard(Modifier.fillMaxWidth()) {
            Column {
                Text("کجا مراقب باشید", style = MaterialTheme.typography.titleSmall, color = Danger)
                Text(e.warning, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
    SectionTitle("مثال‌های طبیعی")
    AppCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            e.examples.forEach { ex ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    EnglishText(ex, Modifier.weight(1f), MaterialTheme.typography.bodyLarge)
                    SpeakTextButton(ex)
                }
            }
        }
    }
    if (e.alternatives.isNotEmpty()) {
        SectionTitle("جایگزین‌های رایج")
        AppCard(Modifier.fillMaxWidth()) {
            Column {
                e.alternatives.forEach { EnglishText(it, Modifier.fillMaxWidth(), MaterialTheme.typography.bodyLarge) }
            }
        }
    }
    if (!e.pronunciation.isNullOrBlank()) {
        SectionTitle("راهنمای تلفظ")
        AppCard(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(e.pronunciation, style = MaterialTheme.typography.bodyMedium)
                SecondaryButton("تمرین تلفظ این عبارت", { onSpeak(e.id) }, Modifier.fillMaxWidth())
            }
        }
    } else {
        SecondaryButton("تمرین تلفظ این عبارت", { onSpeak(e.id) }, Modifier.fillMaxWidth())
    }
}

@Composable
private fun WrapUpPage(d: LessonDetail, onStartPractice: () -> Unit) {
    Text("یک مثال تازه", style = MaterialTheme.typography.headlineSmall)
    AppCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                EnglishText(d.lesson.newExampleEn, Modifier.weight(1f), MaterialTheme.typography.titleMedium)
                SpeakTextButton(d.lesson.newExampleEn)
            }
            Text(d.lesson.newExampleFa, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    AppCard(Modifier.fillMaxWidth()) {
        Text("حالا آزمون کوتاه درس: چند تمرین شنیداری، تکمیل بند ترانه، یادآوری و تولید جمله. نتیجه‌ی شما ثبت می‌شود و عبارت‌های درس برای مرور فاصله‌دار زمان‌بندی می‌شوند. بدون محدودیت زمانی است.", style = MaterialTheme.typography.bodyMedium)
    }
    Spacer(Modifier.height(4.dp))
    PrimaryButton("شروع آزمون درس", onStartPractice, Modifier.fillMaxWidth())
}
