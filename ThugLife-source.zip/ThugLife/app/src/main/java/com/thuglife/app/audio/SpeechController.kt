package com.thuglife.app.audio

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface SpeechUiState {
    data object Idle : SpeechUiState
    data object Listening : SpeechUiState
    data class Result(val text: String, val alternatives: List<String>) : SpeechUiState
    data class Failed(val messageFa: String) : SpeechUiState
}

data class SpeechAvailability(val available: Boolean, val onDeviceAvailable: Boolean, val noteFa: String)

/**
 * Wraps android.speech.SpeechRecognizer (English). Recognition is NOT pronunciation assessment: it only tells us
 * which words the engine heard. Availability and offline support are checked at runtime. Main thread only.
 */
class SpeechController(context: Context) {
    private val appContext = context.applicationContext
    private val _state = MutableStateFlow<SpeechUiState>(SpeechUiState.Idle)
    val state: StateFlow<SpeechUiState> = _state.asStateFlow()
    private var recognizer: SpeechRecognizer? = null

    fun availability(): SpeechAvailability {
        val available = SpeechRecognizer.isRecognitionAvailable(appContext)
        val onDevice = Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(appContext)
        val note = when {
            !available -> "این دستگاه سرویس تشخیص گفتار ندارد. از تمرین تایپی استفاده کنید."
            onDevice -> "تشخیص گفتار روی دستگاه در دسترس است؛ بسته‌ی زبان انگلیسی هم باید نصب باشد."
            else -> "ممکن است تشخیص گفتار برای کار کردن به اینترنت نیاز داشته باشد؛ به این دستگاه و زبان‌های نصب‌شده بستگی دارد."
        }
        return SpeechAvailability(available, onDevice, note)
    }

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            _state.value = SpeechUiState.Failed("تشخیص گفتار روی این دستگاه در دسترس نیست. از تمرین تایپی استفاده کنید.")
            return
        }
        cancel()
        val r = SpeechRecognizer.createSpeechRecognizer(appContext)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { _state.value = SpeechUiState.Listening }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { _state.value = SpeechUiState.Failed(messageFor(error)) }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                _state.value = if (list.isEmpty()) SpeechUiState.Failed("چیزی تشخیص داده نشد. دوباره امتحان کنید.")
                else SpeechUiState.Result(list.first(), list.drop(1))
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        _state.value = SpeechUiState.Listening
        r.startListening(intent)
    }

    fun cancel() {
        recognizer?.let { it.cancel(); it.destroy() }
        recognizer = null
        if (_state.value is SpeechUiState.Listening) _state.value = SpeechUiState.Idle
    }

    fun reset() { cancel(); _state.value = SpeechUiState.Idle }

    fun destroy() { cancel(); _state.value = SpeechUiState.Idle }

    private fun messageFor(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
            "تشخیص گفتار روی این دستگاه به اینترنت یا بسته‌ی آفلاین زبان انگلیسی نیاز دارد. می‌توانید به‌جای آن تایپ کنید."
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "صدایی تشخیص داده نشد. نزدیک‌تر به میکروفون و واضح‌تر بگویید."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "اجازه‌ی میکروفون داده نشده است."
        SpeechRecognizer.ERROR_AUDIO -> "مشکلی در ضبط صدا پیش آمد."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "سرویس تشخیص گفتار مشغول است؛ چند لحظه بعد دوباره امتحان کنید."
        12, 13 -> "زبان انگلیسی برای تشخیص گفتار روی این دستگاه پشتیبانی یا نصب نشده است. می‌توانید به‌جای آن تایپ کنید."
        else -> "تشخیص گفتار با خطا مواجه شد (کد ${code})."
    }
}
