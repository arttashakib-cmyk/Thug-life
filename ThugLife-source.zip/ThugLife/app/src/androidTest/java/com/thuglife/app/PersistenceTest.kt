package com.thuglife.app

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.thuglife.app.core.Clock
import com.thuglife.app.core.DAY_MS
import com.thuglife.app.data.content.ContentImporter
import com.thuglife.app.data.local.ThugLifeDatabase
import com.thuglife.app.data.prefs.PreferencesRepository
import com.thuglife.app.data.repository.AttemptInput
import com.thuglife.app.data.repository.ProgressRepository
import com.thuglife.app.domain.ExerciseType
import com.thuglife.app.domain.LearningState
import com.thuglife.app.domain.Skill
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

class TestClock(var t: Long = 1_700_000_000_000L) : Clock { override fun now(): Long = t }

/** Instrumented tests: real Room (SQLite) on a device or emulator. */
@RunWith(AndroidJUnit4::class)
class PersistenceTest {
    private lateinit var ctx: Context
    private lateinit var db: ThugLifeDatabase
    private lateinit var prefs: PreferencesRepository
    private lateinit var repo: ProgressRepository
    private val clock = TestClock()

    @Before fun setUp() {
        ctx = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(ctx, ThugLifeDatabase::class.java).allowMainThreadQueries().build()
        prefs = PreferencesRepository(ctx)
        repo = ProgressRepository(db, prefs, clock)
    }

    @After fun tearDown() { db.close() }

    private fun attempt(ordinal: Int, item: String, correct: Boolean = true, expr: String? = "x_whats_up", session: String = "s1") = AttemptInput(
        session, ordinal, item, expr, Skill.RECALL, ExerciseType.RECALL_TYPED, correct, false, "a", 3000, false, 2, null
    )

    @Test fun duplicateSubmitIsIgnoredAndAwardsNothingTwice() = runBlocking {
        val first = repo.recordAttempt(attempt(0, "rcl_whats_up"))
        val again = repo.recordAttempt(attempt(0, "rcl_whats_up"))
        assertTrue(first.xpAwarded > 0)
        assertTrue(again.duplicate)
        assertEquals(0, again.xpAwarded)
        assertEquals(first.xpAwarded, db.activityDao().totalXp())
        assertEquals(1, db.reviewDao().get("x_whats_up")!!.successfulRecalls)
    }

    @Test fun sameExerciseEarnsXpOnlyOncePerDay() = runBlocking {
        val a = repo.recordAttempt(attempt(0, "rcl_whats_up"))
        val b = repo.recordAttempt(attempt(1, "rcl_whats_up", session = "s2"))
        assertTrue(a.xpAwarded > 0)
        assertEquals(0, b.xpAwarded)
        clock.t += DAY_MS
        val c = repo.recordAttempt(attempt(2, "rcl_whats_up", session = "s3"))
        assertTrue(c.xpAwarded > 0)
    }

    @Test fun wrongAnswerLapsesReviewAndEarnsNoXp() = runBlocking {
        repo.recordAttempt(attempt(0, "rcl_whats_up"))
        clock.t += 2 * DAY_MS
        val out = repo.recordAttempt(attempt(1, "rcl_whats_up", correct = false, session = "s2"))
        assertEquals(0, out.xpAwarded)
        val st = db.reviewDao().get("x_whats_up")!!
        assertEquals(LearningState.RELEARNING.name, st.learningState)
        assertEquals(1, st.failedRecalls)
    }

    @Test fun diagnosticAttemptsDoNotTouchReviewSchedule() = runBlocking {
        repo.recordAttempt(attempt(0, "rcl_whats_up").copy(updateReview = false))
        assertEquals(null, db.reviewDao().get("x_whats_up"))
    }

    @Test fun lessonCompletionXpIsPaidOncePerDayAndNeedsHalfScore() = runBlocking {
        assertEquals(0, repo.completeLesson("l_rap_1", 40))
        assertEquals(30, repo.completeLesson("l_rap_1", 80))
        assertEquals(0, repo.completeLesson("l_rap_1", 90))
    }

    @Test fun resetProgressClearsLearnerTablesOnly() = runBlocking {
        ContentImporter(InstrumentationRegistry.getInstrumentation().targetContext, db, prefs).ensureImported()
        repo.recordAttempt(attempt(0, "rcl_whats_up"))
        repo.resetProgress()
        assertEquals(0, db.activityDao().totalXp())
        assertEquals(null, db.reviewDao().get("x_whats_up"))
        assertTrue(db.contentDao().countExpressions() >= 60)
    }

    @Test fun contentImportIsRepeatableAndNeverTouchesProgress() = runBlocking {
        val target = InstrumentationRegistry.getInstrumentation().targetContext
        val importer = ContentImporter(target, db, prefs)
        importer.ensureImported()
        val expressions = db.contentDao().countExpressions()
        assertTrue(expressions >= 60)
        repo.recordAttempt(attempt(0, "rcl_whats_up"))
        val before = db.reviewDao().get("x_whats_up")
        assertNotNull(before)
        importer.importParsed(com.thuglife.app.data.content.ContentParser.parse(target.assets.open(ContentImporter.ASSET_PATH).bufferedReader().readText()))
        assertEquals(expressions, db.contentDao().countExpressions())
        assertEquals(before, db.reviewDao().get("x_whats_up"))
    }

    @Test fun reviewStateSurvivesClosingAndReopeningTheDatabase() = runBlocking {
        val name = "persist_test.db"
        ctx.deleteDatabase(name)
        var file = Room.databaseBuilder(ctx, ThugLifeDatabase::class.java, name).allowMainThreadQueries().build()
        ProgressRepository(file, prefs, clock).recordAttempt(attempt(0, "rcl_whats_up"))
        file.close()
        file = Room.databaseBuilder(ctx, ThugLifeDatabase::class.java, name).allowMainThreadQueries().build()
        val st = file.reviewDao().get("x_whats_up")
        assertNotNull(st)
        assertEquals(1, st!!.successfulRecalls)
        assertTrue(file.activityDao().totalXp() > 0)
        file.close()
        ctx.deleteDatabase(name)
    }
}
