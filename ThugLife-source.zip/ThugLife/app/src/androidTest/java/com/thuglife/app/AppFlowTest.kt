package com.thuglife.app

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Critical first-run and navigation flow on a real device/emulator. */
@RunWith(AndroidJUnit4::class)
class AppFlowTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()

    private fun waitForText(text: String, timeoutMs: Long = 15_000) {
        rule.waitUntil(timeoutMs) { rule.onAllNodesWithTextSafe(text) }
    }

    private fun androidx.compose.ui.test.junit4.ComposeTestRule.onAllNodesWithTextSafe(text: String): Boolean =
        onAllNodes(androidx.compose.ui.test.hasText(text)).fetchSemanticsNodes().isNotEmpty()

    @Test fun firstRunShowsOnboardingOrHomeAndHomeShowsRealRecommendation() {
        rule.waitUntil(20_000) { rule.onAllNodesWithTextSafe("خوش آمدید") || rule.onAllNodesWithTextSafe("قدم بعدی پیشنهادی") }
        if (rule.onAllNodesWithTextSafe("خوش آمدید")) {
            repeat(6) { rule.onNodeWithText("بعدی").performClick() }
            rule.onNodeWithText("رد کردن").performClick()
        }
        waitForText("قدم بعدی پیشنهادی")
        rule.onNodeWithText("ادامه‌ی یادگیری").assertExists()
    }

    @Test fun bottomNavigationReachesAllMainAreas() {
        rule.waitUntil(20_000) { rule.onAllNodesWithTextSafe("خوش آمدید") || rule.onAllNodesWithTextSafe("قدم بعدی پیشنهادی") }
        if (rule.onAllNodesWithTextSafe("خوش آمدید")) {
            repeat(6) { rule.onNodeWithText("بعدی").performClick() }
            rule.onNodeWithText("رد کردن").performClick()
        }
        waitForText("قدم بعدی پیشنهادی")
        rule.onNodeWithText("موسیقی").performClick(); waitForText("آزمایشگاه موسیقی")
        rule.onNodeWithText("خیابان").performClick(); waitForText("حالت خیابان")
        rule.onNodeWithText("چالش").performClick(); waitForText("میدان چالش")
        rule.onNodeWithText("حافظه").performClick(); waitForText("کارت‌های حافظه")
        rule.onNodeWithText("خانه").performClick(); waitForText("قدم بعدی پیشنهادی")
    }
}
