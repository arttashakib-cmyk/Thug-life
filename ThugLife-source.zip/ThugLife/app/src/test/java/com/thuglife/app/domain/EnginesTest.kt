package com.thuglife.app.domain

import com.thuglife.app.domain.engine.AchievementFacts
import com.thuglife.app.domain.engine.Achievements
import com.thuglife.app.domain.engine.AdaptiveDifficulty
import com.thuglife.app.domain.engine.AttemptSample
import com.thuglife.app.domain.engine.LearnerSnapshot
import com.thuglife.app.domain.engine.MasteryEstimator
import com.thuglife.app.domain.engine.MasteryLevel
import com.thuglife.app.domain.engine.RatingPolicy
import com.thuglife.app.domain.engine.RecAction
import com.thuglife.app.domain.engine.Recommender
import com.thuglife.app.domain.engine.ReviewKindPolicy
import com.thuglife.app.domain.engine.SkillAccuracy
import com.thuglife.app.domain.engine.SkillLevelState
import com.thuglife.app.domain.engine.StreakCalculator
import com.thuglife.app.domain.engine.XpPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class EnginesTest {
    // ---- XP and levels
    @Test fun wrongAnswersEarnNoXpEvenWhenFast() {
        assertEquals(0, XpPolicy.exerciseXp(Skill.RECALL, false, false, 3, true, 100, 10_000))
    }

    @Test fun xpScalesWithSkillDifficultyAssistAndTimedSpeed() {
        val base = XpPolicy.exerciseXp(Skill.RECALL, true, false, 1, false, 5000, null)
        assertEquals(8, base)
        assertTrue(XpPolicy.exerciseXp(Skill.RECALL, true, false, 5, false, 5000, null) > base)
        assertTrue(XpPolicy.exerciseXp(Skill.RECALL, true, true, 1, false, 5000, null) < base)
        assertTrue(XpPolicy.exerciseXp(Skill.RECALL, true, false, 1, true, 2000, 10_000) > base)
        assertEquals(base, XpPolicy.exerciseXp(Skill.RECALL, true, false, 1, true, 9000, 10_000))
    }

    @Test fun levelFormulaIsTransparent() {
        assertEquals(1, XpPolicy.level(0))
        assertEquals(1, XpPolicy.level(49))
        assertEquals(2, XpPolicy.level(50))
        assertEquals(3, XpPolicy.level(200))
        assertEquals(50, XpPolicy.xpForLevel(2))
        assertEquals(200, XpPolicy.xpForLevel(3))
        assertEquals(0.5f, XpPolicy.levelProgress(125), 1e-6f)
    }

    // ---- streaks
    private val today = LocalDate.of(2026, 10, 15)

    @Test fun streakCountsConsecutiveDaysEndingToday() {
        val s = StreakCalculator.compute(listOf(today, today.minusDays(1), today.minusDays(2), today.minusDays(5)), today)
        assertEquals(3, s.current); assertTrue(s.activeToday); assertEquals(3, s.longest)
    }

    @Test fun streakSurvivesUntilEndOfTodayIfYesterdayWasActive() {
        val s = StreakCalculator.compute(listOf(today.minusDays(1), today.minusDays(2)), today)
        assertEquals(2, s.current); assertFalse(s.activeToday)
    }

    @Test fun missedDayResetsCurrentButKeepsLongest() {
        val s = StreakCalculator.compute(listOf(today.minusDays(3), today.minusDays(4), today.minusDays(5)), today)
        assertEquals(0, s.current); assertEquals(3, s.longest)
    }

    @Test fun emptyHistoryIsZero() {
        val s = StreakCalculator.compute(emptyList(), today)
        assertEquals(0, s.current); assertEquals(0, s.longest)
    }

    @Test fun futureDatesAfterTimezoneChangeAreTreatedAsToday() {
        val s = StreakCalculator.compute(listOf(today.plusDays(1), today, today.minusDays(1)), today)
        assertEquals(2, s.current)
    }

    // ---- rating policy
    @Test fun fastWrongAnswerIsNeverMastery() {
        assertEquals(ReviewRating.AGAIN, RatingPolicy.rate(false, false, false, 300, ExerciseType.MEANING_RECOGNITION))
    }

    @Test fun speedNeverPromotesAboveGood() {
        assertEquals(ReviewRating.GOOD, RatingPolicy.rate(true, false, false, 200, ExerciseType.RECALL_TYPED))
        assertEquals(ReviewRating.HARD, RatingPolicy.rate(true, false, false, 99_000, ExerciseType.RECALL_TYPED))
        assertEquals(ReviewRating.HARD, RatingPolicy.rate(true, true, false, 200, ExerciseType.RECALL_TYPED))
    }

    // ---- adaptive difficulty
    private fun samples(correct: Int, total: Int, assisted: Int = 0) =
        List(total) { AttemptSample(it < correct, it < assisted) }

    @Test fun levelRisesOnlyAfterEnoughStrongSamples() {
        val st = SkillLevelState(2, 10, 0)
        assertEquals(3, AdaptiveDifficulty.adjust(st, samples(9, 10)).level)
        assertEquals(2, AdaptiveDifficulty.adjust(st, samples(9, 6)).level)
        assertEquals(2, AdaptiveDifficulty.adjust(SkillLevelState(2, 14, 10), samples(10, 10)).level)
    }

    @Test fun levelFallsOnPoorAccuracyAndStaysInRange() {
        assertEquals(2, AdaptiveDifficulty.adjust(SkillLevelState(3, 10, 0), samples(4, 10)).level)
        assertEquals(1, AdaptiveDifficulty.adjust(SkillLevelState(1, 10, 0), samples(1, 10)).level)
        assertEquals(5, AdaptiveDifficulty.adjust(SkillLevelState(5, 10, 0), samples(10, 10)).level)
    }

    @Test fun assistedAnswersBlockPromotion() {
        assertEquals(2, AdaptiveDifficulty.adjust(SkillLevelState(2, 10, 0), samples(10, 10, assisted = 5)).level)
    }

    @Test fun diagnosticAdjustsSelfReportedLevelByOne() {
        assertEquals(3, AdaptiveDifficulty.initialLevel(3, 1, 1))
        assertEquals(4, AdaptiveDifficulty.initialLevel(3, 2, 2))
        assertEquals(2, AdaptiveDifficulty.initialLevel(3, 0, 2))
        assertEquals(3, AdaptiveDifficulty.initialLevel(3, 1, 2))
    }

    // ---- mastery
    @Test fun viewedIsNotRecalled() {
        assertEquals(MasteryLevel.VIEWED, MasteryEstimator.estimate(ReviewState("a")))
        assertEquals(MasteryLevel.RECALLED, MasteryEstimator.estimate(ReviewState("a", successfulRecalls = 2, learningState = LearningState.REVIEW)))
        assertEquals(MasteryLevel.RETAINED, MasteryEstimator.estimate(ReviewState("a", successfulRecalls = 6, learningState = LearningState.MASTERED)))
    }

    // ---- review kind mix
    @Test fun reviewKindsRotateAndFailingItemsGetEasierKinds() {
        val kinds = (0..3).map { ReviewKindPolicy.preferred(ReviewState("a", repetitions = it, learningState = LearningState.REVIEW)).first() }
        assertEquals(4, kinds.toSet().size)
        assertEquals(ExerciseType.MEANING_RECOGNITION, ReviewKindPolicy.preferred(ReviewState("a", learningState = LearningState.RELEARNING)).first())
        assertEquals(ExerciseType.MEANING_RECOGNITION, ReviewKindPolicy.preferred(ReviewState("a", failedRecalls = 3, repetitions = 3)).first())
    }

    // ---- recommender
    private fun snap(
        due: Int = 0, overdue: Int = 0, inProgress: String? = null, next: String? = "l_rap_1",
        skills: Map<Skill, SkillAccuracy> = emptyMap(), goal: LearningGoal = LearningGoal.MUSIC,
        lessons: Int = 0, scenarios: Int = 0, unfinished: Boolean = true
    ) = LearnerSnapshot(due, overdue, inProgress, inProgress?.let { "t" }, next, next?.let { "n" }, skills, goal, lessons, scenarios, unfinished, 0, 60)

    @Test fun manyDueReviewsWin() {
        val r = Recommender.recommend(snap(due = 9))
        assertEquals(RecAction.StartReview, r.action)
        assertTrue(r.reasonFa.contains("۹"))
    }

    @Test fun weakSkillWithEnoughDataIsTargeted() {
        val r = Recommender.recommend(snap(skills = mapOf(Skill.LISTENING to SkillAccuracy(10, 4), Skill.RECALL to SkillAccuracy(10, 9))))
        assertEquals(RecAction.Weakness(Skill.LISTENING), r.action)
    }

    @Test fun weakSkillWithTooFewSamplesIsIgnored() {
        val r = Recommender.recommend(snap(skills = mapOf(Skill.LISTENING to SkillAccuracy(3, 0))))
        assertEquals(RecAction.OpenLesson("l_rap_1"), r.action)
    }

    @Test fun unfinishedLessonThenSomeDueThenNext() {
        assertEquals(RecAction.OpenLesson("l_x"), Recommender.recommend(snap(inProgress = "l_x")).action)
        assertEquals(RecAction.StartReview, Recommender.recommend(snap(due = 2)).action)
    }

    @Test fun conversationGoalPrefersStreetWhenBehind() {
        assertEquals(RecAction.OpenStreet, Recommender.recommend(snap(goal = LearningGoal.CONVERSATION, lessons = 3, scenarios = 0)).action)
    }

    @Test fun fallbackWhenNothingLeft() {
        assertEquals(RecAction.OpenArena, Recommender.recommend(snap(next = null, unfinished = false)).action)
    }

    // ---- achievements
    @Test fun achievementsOnlyUnlockNeverRevoke() {
        val f = AchievementFacts(1, 0, 10, 3, 3, 250, false, 1, 0, 0)
        val got = Achievements.unlocked(f)
        assertTrue("first_lesson" in got && "recall_10" in got && "streak_3" in got && "xp_200" in got)
        assertFalse("streak_7" in got)
        assertTrue(Achievements.all.map { it.id }.toSet().containsAll(got))
    }
}
