package com.thuglife.app.domain

import com.thuglife.app.core.DAY_MS
import com.thuglife.app.core.MINUTE_MS
import com.thuglife.app.domain.engine.Scheduler
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SchedulerTest {
    private val t0 = 1_700_000_000_000L
    private fun fresh() = ReviewState(expressionId = "x_test", firstSeenAt = t0)

    @Test fun firstGoodSchedulesOneDay() {
        val s = Scheduler.review(fresh(), ReviewRating.GOOD, t0)
        assertEquals(1, s.repetitions)
        assertEquals(1.0, s.intervalDays, 1e-9)
        assertEquals(LearningState.LEARNING, s.learningState)
        assertEquals(t0 + DAY_MS, s.nextReviewAt)
        assertEquals(1, s.successfulRecalls)
    }

    @Test fun intervalsGrowWithEase() {
        var s = Scheduler.review(fresh(), ReviewRating.GOOD, t0)
        s = Scheduler.review(s, ReviewRating.GOOD, t0 + DAY_MS)
        assertEquals(3.0, s.intervalDays, 1e-9)
        assertEquals(LearningState.REVIEW, s.learningState)
        s = Scheduler.review(s, ReviewRating.GOOD, t0 + 4 * DAY_MS)
        assertEquals(7.5, s.intervalDays, 1e-9)
        assertEquals(2.5, s.easeFactor, 1e-9)
    }

    @Test fun lapseSendsItemBackQuicklyAndHalvesInterval() {
        var s = Scheduler.review(fresh(), ReviewRating.GOOD, t0)
        s = Scheduler.review(s, ReviewRating.GOOD, t0 + DAY_MS)
        s = Scheduler.review(s, ReviewRating.GOOD, t0 + 4 * DAY_MS)
        val now = t0 + 12 * DAY_MS
        val l = Scheduler.review(s, ReviewRating.AGAIN, now)
        assertEquals(LearningState.RELEARNING, l.learningState)
        assertEquals(0, l.repetitions)
        assertEquals(1, l.failedRecalls)
        assertEquals(3.75, l.intervalDays, 1e-9)
        assertEquals(2.3, l.easeFactor, 1e-9)
        assertEquals(now + 10 * MINUTE_MS, l.nextReviewAt)
    }

    @Test fun relearningGraduatesWhenDueUsingCarriedInterval() {
        var s = Scheduler.review(fresh(), ReviewRating.GOOD, t0)
        s = Scheduler.review(s, ReviewRating.GOOD, t0 + DAY_MS)
        val lapseAt = t0 + 5 * DAY_MS
        s = Scheduler.review(s, ReviewRating.AGAIN, lapseAt)
        val back = Scheduler.review(s, ReviewRating.GOOD, lapseAt + 11 * MINUTE_MS)
        assertEquals(LearningState.REVIEW, back.learningState)
        assertEquals(s.intervalDays, back.intervalDays, 1e-9)
        assertEquals(lapseAt + 11 * MINUTE_MS + (s.intervalDays * DAY_MS).toLong(), back.nextReviewAt)
    }

    @Test fun sameSessionSuccessDoesNotInflateSchedule() {
        val first = Scheduler.review(fresh(), ReviewRating.GOOD, t0)
        val second = Scheduler.review(first, ReviewRating.GOOD, t0 + 2 * MINUTE_MS)
        assertEquals(first.nextReviewAt, second.nextReviewAt)
        assertEquals(first.intervalDays, second.intervalDays, 1e-9)
        assertEquals(1, second.repetitions)
        assertEquals(2, second.successfulRecalls)
    }

    @Test fun wrongAnswerInsideSessionStillLapses() {
        val first = Scheduler.review(fresh(), ReviewRating.GOOD, t0)
        val wrong = Scheduler.review(first, ReviewRating.AGAIN, t0 + 2 * MINUTE_MS)
        assertEquals(1, wrong.failedRecalls)
        assertEquals(t0 + 12 * MINUTE_MS, wrong.nextReviewAt)
    }

    @Test fun hardGrowsLessThanGoodAndEasyGrowsMore() {
        var base = Scheduler.review(fresh(), ReviewRating.GOOD, t0)
        base = Scheduler.review(base, ReviewRating.GOOD, t0 + DAY_MS)
        val at = t0 + 4 * DAY_MS
        val hard = Scheduler.review(base, ReviewRating.HARD, at)
        val good = Scheduler.review(base, ReviewRating.GOOD, at)
        val easy = Scheduler.review(base, ReviewRating.EASY, at)
        assertTrue(hard.intervalDays < good.intervalDays)
        assertTrue(good.intervalDays < easy.intervalDays)
        assertTrue(hard.easeFactor < good.easeFactor)
        assertTrue(easy.easeFactor > good.easeFactor)
    }

    @Test fun reviewingAheadBarelyGrowsInterval() {
        var s = Scheduler.review(fresh(), ReviewRating.GOOD, t0)
        s = Scheduler.review(s, ReviewRating.GOOD, t0 + DAY_MS)
        s = Scheduler.review(s, ReviewRating.GOOD, t0 + 4 * DAY_MS)
        val early = Scheduler.review(s, ReviewRating.GOOD, t0 + 6 * DAY_MS) // due at day 11.5
        assertEquals(s.intervalDays, early.intervalDays, 1e-9)
        val easyEarly = Scheduler.review(s, ReviewRating.EASY, t0 + 6 * DAY_MS)
        assertTrue(easyEarly.intervalDays <= s.intervalDays * 1.15 + 1e-9)
    }

    @Test fun easeNeverDropsBelowMinimum() {
        var s = Scheduler.review(fresh(), ReviewRating.GOOD, t0)
        var now = t0
        repeat(15) { now += DAY_MS; s = Scheduler.review(s, ReviewRating.AGAIN, now) }
        assertEquals(Scheduler.MIN_EASE, s.easeFactor, 1e-9)
        assertEquals(15, s.failedRecalls)
    }

    @Test fun leechesComeBackSooner() {
        var s = fresh()
        var now = t0
        repeat(4) { now += DAY_MS; s = Scheduler.review(s, ReviewRating.AGAIN, now) }
        assertEquals(now + 5 * MINUTE_MS, s.nextReviewAt)
    }

    @Test fun masteredNeedsManySpacedSuccesses() {
        var s = fresh()
        var now = t0
        repeat(8) { s = Scheduler.review(s, ReviewRating.EASY, now); now = s.nextReviewAt!! + 1 }
        assertEquals(LearningState.MASTERED, s.learningState)
        assertTrue(s.intervalDays >= 21.0)
    }

    @Test fun newItemIsNeverDueAndScheduledItemBecomesDue() {
        assertFalse(Scheduler.isDue(fresh(), t0 + 100 * DAY_MS))
        val s = Scheduler.review(fresh(), ReviewRating.GOOD, t0)
        assertFalse(Scheduler.isDue(s, t0 + DAY_MS - 1))
        assertTrue(Scheduler.isDue(s, t0 + DAY_MS))
    }

    @Test fun intervalIsCapped() {
        var s = fresh()
        var now = t0
        repeat(30) { s = Scheduler.review(s, ReviewRating.EASY, now); now = s.nextReviewAt!! + 1 }
        assertTrue(s.intervalDays <= Scheduler.MAX_INTERVAL_DAYS)
    }
}
