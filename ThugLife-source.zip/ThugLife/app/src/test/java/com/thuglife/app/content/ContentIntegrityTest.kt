package com.thuglife.app.content

import com.thuglife.app.data.content.ContentParser
import com.thuglife.app.data.local.toStringList
import com.thuglife.app.domain.ExerciseType
import com.thuglife.app.domain.engine.AnswerValidator
import com.thuglife.app.domain.engine.TextNormalizer
import com.thuglife.app.domain.engine.Verdict
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File

/** Parses the real bundled curriculum.json (same file the app imports). Runs on the JVM, no device needed. */
class ContentIntegrityTest {
    private lateinit var c: com.thuglife.app.data.content.ParsedContent
    private val assets = File("src/main/assets")

    @Before fun load() {
        c = ContentParser.parse(File(assets, "content/curriculum.json").readText(Charsets.UTF_8))
    }

    @Test fun meetsMinimumContentTargets() {
        assertTrue(c.expressions.size >= 60)
        assertTrue(c.lessons.size >= 12)
        assertTrue(c.scenarios.size >= 12)
        assertEquals(4, c.expressions.map { it.pathway }.toSet().size)
        val byType = c.exercises.groupingBy { it.type }.eachCount()
        val listening = listOf("LISTEN_IDENTIFY", "AUDIO_MEMORY", "LISTEN_COMPREHENSION").sumOf { byType[it] ?: 0 }
        val assessment = listOf("MEANING_RECOGNITION", "RECALL_TYPED", "SLANG_DECODER", "NATURAL_OR_UNNATURAL", "CONTEXT_MATCH", "MISSING_PHRASE").sumOf { byType[it] ?: 0 }
        val production = listOf("SENTENCE_RECONSTRUCTION", "TYPED_PRODUCTION").sumOf { byType[it] ?: 0 }
        assertTrue("listening=$listening", listening >= 30)
        assertTrue("assessment=$assessment", assessment >= 60)
        assertTrue("production=$production", production >= 20)
    }

    @Test fun idsAreUniqueAndReferencesResolve() {
        fun unique(ids: List<String>, what: String) = assertEquals("duplicate $what", ids.size, ids.toSet().size)
        unique(c.expressions.map { it.id }, "expressions"); unique(c.lessons.map { it.id }, "lessons")
        unique(c.exercises.map { it.id }, "exercises"); unique(c.audio.map { it.id }, "audio")
        unique(c.scenarios.map { it.id }, "scenarios"); unique(c.steps.map { it.id }, "steps")
        val expr = c.expressions.map { it.id }.toSet(); val lessons = c.lessons.map { it.id }.toSet()
        val audio = c.audio.map { it.id }.toSet(); val steps = c.steps.map { it.id }.toSet()
        c.lessonExpressions.forEach { assertTrue(it.expressionId in expr && it.lessonId in lessons) }
        assertEquals("every expression belongs to a lesson", expr, c.lessonExpressions.map { it.expressionId }.toSet())
        c.expressions.forEach { assertTrue(it.audioAssetId in audio) }
        c.exercises.forEach { e ->
            e.expressionId?.let { assertTrue("expr ref ${e.id}", it in expr) }
            e.lessonId?.let { assertTrue("lesson ref ${e.id}", it in lessons) }
            e.audioAssetId?.let { assertTrue("audio ref ${e.id}", it in audio) }
            assertTrue("unknown type ${e.type}", ExerciseType.fromName(e.type) != null)
        }
        c.steps.forEach { s -> s.nextStepId?.let { assertTrue(it in steps) } }
        c.scenarios.forEach { assertTrue(it.startStepId in steps) }
    }

    @Test fun everyAcceptedAnswerValidatesItselfAndOptionsContainTheAnswer() {
        c.exercises.forEach { e ->
            val accepted = e.acceptedJson.toStringList(); val options = e.optionsJson.toStringList(); val tokens = e.tokensJson.toStringList()
            assertTrue("accepted ${e.id}", accepted.isNotEmpty() && accepted.all { TextNormalizer.normalize(it).isNotEmpty() })
            val type = ExerciseType.fromName(e.type)!!
            when (type.input) {
                com.thuglife.app.domain.InputKind.CHOICE, com.thuglife.app.domain.InputKind.BINARY ->
                    assertEquals("answer in options ${e.id}", Verdict.CORRECT, AnswerValidator.validateChoice(accepted[0], accepted).verdict.also { assertTrue(accepted[0] in options) })
                com.thuglife.app.domain.InputKind.TYPED -> accepted.forEach { assertEquals(e.id, Verdict.CORRECT, AnswerValidator.validateTyped(it, accepted).verdict) }
                com.thuglife.app.domain.InputKind.ORDER -> {
                    assertEquals(accepted[0].split(" ").map { TextNormalizer.normalize(it) }.sorted(), tokens.map { TextNormalizer.normalize(it) }.sorted())
                    assertEquals(e.id, Verdict.CORRECT, AnswerValidator.validateOrder(accepted[0].split(" "), accepted).verdict)
                }
                com.thuglife.app.domain.InputKind.REVEAL -> Unit
            }
        }
    }

    @Test fun listeningExercisesHaveAudioThatResolves() {
        c.exercises.filter { ExerciseType.fromName(it.type)?.usesAudio == true }.forEach { e ->
            val a = c.audio.firstOrNull { it.id == e.audioAssetId }
            assertTrue("audio for ${e.id}", a != null)
            assertTrue("TTS text for ${e.id}", a!!.kind != "TTS" || !a.text.isNullOrBlank())
        }
    }

    @Test fun bundledAudioFilesActuallyExistAndTtsIsLabelledHonestly() {
        c.audio.forEach { a ->
            if (a.kind == "BUNDLED") assertTrue("missing file for ${a.id}", a.resourceName != null && File(assets, "audio/${a.resourceName}").exists())
            else assertTrue(a.attribution!!.contains("تبدیل متن به گفتار"))
        }
    }

    @Test fun scenariosAreMultiStepWithMixedInteractionKinds() {
        c.scenarios.forEach { sc ->
            val steps = c.steps.filter { it.scenarioId == sc.id }
            assertTrue("steps ${sc.id}", steps.size >= 3)
            assertTrue("kinds ${sc.id}", steps.map { it.kind }.toSet().size >= 2)
            steps.filter { it.kind == "CHOICE" || it.kind == "LISTEN_CHOICE" }.forEach { assertTrue(it.optionsJson.contains("\"BEST\"")) }
        }
        assertTrue(c.steps.any { it.kind == "TYPED" } && c.steps.any { it.kind == "FILL" } && c.steps.any { it.kind == "ORDER" } && c.steps.any { it.kind == "LISTEN_CHOICE" })
    }

    @Test fun persianExplanationsArePresent() {
        val fa = Regex("[\\u0600-\\u06FF]")
        c.expressions.forEach { assertTrue(it.id, fa.containsMatchIn(it.persian) && fa.containsMatchIn(it.context) && !it.pronunciation.isNullOrBlank()) }
        c.lessons.forEach { assertTrue(fa.containsMatchIn(it.introFa)) }
    }
}
