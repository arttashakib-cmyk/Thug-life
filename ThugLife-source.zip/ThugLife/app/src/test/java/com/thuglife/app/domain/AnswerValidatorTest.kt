package com.thuglife.app.domain

import com.thuglife.app.domain.engine.AnswerValidator
import com.thuglife.app.domain.engine.SpeechComparison
import com.thuglife.app.domain.engine.TextNormalizer
import com.thuglife.app.domain.engine.Verdict
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AnswerValidatorTest {
    @Test fun normalizeIgnoresCaseApostrophesAndPunctuation() {
        assertEquals("whats up", TextNormalizer.normalize("  What's   up?! "))
        assertEquals("whats up", TextNormalizer.normalize("What\u2019s up"))
        assertEquals("a wake up call", TextNormalizer.normalize("a wake-up call"))
    }

    @Test fun exactAndPunctuationInsensitiveMatchIsCorrect() {
        val r = AnswerValidator.validateTyped("no worries", listOf("No worries."))
        assertEquals(Verdict.CORRECT, r.verdict)
    }

    @Test fun oneTypoIsNearButTwoTyposAreWrongForShortPhrases() {
        assertEquals(Verdict.NEAR, AnswerValidator.validateTyped("spil the beans", listOf("Spill the beans")).verdict)
        assertEquals(Verdict.WRONG, AnswerValidator.validateTyped("spl the bens", listOf("Spill the beans")).verdict)
    }

    @Test fun veryShortAnswersNeedExactMatch() {
        assertEquals(Verdict.WRONG, AnswerValidator.validateTyped("dop", listOf("dope")).verdict.let { if (it == Verdict.NEAR) Verdict.WRONG else it })
        assertEquals(Verdict.WRONG, AnswerValidator.validateTyped("cap", listOf("gap")).verdict)
    }

    @Test fun emptyInputIsEmpty() {
        assertEquals(Verdict.EMPTY, AnswerValidator.validateTyped("   ", listOf("x")).verdict)
        assertEquals(Verdict.EMPTY, AnswerValidator.validateChoice(null, listOf("x")).verdict)
        assertEquals(Verdict.EMPTY, AnswerValidator.validateOrder(emptyList(), listOf("x")).verdict)
    }

    @Test fun containsModeAcceptsLongerSentenceButNotNegation() {
        val acc = listOf("I'm down")
        assertEquals(Verdict.CORRECT, AnswerValidator.validateTyped("Yeah, I'm down for that!", acc, allowContains = true).verdict)
        assertEquals(Verdict.WRONG, AnswerValidator.validateTyped("I'm not down for that", acc, allowContains = true).verdict)
        assertEquals(Verdict.WRONG, AnswerValidator.validateTyped("Yeah, I'm down for that!", acc, allowContains = false).verdict)
    }

    @Test fun wordOrderMustMatch() {
        val acc = listOf("Do you wanna grab a coffee sometime?")
        assertEquals(Verdict.CORRECT, AnswerValidator.validateOrder(listOf("Do", "you", "wanna", "grab", "a", "coffee", "sometime?"), acc).verdict)
        assertEquals(Verdict.WRONG, AnswerValidator.validateOrder(listOf("you", "Do", "wanna", "grab", "a", "coffee", "sometime?"), acc).verdict)
    }

    @Test fun choiceIsExact() {
        assertEquals(Verdict.CORRECT, AnswerValidator.validateChoice("A", listOf("A")).verdict)
        assertEquals(Verdict.WRONG, AnswerValidator.validateChoice("B", listOf("A")).verdict)
    }

    @Test fun levenshteinBasics() {
        assertEquals(0, AnswerValidator.levenshtein("abc", "abc"))
        assertEquals(1, AnswerValidator.levenshtein("abc", "abd"))
        assertEquals(3, AnswerValidator.levenshtein("", "abc"))
    }

    @Test fun speechComparisonReportsWordsNotAScore() {
        val r = SpeechComparison.compare("Cut me some slack", "cut me some black")
        assertEquals(listOf("cut", "me", "some"), r.matchedWords)
        assertEquals(listOf("slack"), r.missingWords)
        assertEquals(listOf("black"), r.extraWords)
        assertEquals(0.75, r.completion, 1e-9)
        assertTrue(SpeechComparison.compare("hello", "").matchedWords.isEmpty())
    }
}
