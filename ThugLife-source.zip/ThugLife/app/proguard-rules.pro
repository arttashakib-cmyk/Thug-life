# Room generates its own keep rules. Content is parsed with org.json (part of Android), no reflection.
-keepclassmembers class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}
