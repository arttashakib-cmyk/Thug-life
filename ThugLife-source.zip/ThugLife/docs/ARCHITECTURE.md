# معماری

MVVM + Repository روی یک ماژول `app` با پکیج‌بندی لایه‌ای؛ DI دستی (`AppContainer`) بدون چارچوب اضافه.

- **UI**: Compose + Material 3، جهت RTL اجباری در `ThugLifeTheme`، متن انگلیسی با `EnglishText` (LTR). هر صفحه ViewModel و وضعیت صریح (Loading/Empty/Error/Ready) دارد؛ state با `collectAsStateWithLifecycle`؛ شناسه‌ها (نه اشیاء) در مسیر ناوبری؛ `SavedStateHandle` برای بازیابی جلسه بعد از چرخش/مرگ فرایند.
- **جلسه‌ی تمرین عمومی** (`ExerciseSessionViewModel`) برای درس، چالش، مرور، ارزیابی و تمرین هدفمند؛ `ScenarioViewModel` برای حالت خیابان. هر پاسخ در یک تراکنش Room ثبت می‌شود.
- **داده**: Room v1 (۱۵ جدول: محتوا — expressions, lessons, lesson_expressions, audio_assets, exercises, scenarios, scenario_steps؛ یادگیرنده — expression_review_states, learning_sessions, exercise_attempts, xp_events, lesson_progress, scenario_progress, skill_profiles, achievements)، DataStore برای تنظیمات. بدون `fallbackToDestructiveMigration`؛ اسکیما در `app/schemas` صادر می‌شود.
- **محتوا**: `curriculum.json` با `ContentImporter` به‌صورت upsert با شناسه‌ی پایدار فقط روی جدول‌های محتوا وارد می‌شود و منتظر می‌ماند تا Splash تمام شود (بدون race). حذف ردیف‌های محتوایی کنار گذاشته شده تا پیشرفت یتیم نشود.
- **آنلاین**: فقط رابط‌ها (`data/online`) با پیاده‌سازی «پیکربندی‌نشده»؛ هیچ endpoint و کلیدی نیست.
- **عملکرد**: Room روی Dispatcher خودش، `StrictMode` در دیباگ، لیست‌های Lazy با key پایدار، بدون Blur/تصویر بزرگ، کتابخانه‌ی آیکن سنگین حذف شد. برای پروفایلینگ: Android Studio Profiler (CPU/Memory)، Macrobenchmark برای cold start، `adb shell am start -W`؛ اندازه‌گیری انجام نشده و عددی ادعا نمی‌شود.
