// Versions are pinned deliberately as one internally consistent set:
// Gradle 8.9 + AGP 8.7.2 + Kotlin 2.0.21 + KSP 2.0.21-1.0.25 + Compose BOM 2024.10.01 + Room 2.6.1.
plugins {
    id("com.android.application") version "8.7.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    id("com.google.devtools.ksp") version "2.0.21-1.0.25" apply false
}
