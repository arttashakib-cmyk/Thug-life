# -*- coding: utf-8 -*-
"""Integrity checks for app/src/main/assets/content/curriculum.json. Exit code 1 on any problem.
Run in CI before the Gradle build:  python3 tools/validate_content.py"""
import json, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "app", "src", "main", "assets")
d = json.load(open(os.path.join(ASSETS, "content", "curriculum.json"), encoding="utf-8"))
errors = []
def err(m): errors.append(m)

def norm(s):
    s = s.lower().replace("\u2019", "'").replace("\u2018", "'").replace("'", "")
    s = re.sub(r"[-\u2013\u2014]", " ", s)
    s = re.sub(r"[^\w ]", "", s)
    return re.sub(r"\s+", " ", s).strip()

def unique(rows, key, what):
    ids = [r[key] for r in rows]
    if len(ids) != len(set(ids)): err("duplicate ids in " + what)
    return set(ids)

audio = {a["id"]: a for a in d["audioAssets"]}
unique(d["audioAssets"], "id", "audioAssets")
for a in d["audioAssets"]:
    if a["kind"] == "TTS":
        if not a["text"].strip(): err("empty TTS text " + a["id"])
    elif a["kind"] == "BUNDLED":
        if not a.get("resource") or not os.path.exists(os.path.join(ASSETS, "audio", a["resource"])):
            err("BUNDLED audio file missing for " + a["id"])
    else: err("unknown audio kind " + a["id"])

exprs = unique(d["expressions"], "id", "expressions")
persian = re.compile(r"[\u0600-\u06FF]")
for e in d["expressions"]:
    for f in ("english", "persian", "context", "register", "topic", "pronunciation", "situationFa", "pathway"):
        if not str(e.get(f) or "").strip(): err("%s missing %s" % (e["id"], f))
    if not persian.search(e["persian"]) or not persian.search(e["context"]): err("no Persian text in " + e["id"])
    if not (1 <= e["difficulty"] <= 5): err("difficulty " + e["id"])
    if len(e["examples"]) < 2 or len(e["alternatives"]) < 1: err("examples/alternatives " + e["id"])
    if e["audio"] not in audio: err("audio ref " + e["id"])
    if e["pathway"] not in ("RAP", "ROCK", "POP", "EVERYDAY"): err("pathway " + e["id"])
lessons = unique(d["lessons"], "id", "lessons")
covered = set()
for r in d["lessonExpressions"]:
    if r["lesson"] not in lessons or r["expr"] not in exprs: err("lessonExpression ref %s/%s" % (r["lesson"], r["expr"]))
    covered.add(r["expr"])
if covered != exprs: err("expressions not in any lesson: %s" % sorted(exprs - covered))
for l in d["lessons"]:
    if len(l["lyric"]) < 2: err("lyric short " + l["id"])
    if l["listenAudio"] not in audio: err("lesson audio " + l["id"])
ex_ids = unique(d["exercises"], "id", "exercises")
for x in d["exercises"]:
    i = x["id"]
    if x["expr"] and x["expr"] not in exprs: err("exercise expr ref " + i)
    if x["lesson"] and x["lesson"] not in lessons: err("exercise lesson ref " + i)
    if x["audio"] and x["audio"] not in audio: err("exercise audio ref " + i)
    if x["type"] in ("LISTEN_IDENTIFY", "AUDIO_MEMORY", "LISTEN_COMPREHENSION") and not x["audio"]: err("listening without audio " + i)
    if not x["accepted"] or not all(norm(a) for a in x["accepted"]): err("accepted " + i)
    if not x["promptFa"].strip() or not x["explanationFa"].strip(): err("prompt/explanation " + i)
    if x["options"] is not None:
        if len(set(x["options"])) != len(x["options"]): err("duplicate options " + i)
        if x["accepted"][0] not in x["options"]: err("answer not among options " + i)
        if x["type"] != "NATURAL_OR_UNNATURAL" and len(x["options"]) < 3: err("too few options " + i)
    if x["tokens"] is not None:
        if sorted(norm(t) for t in x["tokens"]) != sorted(norm(t) for t in x["accepted"][0].split()): err("tokens mismatch " + i)
    if x["type"] in ("MISSING_PHRASE",) and "____" not in (x["promptEn"] or ""): err("blank missing " + i)
scen = unique(d["scenarios"], "id", "scenarios")
steps = unique(d["scenarioSteps"], "id", "scenarioSteps")
for s in d["scenarioSteps"]:
    i = s["id"]
    if s["scenario"] not in scen: err("step scenario " + i)
    if s["next"] and s["next"] not in steps: err("step next " + i)
    if s["audio"] and s["audio"] not in audio: err("step audio " + i)
    if s["expr"] and s["expr"] not in exprs: err("step expr " + i)
    if s["kind"] in ("CHOICE", "LISTEN_CHOICE"):
        qs = [o["q"] for o in s["options"]]
        if "BEST" not in qs: err("no BEST option " + i)
        for o in s["options"]:
            if o["next"] and o["next"] not in steps: err("option next " + i)
            if not o["fb"].strip(): err("option feedback " + i)
    else:
        if not s["accepted"]: err("no accepted " + i)
        if s["kind"] == "ORDER" and sorted(norm(t) for t in s["tokens"]) != sorted(norm(t) for t in s["accepted"][0].split()): err("order tokens " + i)
        if s["kind"] == "FILL" and "____" not in s["prompt"]: err("fill blank " + i)
for sc in d["scenarios"]:
    if sc["start"] not in steps: err("scenario start " + sc["id"])
    kinds = {s["kind"] for s in d["scenarioSteps"] if s["scenario"] == sc["id"]}
    if len(kinds) < 2: err("scenario has a single step kind " + sc["id"])

# minimum content targets from the product spec
cnt = lambda t: sum(1 for x in d["exercises"] if x["type"] in t)
targets = [("expressions>=60", len(d["expressions"]) >= 60), ("lessons>=12", len(d["lessons"]) >= 12),
           ("scenarios>=12", len(d["scenarios"]) >= 12), ("pathways==4", len({e["pathway"] for e in d["expressions"]}) == 4),
           ("listening>=30", cnt(("LISTEN_IDENTIFY", "AUDIO_MEMORY", "LISTEN_COMPREHENSION")) >= 30),
           ("assessment/recall>=60", cnt(("MEANING_RECOGNITION", "RECALL_TYPED", "SLANG_DECODER", "NATURAL_OR_UNNATURAL", "CONTEXT_MATCH", "MISSING_PHRASE")) >= 60),
           ("reconstruction/production>=20", cnt(("SENTENCE_RECONSTRUCTION", "TYPED_PRODUCTION")) >= 20)]
for n, ok in targets:
    if not ok: err("target not met: " + n)
if errors:
    print("CONTENT INVALID:"); [print(" -", m) for m in errors]; sys.exit(1)
print("content OK:", len(d["expressions"]), "expressions,", len(d["lessons"]), "lessons,", len(d["exercises"]), "exercises,",
      len(d["scenarios"]), "scenarios /", len(d["scenarioSteps"]), "steps,", len(d["audioAssets"]), "audio assets")
