# -*- coding: utf-8 -*-
# 13 multi-step conversation scenarios for Street Mode. All dialogue is original.
# Step kinds: CHOICE (pick a reply), LISTEN_CHOICE (hear the line first), TYPED, FILL (missing word), ORDER (rebuild sentence).
# Option tuple: (text, quality BEST|OK|BAD, feedback_fa, next_step_id or None -> default next)

def CH(id, sit, partner, opts, formal, alts, avoid, nxt=None, expr=None, listen=False):
    return dict(id=id, kind="LISTEN_CHOICE" if listen else "CHOICE", sit=sit, partner=partner,
                options=[dict(t=o[0], q=o[1], fb=o[2], next=(o[3] if len(o) > 3 else None)) for o in opts],
                formal=formal, alts=alts, avoid=avoid, next=nxt, expr=expr)

def TY(id, sit, partner, accepted, ok, bad, formal, alts, avoid, nxt=None, expr=None, hint=None):
    return dict(id=id, kind="TYPED", sit=sit, partner=partner, accepted=accepted, ok=ok, bad=bad,
                formal=formal, alts=alts, avoid=avoid, next=nxt, expr=expr, hint=hint)

def FI(id, sit, partner, prompt, accepted, ok, bad, formal, alts, avoid, nxt=None, expr=None):
    return dict(id=id, kind="FILL", sit=sit, partner=partner, prompt=prompt, accepted=accepted, ok=ok, bad=bad,
                formal=formal, alts=alts, avoid=avoid, next=nxt, expr=expr)

def OR(id, sit, partner, sentence, ok, bad, formal, alts, avoid, nxt=None, expr=None):
    return dict(id=id, kind="ORDER", sit=sit, partner=partner, sentence=sentence, ok=ok, bad=bad,
                formal=formal, alts=alts, avoid=avoid, next=nxt, expr=expr)

def S(id, titleFa, titleEn, descFa, diff, topic, steps):
    return dict(id=id, titleFa=titleFa, titleEn=titleEn, descFa=descFa, diff=diff, topic=topic, steps=steps)

SCENARIOS = [
S("meet_new","آشنایی با فرد جدید","Meeting Someone New","اولین مکالمه با کسی که تازه می‌شناسید.",1,"meeting",[
  CH("s1","در یک دورهمی کسی خودش را معرفی می‌کند.","Hi, I don't think we've met. I'm Sam.",[
    ("Hi Sam, I'm Ava. Nice to meet you.","BEST","طبیعی و دوستانه است: اسم خودتان را می‌گویید و محترمانه جواب می‌دهید.",None),
    ("Hi. Who are you?","BAD","«Who are you?» سرد و تقریباً بی‌ادبانه است؛ او خودش را معرفی کرد.",None),
    ("Hello. My name is Ava.","OK","درست و مؤدبانه است ولی کمی رسمی و خشک؛ در دورهمی «Nice to meet you» بعدش لازم است.",None)],
    "خودمانی ولی مؤدبانه",["Hey Sam, I'm Ava.","Good to meet you, Sam."],"«Who are you?» برای اولین آشنایی نامناسب است.","s2",listen=True),
  TY("s2","او به شما کمک کرده تا اتاق را پیدا کنید و شما تشکر کرده‌اید.","Hey, thanks for walking me to the room!",
    ["no worries","no problem","anytime","you're welcome","sure thing","don't mention it"],
    "عالی! همه‌ی این جواب‌ها در این موقعیت طبیعی‌اند.","جوابی کوتاه و محترمانه مثل «No worries» یا «You're welcome» بنویسید.",
    "خودمانی / مؤدبانه",["No problem.","Anytime."],"فقط «Yes» جواب مناسبی برای تشکر نیست.","s3",expr="no_worries",hint="کوتاه و دوستانه جواب بدهید"),
  OR("s3","می‌خواهید او را برای یک قهوه دعوت کنید.",None,"Do you wanna grab a coffee sometime?",
    "درست! «wanna» این جمله را خودمانی و طبیعی می‌کند.","ترتیب کلمات را بررسی کنید؛ سؤال با «Do you» شروع می‌شود.",
    "خودمانی",["Would you like to grab a coffee sometime?"],"با مافوق رسمی «Would you like to…» بهتر است.",None,expr="wanna"),
]),
S("friends_chat","صحبت با دوستان","Talking with Friends","احوال‌پرسی و پیشنهاد در جمع دوستان.",1,"friends",[
  CH("s1","دوست قدیمی‌تان را بعد از مدت‌ها می‌بینید.","What's up, man? Long time no see!",[
    ("Not much, just chilling. You?","BEST","جواب کوتاه، طبیعی و خودمانی؛ سؤال را هم برمی‌گردانید.",None),
    ("I am fine, thank you, and you?","OK","از نظر دستوری درست است ولی بین دوستان بیش از حد رسمی و کتابی است.",None),
    ("Why do you ask?","BAD","مثل بدگمانی به نظر می‌رسد؛ «What's up» فقط سلام است.",None)],
    "خودمانی",["Not much. How about you?","Just hanging out."],"«How do you do?» بین دوستان نامناسب و قدیمی است.","s2",expr="whats_up"),
  FI("s2","او شما را به بازی امشب دعوت کرده، ولی باید زودتر بروید.","Wanna come to the game tonight?",
    "Sorry, I ____ go home. Maybe next time.",["gotta"],
    "درست! «gotta» یعنی «باید» و در خداحافظی خیلی رایج است.","اینجا «gotta» (= got to) می‌خواهد؛ یعنی «باید».",
    "خودمانی",["I have to go home.","I need to head home."],"در ایمیل رسمی gotta ننویسید.","s3",expr="gotta"),
  OR("s3","می‌خواهید بگویید وقتی رسیدید بهتان خبر بدهد.",None,"Hit me up when you get there.",
    "درست! «Hit me up» یعنی پیام بده یا زنگ بزن.","«Hit me up» با ضمیر me در وسط می‌آید.",
    "غیررسمی",["Text me when you get there."],"در محیط کار رسمی استفاده نکنید.",None,expr="hit_me_up"),
]),
S("order_food","سفارش غذا و نوشیدنی","Ordering Food and Drinks","سفارش در کافه با لحن مؤدبانه و طبیعی.",2,"food",[
  CH("s1","در کافه جلوی صندوق ایستاده‌اید.","Hi! What can I get for you?",[
    ("Can I get a large latte, please?","BEST","روش رایج و مؤدبانه برای سفارش؛ «please» لحن را نرم می‌کند.",None),
    ("Give me a latte.","OK","مفهوم است ولی دستوری و کمی تند؛ با «please» یا «Can I get…» نرم‌تر می‌شود.",None),
    ("I want latte now.","BAD","هم دستور مستقیم است و هم گرامر نادرست (a latte)؛ لحنش تند است.",None)],
    "مؤدبانه",["I'll have a large latte, please.","Could I have a large latte?"],"دستور مستقیم و بدون «please» را به‌کار نبرید.","s2"),
  CH("s2","صندوق‌دار قیمت را می‌گوید و می‌پرسد چطور تحویل بگیرید.","That'll be six fifty. For here or to go?",[
    ("To go, please.","BEST","کوتاه و طبیعی؛ «To go» یعنی بیرون‌بر.",None),
    ("Yes.","BAD","سؤال انتخابی است و «Yes» به آن جواب نمی‌دهد.",None),
    ("Six fifty is expensive.","BAD","به سؤال جواب نداده‌اید و ممکن است بی‌ادبانه برسد.",None)],
    "مؤدبانه",["For here, please.","I'll take it to go."],"به سؤال انتخابی با Yes/No جواب ندهید.","s3",listen=True),
  TY("s3","او می‌پرسد چیز دیگری می‌خواهید یا نه.","Anything else?",
    ["that's all","that's it","that'll be all","nothing else","no, thanks","no thanks","that's all, thanks","that's it, thanks"],
    "عالی! این جواب‌ها در کافه رایج‌اند.","یک جواب کوتاه مثل «That's all, thanks.» بنویسید.",
    "مؤدبانه",["That's it, thank you.","No, that's all."],"فقط «No» (بدون توضیح) خشک است.",None,hint="مثل «That's all, thanks.»"),
]),
S("making_plans","برنامه‌ریزی","Making Plans","هماهنگی قرار آخر هفته و بازیابی بعد از پاسخ نامناسب.",2,"plans",[
  CH("s1","همکارتان می‌پرسد آخر هفته آزادید یا نه.","Are you free this Saturday?",[
    ("I think so. What did you have in mind?","BEST","هم محتاطانه جواب می‌دهید و هم علاقه نشان می‌دهید.",None),
    ("Yes.","OK","درست است ولی گفتگو را جلو نمی‌برد.",None),
    ("I never have free time.","BAD","لحنش تند و بی‌علاقه است و او را ناراحت می‌کند.","r1")],
    "خودمانی",["Maybe. What's up?","Depends. What's the plan?"],"با جواب‌های منفی و تند رابطه را خراب نکنید.","s2"),
  CH("r1","او ناراحت شده است؛ باید گفتگو را اصلاح کنید.","Oh, sorry. I didn't mean to bother you.",[
    ("Sorry, that came out wrong. I'm just stressed. Saturday could work!","BEST","عذرخواهی کوتاه و ترمیم رابطه؛ بعد دوباره علاقه نشان می‌دهید.",None),
    ("It's fine.","OK","گفتگو را بسته می‌کند ولی مشکل حل نمی‌شود.",None),
    ("You always bother me.","BAD","وضع را بدتر می‌کند.",None)],
    "مؤدبانه",["I'm sorry, I was rude.","Sorry, bad day."],"سرزنش کردن گفتگو را وخیم‌تر می‌کند.","s2"),
  TY("s2","او پیشنهاد می‌دهد ساعت هفت همدیگر را ببینید.","Great! How about seven?",
    ["sounds good","sounds great","works for me","that works","i'm down","perfect","seven works","7 works","okay","ok"],
    "عالی! همین عبارت‌ها قرار را قطعی می‌کنند.","با «Sounds good» یا «That works for me» قبول کنید.",
    "خودمانی",["Seven works for me.","I'm down."],"پاسخ مبهم مثل «maybe» قرار را قطعی نمی‌کند.","s3",expr="im_down"),
  OR("s3","نمی‌دانید دقیقاً کجا بروید و می‌خواهید انعطاف نشان دهید.",None,"Let's play it by ear and see how we feel.",
    "درست! این جمله انعطاف را نشان می‌دهد.","ترتیب اصطلاح «play it by ear» را بررسی کنید.",
    "خودمانی",["Let's see how it goes."],"برای برنامه‌های مهم و ساعت‌دار مناسب نیست.",None,expr="play_it_by_ear"),
]),
S("invitation","قبول یا رد دعوت","Accepting or Declining an Invitation","رد کردن مؤدبانه و قبول کردن گرم.",2,"invitations",[
  CH("s1","همسایه‌تان شما را به مهمانی کوچک جمعه دعوت می‌کند، ولی قرار دیگری دارید.","We're having a small party on Friday. Wanna come?",[
    ("Thanks for inviting me! I'd love to, but I already have plans.","BEST","هم تشکر می‌کنید، هم دلیل می‌آورید و هم لحن گرمی دارید.",None),
    ("No.","BAD","خیلی کوتاه و سرد است.",None),
    ("Parties are boring.","BAD","نظر شخصی را با توهین ترکیب می‌کند.",None)],
    "مؤدبانه",["Thanks, but I can't make it.","I wish I could, but I'm busy."],"بدون دلیل یا تشکر رد نکنید.","s2",listen=True),
  FI("s2","او باز هم اصرار می‌کند؛ می‌خواهید مؤدبانه توضیح دهید که اهل مهمانی نیستید.","Come on, it'll be fun!",
    "Thanks, but parties are just not my ____ of tea.",["cup"],
    "درست! «not my cup of tea» یعنی سلیقه‌ی من نیست.","کلمه‌ی گمشده «cup» است؛ اصطلاح «not my cup of tea».",
    "مؤدبانه",["It's not really my thing."],"برای اتفاق جدی مثل مرگ استفاده نکنید.","s3",expr="not_my_cup_of_tea"),
  TY("s3","او یک ماه بعد دوباره دعوتتان می‌کند و این‌بار می‌خواهید قبول کنید.","How about a movie night next week? You in?",
    ["i'm down","count me in","i'll be there","sounds good","i'd love to","i'm in","sure","yes"],
    "عالی! پذیرفتن گرم و واضح.","با «I'm in» یا «I'd love to» قبول کنید.",
    "خودمانی",["I'd love to.","Sounds fun."],"پاسخ مبهم مثل «Maybe» ممکن است رد کردن به نظر برسد.",None,expr="im_down"),
]),
S("surprising_news","واکنش به خبر غافلگیرکننده","Reacting to Surprising News","نشان دادن شادی و تعجب به‌شکل طبیعی.",2,"reactions",[
  CH("s1","دوستتان خبر خوشی می‌دهد.","Guess what? I got the job!",[
    ("No way! That's amazing, congrats!","BEST","هم تعجب نشان می‌دهید و هم تبریک می‌گویید.",None),
    ("Okay.","OK","بی‌تفاوت به نظر می‌رسد.",None),
    ("That's not a big deal.","BAD","شادی او را کوچک می‌کند.","r1")],
    "خودمانی",["That's awesome!","I'm so happy for you!"],"خبر خوب را کوچک نشان ندهید.","s2",listen=True),
  CH("r1","او ناراحت می‌شود؛ باید جبران کنید.","Oh… I thought you'd be happier for me.",[
    ("You're right, I'm sorry. Congrats, I'm really proud of you!","BEST","اعتراف به اشتباه و تبریک صمیمانه.",None),
    ("Whatever.","BAD","بی‌اعتنایی است و رابطه را خراب می‌کند.",None),
    ("It's fine.","OK","مشکل را حل نمی‌کند.",None)],
    "مؤدبانه",["Sorry, I was surprised. Congrats!"],"بی‌اعتنایی نکنید.","s2"),
  TY("s2","او می‌گوید حقوقش از انتظارش هم بیشتر است.","And they're paying more than I expected.",
    ["are you kidding","are you kidding me","you're kidding","no way","seriously","that's awesome","that's amazing","wow","are you serious"],
    "عالی! تعجب مثبت را نشان می‌دهید.","یک واکنش تعجبی مثل «No way!» یا «Are you kidding me?» بنویسید.",
    "خودمانی",["Seriously?","That's incredible!"],"با لحن منفی «Are you kidding me?» به اعتراض تبدیل می‌شود.","s3",expr="are_you_kidding"),
  OR("s3","می‌خواهید به او بگویید حقش بوده است.",None,"Congrats, you totally deserve it!",
    "درست! جمله‌ی شاد و طبیعی.","ترتیب کلمات را دوباره بررسی کنید.",
    "خودمانی",["You've earned it!"],None,None),
]),
S("frustration","ابراز ناامیدی","Expressing Frustration","بیان ناراحتی بدون دعوا.",3,"emotions",[
  CH("s1","دوستتان می‌بیند که ناراحتید.","You look upset. What happened?",[
    ("Ugh, I'm just swamped and my plans fell through.","BEST","احساس را صادقانه و بدون سرزنش بیان می‌کنید.",None),
    ("Nothing.","OK","مؤدبانه ولی گفتگو را می‌بندد؛ ممکن است نگران بماند.",None),
    ("Leave me alone, it's your fault!","BAD","سرزنش بی‌دلیل رابطه را خراب می‌کند.","r1")],
    "خودمانی",["I'm kind of stressed.","I'm having a rough day."],"دیگران را بدون دلیل سرزنش نکنید.","s2",expr="swamped"),
  CH("r1","او ناراحت شده و دور می‌شود.","Wow. Okay. I was just trying to help.",[
    ("Sorry, I took it out on you. It's not your fault.","BEST","اشتباه را می‌پذیرید و مشکل را به او نسبت نمی‌دهید.",None),
    ("Good.","BAD","بی‌توجهی است.",None),
    ("You don't understand.","OK","ممکن است درست باشد ولی دفاعی است و مشکل را حل نمی‌کند.",None)],
    "مؤدبانه",["I'm sorry, I'm just stressed."],"احساسات منفی را روی دیگران خالی نکنید.","s2"),
  FI("s2","کار تمام نمی‌شود و می‌خواهید بگویید دیگر خسته‌اید.","Do you need a break?",
    "Yeah, I'm really ____ out. Can we call it a day?",["burned","burnt"],
    "درست! «burned out» یعنی از پا افتاده.","کلمه‌ی گمشده «burned» است (burned out).",
    "خودمانی",["I'm exhausted."],"برای مشکل سلامتی جدی، صراحت بیشتری لازم است.","s3",expr="burn_out"),
  OR("s3","می‌خواهید کمی مدارا بخواهید.",None,"Can you cut me some slack today?",
    "درست! درخواست نرم و محترمانه است.","ترتیب جمله‌ی سؤالی «Can you…» را بررسی کنید.",
    "خودمانی / مؤدبانه",["Could you give me a break today?"],"به مافوق با احتیاط بگویید.",None,expr="cut_me_some_slack"),
]),
S("disagree","مخالفت محترمانه","Disagreeing Respectfully","نظر مخالف دادن بدون توهین.",3,"opinions",[
  CH("s1","دوستتان نظرش را درباره‌ی پیتزا می‌گوید و شما مخالفید.","I think pineapple on pizza is the best.",[
    ("Fair enough, but it's not my cup of tea.","BEST","هم نظر او را محترم می‌شمارید و هم سلیقه‌ی خودتان را مؤدبانه می‌گویید.",None),
    ("I disagree.","OK","مؤدبانه ولی خشک است؛ دلیل یا نرم‌کننده اضافه کنید.",None),
    ("That's a stupid opinion.","BAD","نظر را مستقیماً تحقیر می‌کند.","r1")],
    "مؤدبانه / خودمانی",["I see your point, but I'm not a fan.","Interesting, but I prefer plain."],"نظر را تحقیر نکنید؛ از «I think / to me» استفاده کنید.","s2",expr="fair_enough"),
  CH("r1","او می‌رنجد.","Wow, that was harsh.",[
    ("Sorry, that was rude. I just prefer it plain.","BEST","اشتباه را می‌پذیرید و نظرتان را دوباره محترمانه می‌گویید.",None),
    ("It's just pizza.","OK","مسئله را کوچک می‌کند؛ عذرخواهی ندارد.",None),
    ("You're too sensitive.","BAD","وضع را بدتر می‌کند.",None)],
    "مؤدبانه",["Sorry, I was joking."],"دیگران را «حساس» خطاب نکنید.","s2"),
  TY("s2","او اصرار می‌کند یک تکه امتحان کنید، ولی شما نمی‌خواهید.","Come on, just try one bite!",
    ["maybe next time","i'll pass","i'll pass, thanks","no thanks","no, thanks","i'll pass, but thanks","not today","i'm good"],
    "عالی! رد کردن مؤدبانه.","با «I'll pass, thanks» یا «Maybe next time» رد کنید.",
    "مؤدبانه",["I'm good, thanks.","Not today, thanks."],"فقط «No» خیلی تند است.","s3"),
  OR("s3","می‌خواهید در پایان بگویید که هنوز مخالفید ولی احترام می‌گذارید.",None,"I see your point, but I still disagree.",
    "درست! محترمانه و روشن.","ترتیب جمله را دوباره بررسی کنید.",
    "مؤدبانه",["I get it, but I'm not convinced."],None,None),
]),
S("jokes","شوخی کردن","Making Jokes","فهمیدن و جواب دادن به شوخی.",3,"humor",[
  CH("s1","دوستتان شوخی می‌کند.","I'd tell you a joke about pizza, but it's too cheesy.",[
    ("Ha! That was cheesy, but good.","BEST","واکنش مثبت و بامزه؛ «cheesy» یعنی «کلیشه‌ای/لوس».",None),
    ("Why?","OK","شوخی را نفهمیده‌اید؛ «cheesy» هم پنیری و هم لوس است.",None),
    ("That's not funny at all.","BAD","شوخی را تحقیر می‌کند.",None)],
    "خودمانی",["Good one!","Haha, nice."],"شوخی دوستانه را جدی نگیرید.","s2",listen=True),
  TY("s2","او می‌پرسد خنده‌دار بود یا نه.","Was that funny or what?",
    ["ha","good one","that was funny","that was a good one","you're hilarious","you crack me up","that's hilarious","nice one","haha"],
    "عالی! واکنش شاد.","یک جواب کوتاه مثل «Good one!» بنویسید.",
    "خودمانی",["That cracked me up.","You're hilarious."],"اگر خنده‌دار نبود، مؤدبانه بگویید «Nice try!».","s3"),
  OR("s3","می‌خواهید اعتراف کنید که شوخی واقعاً خنده‌دار بود.",None,"Okay, that was actually pretty funny.",
    "درست! لحن شوخ و صمیمی.","ترتیب جمله‌ی «that was actually…» را بررسی کنید.",
    "خودمانی",["That was kind of funny."],None,None),
]),
S("sarcasm","درک طعنه","Understanding Sarcasm","فهمیدن منظور واقعی در طعنه.",4,"humor",[
  CH("s1","همکارتان با لحن خسته می‌گوید:","Oh great, another Monday. Just what I needed.",[
    ("He's annoyed; he doesn't really think Monday is great.","BEST","«great» در اینجا طعنه است و یعنی برعکس.",None),
    ("He's really happy about Monday.","BAD","طعنه را تحت‌اللفظی فهمیده‌اید.",None),
    ("He's asking for help.","OK","منظورش درخواست کمک نیست؛ فقط ناراحتی‌اش را نشان می‌دهد.",None)],
    "طعنه‌آمیز",["He's frustrated.","He's being sarcastic."],"طعنه را تحت‌اللفظی نفهمید.","s2",listen=True),
  CH("s2","همکارتان بعد از اینکه ماشین‌تان را بد پارک کرده‌اید می‌گوید:","Nice parking job, genius.",[
    ("Ha, okay, okay. My bad.","BEST","طعنه را فهمیده‌اید و با شوخی عذرخواهی می‌کنید.",None),
    ("Thank you!","OK","طعنه را تعریف فهمیده‌اید؛ ممکن است موقعیت را خراب کند.",None),
    ("Why are you insulting me?","BAD","شوخی طعنه‌آمیز را جدی می‌گیرد.",None)],
    "خودمانی",["Yeah, yeah, I know.","Alright, point taken."],"اگر طرف دوست نیست، طعنه را جدی بگیرید و واضح بپرسید.","s3",expr="my_bad"),
  OR("s3","می‌خواهید طعنه بزنید.",None,"Yeah, right, like that's gonna happen.",
    "درست! «Yeah, right» با لحن طعنه یعنی «حتماً! (نه)».","ترتیب کلمات را بررسی کنید.",
    "طعنه‌آمیز / خودمانی",["Sure, that'll happen."],"با غریبه‌ها یا در محیط رسمی طعنه نزنید.",None,expr="gonna"),
]),
S("workplace","مکالمه‌ی غیررسمی محل کار","Casual Workplace Chat","هماهنگی و اطلاع‌رسانی در محل کار.",3,"work",[
  CH("s1","همکارتان خبری مهم دارد.","Got a minute? Just a heads-up, the client moved the deadline.",[
    ("Thanks for the heads-up. What's the new deadline?","BEST","هم تشکر می‌کنید و هم سؤال کاربردی می‌پرسید.",None),
    ("Okay.","OK","کوتاه و بی‌علاقه؛ اطلاعات بیشتری نمی‌گیرید.",None),
    ("That's your problem, not mine.","BAD","مسئولیت را رد می‌کند و حس همکاری را از بین می‌برد.",None)],
    "نیمه‌رسمی",["Thanks for letting me know.","Appreciate it."],"مسئولیت را بدون دلیل رد نکنید.","s2",expr="heads_up"),
  FI("s2","می‌خواهید مؤدبانه بگویید الان وقت ندارید.","Can you look at this now?",
    "Sorry, I'm ____ right now. Can we talk after lunch?",["swamped"],
    "درست! «swamped» یعنی غرق کار.","کلمه‌ی گمشده «swamped» است.",
    "نیمه‌رسمی",["I'm tied up right now."],"با مدیر ارشد «I'm busy» ساده‌تر و رسمی‌تر است.","s3",expr="swamped"),
  TY("s3","مدیر می‌پرسد گزارش تا ساعت پنج آماده می‌شود یا نه.","Can you finish the report by five?",
    ["i'll figure it out","i'll do my best","sure","no problem","i'm on it","i'll get it done","will do","yes"],
    "عالی! این جواب‌ها حرفه‌ای و مثبت‌اند.","یک جواب حرفه‌ای مثل «I'll do my best» بنویسید.",
    "نیمه‌رسمی",["I'm on it.","Will do."],"اگر نمی‌توانید، صادقانه زمان واقعی را بگویید.",None,expr="figure_out"),
]),
S("clarification","درخواست توضیح","Asking for Clarification","وقتی چیزی را نفهمیده‌اید.",2,"clarification",[
  CH("s1","همکارتان تند حرف می‌زند و یک اختصار می‌گوید.","Could you send me the file by EOD?",[
    ("Sorry, what does EOD mean?","BEST","پرسیدن معنی اختصار کاملاً طبیعی است.",None),
    ("Pardon?","OK","مؤدبانه ولی درباره‌ی بخش ناآشنا دقیق نیست؛ ممکن است همان جمله را تکرار کند.",None),
    ("Yes.","BAD","ادعای فهمیدن می‌کنید ولی نفهمیده‌اید؛ ممکن است اشتباه شود.",None)],
    "مؤدبانه",["Sorry, could you explain what that means?","I didn't catch that."],"وانمود نکنید که فهمیده‌اید.","s2",listen=True),
  TY("s2","او توضیح می‌دهد EOD یعنی پایان روز.","It means end of day. Is that okay?",
    ["sure","yes","that works","sounds good","no problem","okay","ok","got it"],
    "عالی! مؤدبانه تأیید می‌کنید.","یک جواب کوتاه مثل «Got it, thanks.» بنویسید.",
    "مؤدبانه",["Got it, thanks.","That works."],None,"s3"),
  OR("s3","می‌خواهید از او بخواهید جمله را دوباره بگوید.",None,"Sorry, could you say that again, please?",
    "درست! مؤدبانه‌ترین شکل درخواست تکرار.","ترتیب جمله را دوباره بررسی کنید.",
    "مؤدبانه",["Sorry, I didn't catch that."],"«What?» تنها تند است.",None),
]),
S("recovery","ترمیم مکالمه‌ی سخت","Recovering a Difficult Conversation","وقتی حرف‌تان آزار داده است.",4,"repair",[
  CH("s1","دوستتان از حرف شما ناراحت شده است.","Why did you say that? That was rude.",[
    ("You're right, I'm sorry. That came out wrong.","BEST","اشتباه را می‌پذیرید و صادقانه عذرخواهی می‌کنید.",None),
    ("It was a joke.","OK","شاید درست باشد ولی احساس او را نادیده می‌گیرد.",None),
    ("You're too sensitive.","BAD","مسئولیت را به او برمی‌گرداند.","r1")],
    "مؤدبانه",["I'm sorry, I didn't mean it that way.","I shouldn't have said that."],"او را «حساس» خطاب نکنید.","s2"),
  CH("r1","او می‌گوید دیگر نمی‌خواهد حرف بزند.","Forget it. I don't want to talk.",[
    ("I'm sorry. I was wrong to say that. Can we start over?","BEST","مسئولیت را می‌پذیرید و راهی برای شروع دوباره می‌دهید.",None),
    ("Fine, don't talk then.","BAD","بحث را تلخ‌تر می‌کند.",None),
    ("Whatever.","BAD","بی‌اعتنایی است.",None)],
    "مؤدبانه",["I'm sorry, let's talk later."],"بی‌اعتنایی نکنید.","s2"),
  TY("s2","او کمی آرام می‌شود و می‌گوید قدردان عذرخواهی است.","Okay. Thanks for saying that.",
    ["thanks for understanding","thanks for listening","thank you for understanding","i appreciate it","no worries","thanks","thank you"],
    "عالی! ترمیم رابطه کامل می‌شود.","یک جواب مثل «Thanks for understanding.» بنویسید.",
    "مؤدبانه",["I appreciate it.","Thank you for listening."],None,"s3"),
  OR("s3","می‌خواهید توضیح بدهید که قصد ناراحت کردنش را نداشتید.",None,"I didn't mean to upset you.",
    "درست! ساده و صمیمانه.","ترتیب جمله را دوباره بررسی کنید.",
    "مؤدبانه",["I never meant to hurt you."],None,None),
]),
]
