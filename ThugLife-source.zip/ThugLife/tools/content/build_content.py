# -*- coding: utf-8 -*-
"""Deterministically builds app/src/main/assets/content/curriculum.json from the authored sources.
Run:  python3 tools/content/build_content.py
All expression, lesson, scenario, lyric and feedback text is authored in expr_a.py / expr_b.py /
lessons.py / scenarios.py. Exercises of the repetitive kinds (recognition, listening-identify,
typed recall, context match, word order, dictation, slang decoder, natural-or-unnatural) are derived
from that authored data with a seeded RNG so that distractors never change between runs."""
import hashlib, json, os, random, re, sys
sys.path.insert(0, os.path.dirname(__file__))
from expr_a import EVERYDAY, RAP
from expr_b import ROCK, POP
from lessons import LESSONS
from scenarios import SCENARIOS

CONTENT_VERSION = 1
EXPRS = EVERYDAY + RAP + ROCK + POP
BY_ID = {e["id"]: e for e in EXPRS}
LESSON_OF = {}
for l in LESSONS:
    for i, eid in enumerate(l["exprs"]):
        LESSON_OF[eid] = (l["id"], i)

def xid(e): return "x_" + e
def rng(key): return random.Random(int(hashlib.sha1(key.encode()).hexdigest()[:12], 16))

def strip_ellipsis(s): return s.replace("…", "").replace("...", "").strip()

STOP_START = ["i'm ", "it's ", "he's ", "she's ", "that's ", "you ", "i've ", "let's ", "stop ", "just a ", "just ", "do you ", "they ", "we ", "my ", "don't ", "you have to ", "i have ", "i "]
def core_of(en):
    t = strip_ellipsis(en)
    t_norm = re.sub(r"[^\w' ]", "", t.lower()).strip()
    c = t_norm
    changed = True
    while changed:
        changed = False
        for p in STOP_START:
            if c.startswith(p) and len(c.split()) > 2:
                c = c[len(p):]; changed = True; break
    return c.strip()


RECALL_KEYS = {
 "whats_up":["What's up?","what is up"],"no_worries":["No worries."],"im_down":["I'm down.","I am down"],
 "gonna":["I'm gonna","I am gonna","gonna"],"wanna":["Do you wanna","wanna","you wanna"],
 "gotta":["I gotta go","gotta go","I gotta","gotta"],"hang_out":["Let's hang out","hang out"],
 "figure_out":["I'll figure it out","figure it out","I will figure it out"],"swamped":["I'm swamped","I am swamped","swamped"],
 "under_the_weather":["I'm under the weather","under the weather","I am under the weather"],
 "call_it_a_day":["Let's call it a day","call it a day"],"spill_the_beans":["Spill the beans"],
 "piece_of_cake":["It's a piece of cake","a piece of cake","piece of cake","it is a piece of cake"],
 "heads_up":["Just a heads-up","a heads up","heads up"],"cut_me_some_slack":["Cut me some slack"],
 "not_my_cup_of_tea":["Not my cup of tea","it's not my cup of tea","not really my cup of tea"],"my_bad":["My bad"],
 "beat_around_the_bush":["Stop beating around the bush","beating around the bush","beat around the bush"],
 "are_you_kidding":["Are you kidding me","are you kidding","you kidding me"],"fair_enough":["Fair enough"],
 "keep_it_real":["Keep it real"],"hit_me_up":["Hit me up"],"flex":["Stop flexing","flexing"],"no_cap":["No cap"],
 "dope":["That's dope","that is dope","dope"],"squad":["my squad","the squad","squad"],
 "grind":["I'm on the grind","on the grind","on my grind","I am on the grind"],
 "salty":["He's salty","she's salty","he is salty","salty"],
 "throw_shade":["Don't throw shade","throw shade","do not throw shade"],
 "lowkey":["I'm lowkey tired","lowkey tired","low-key tired","lowkey"],
 "vibe":["I like the vibe","like the vibe","I love the vibe","the vibe"],"hustle":["Respect the hustle","the hustle"],
 "mic_drop":["Mic drop","mic-drop"],"got_your_back":["I've got your back","got your back","I have got your back","I got your back"],
 "stay_in_your_lane":["Stay in your lane"],"rock_on":["Rock on"],"turn_it_up":["Turn it up"],
 "bring_down_the_house":["They brought the house down","brought the house down","brought down the house","bring the house down"],
 "stage_fright":["I have stage fright","stage fright","I've got stage fright","I got stage fright"],
 "hit_the_road":["Let's hit the road","hit the road"],"play_it_by_ear":["Let's play it by ear","play it by ear"],
 "face_the_music":["You have to face the music","face the music","you'll have to face the music"],
 "go_all_out":["Go all out"],"burn_out":["I'm burned out","I'm burnt out","burned out","burnt out","I am burned out"],
 "sell_out":["He sold out","sold out","sell out"],"rock_bottom":["He hit rock bottom","hit rock bottom","rock bottom"],
 "wake_up_call":["It was a wake-up call","a wake-up call","wake-up call"],
 "crush_on":["I have a crush on her","I have a crush on him","a crush on her","a crush on him","have a crush on"],
 "head_over_heels":["I'm head over heels","head over heels","I am head over heels"],
 "catchy":["That song is so catchy","so catchy","it's so catchy","catchy"],
 "on_repeat":["It's been on repeat","on repeat","been on repeat"],
 "break_up":["We broke up","broke up","we've broken up"],
 "get_over":["I'm getting over it","getting over it","get over it"],
 "move_on":["It's time to move on","time to move on","move on"],"ghost":["He ghosted me","she ghosted me","ghosted me","ghosted"],
 "guilty_pleasure":["It's my guilty pleasure","my guilty pleasure","guilty pleasure"],
 "out_of_my_league":["She's out of my league","he's out of my league","out of my league"],
 "glow_up":["She had a glow-up","he had a glow-up","a glow-up","glow-up"],
 "play_it_cool":["Play it cool"],"slay":["You slay","you slayed","she slays","slayed","slay"],
}
missing = [e["id"] for e in EXPRS if e["id"] not in RECALL_KEYS]
assert not missing, missing

# ---------- audio assets (device TTS; no fake files) ----------
audio = {}
def audio_for(text):
    t = strip_ellipsis(text)
    aid = "tts_" + hashlib.sha1(t.encode()).hexdigest()[:10]
    if aid not in audio:
        audio[aid] = dict(id=aid, kind="TTS", text=t, resource=None, locale="en-US",
                          attribution="تولید‌شده با موتور تبدیل متن به گفتار دستگاه؛ فایل صوتی همراه برنامه نیست.")
    return aid

exercises = []
def add_ex(**k):
    base = dict(type=None, skill=None, expr=None, lesson=None, diff=1, promptFa="", promptEn=None, options=None,
                accepted=[], tokens=None, explanationFa="", audio=None, timeLimit=None, order=0)
    base.update(k); exercises.append(base)

def distractors(e, key, pool, field, n=3, prefer_other_topic=True):
    r = rng(key)
    cands = [x for x in pool if x["id"] != e["id"] and x[field] != e[field]]
    if prefer_other_topic:
        diff_topic = [x for x in cands if x["topic"] != e["topic"]]
        if len(diff_topic) >= n: cands = diff_topic
    r.shuffle(cands)
    out, seen = [], {e[field]}
    for x in cands:
        if x[field] not in seen:
            out.append(x[field]); seen.add(x[field])
        if len(out) == n: break
    return out

def shuffled_options(correct, others, key):
    opts = [correct] + others
    rng("opt:" + key).shuffle(opts)
    return opts

# ---------- per-expression exercises ----------
for e in EXPRS:
    lid, pos = LESSON_OF[e["id"]]
    L = "l_" + lid
    X = xid(e["id"])
    en = strip_ellipsis(e["en"])
    # 1. meaning recognition
    opts = shuffled_options(e["fa"], distractors(e, "rec:" + e["id"], EXPRS, "fa"), "rec:" + e["id"])
    add_ex(id="rec_" + e["id"], type="MEANING_RECOGNITION", skill="RECOGNITION", expr=X, lesson=L, diff=e["diff"],
           promptFa="معنی این عبارت چیست؟", promptEn=en, options=opts, accepted=[e["fa"]],
           explanationFa=e["ctx"], timeLimit=12, order=10 + pos)
    # 2. listen & identify
    others = distractors(dict(e, en=en), "lis:" + e["id"], [dict(x, en=strip_ellipsis(x["en"])) for x in EXPRS], "en", prefer_other_topic=False)
    opts = shuffled_options(en, others, "lis:" + e["id"])
    add_ex(id="lis_" + e["id"], type="LISTEN_IDENTIFY", skill="LISTENING", expr=X, lesson=L, diff=e["diff"],
           promptFa="عبارت را بشنوید و گزینه‌ی درست را انتخاب کنید.", options=opts, accepted=[en],
           explanationFa="شنیده‌شده: «%s» یعنی «%s»." % (en, e["fa"]), audio=audio_for(en), timeLimit=15, order=20 + pos)
    # 3. typed recall
    core = RECALL_KEYS[e["id"]][0]
    acc = list(RECALL_KEYS[e["id"]])
    add_ex(id="rcl_" + e["id"], type="RECALL_TYPED", skill="RECALL", expr=X, lesson=L, diff=e["diff"],
           promptFa="این معنی را به انگلیسی بنویسید: «%s»" % e["fa"], promptEn=None, accepted=acc,
           explanationFa="پاسخ: «%s». %s" % (en, e["ctx"]), timeLimit=25, order=30 + pos)
    # 4. context match
    others = distractors(dict(e, en=en), "sit:" + e["id"], [dict(x, en=strip_ellipsis(x["en"])) for x in EXPRS], "en")
    opts = shuffled_options(en, others, "sit:" + e["id"])
    add_ex(id="sit_" + e["id"], type="CONTEXT_MATCH", skill="CONTEXT", expr=X, lesson=L, diff=e["diff"],
           promptFa="کدام عبارت برای این موقعیت مناسب‌تر است؟\n" + e["sit"], options=opts, accepted=[en],
           explanationFa="«%s» مناسب است. %s" % (en, e["warn"]), timeLimit=20, order=40 + pos)
    # 5. sentence reconstruction
    for si, s in enumerate(e["ex"]):
        toks = s.split()
        if 3 <= len(toks) <= 9 and "—" not in s:
            sh = toks[:]
            r = rng("ord:%s:%d" % (e["id"], si))
            for _ in range(10):
                r.shuffle(sh)
                if sh != toks: break
            add_ex(id="ord_" + e["id"], type="SENTENCE_RECONSTRUCTION", skill="PRODUCTION", expr=X, lesson=L, diff=e["diff"],
                   promptFa="کلمه‌ها را به ترتیب درست بچینید.", tokens=sh, accepted=[s],
                   explanationFa="جمله‌ی درست: «%s»" % s, timeLimit=30, order=50 + pos)
            break
    # 6. typed production (accepts the target and valid alternatives)
    acc = list(RECALL_KEYS[e["id"]]) + [strip_ellipsis(a) for a in e["alt"]]
    acc = [a for i, a in enumerate(acc) if a and a not in acc[:i]]
    add_ex(id="prod_" + e["id"], type="TYPED_PRODUCTION", skill="PRODUCTION", expr=X, lesson=L, diff=min(5, e["diff"] + 1),
           promptFa="در این موقعیت چه می‌گویید؟ (به انگلیسی بنویسید)\n" + e["sit"], accepted=acc,
           explanationFa="عبارت هدف: «%s». جایگزین‌های طبیعی: %s." % (en, "، ".join(e["alt"])), timeLimit=40, order=60 + pos)
    # 7. slang decoder
    if e["reg"] in ("SLANG", "MILD_RUDE"):
        opts = shuffled_options(e["fa"], distractors(e, "sd:" + e["id"], EXPRS, "fa"), "sd:" + e["id"])
        add_ex(id="sd_" + e["id"], type="SLANG_DECODER", skill="RECOGNITION", expr=X, lesson=L, diff=e["diff"],
               promptFa="در این جمله، گوینده چه می‌گوید؟", promptEn=e["ex"][0], options=opts, accepted=[e["fa"]],
               explanationFa=e["ctx"] + " " + e["warn"], timeLimit=15, order=70 + pos)
    # 8. natural or unnatural
    if e["bad"]:
        add_ex(id="natA_" + e["id"], type="NATURAL_OR_UNNATURAL", skill="CONTEXT", expr=X, lesson=L, diff=e["diff"],
               promptFa="این جمله طبیعی و درست است؟", promptEn=e["ex"][0], options=["NATURAL", "UNNATURAL"], accepted=["NATURAL"],
               explanationFa="طبیعی است: «%s» با همین ساختار و لحن به‌کار می‌رود." % e["ex"][0], timeLimit=10, order=80 + pos)
        add_ex(id="natB_" + e["id"], type="NATURAL_OR_UNNATURAL", skill="CONTEXT", expr=X, lesson=L, diff=e["diff"],
               promptFa="این جمله طبیعی و درست است؟", promptEn=e["bad"][0], options=["NATURAL", "UNNATURAL"], accepted=["UNNATURAL"],
               explanationFa=e["bad"][1], timeLimit=10, order=85 + pos)
    # 9. dictation (audio memory)
    s0 = e["ex"][0]
    if len(s0.split()) <= 8 and "—" not in s0:
        add_ex(id="dic_" + e["id"], type="AUDIO_MEMORY", skill="LISTENING", expr=X, lesson=L, diff=min(5, e["diff"] + 1),
               promptFa="جمله را بشنوید و همان‌طور که می‌شنوید بنویسید.", accepted=[s0],
               explanationFa="جمله‌ی درست: «%s»" % s0, audio=audio_for(s0), timeLimit=40, order=90 + pos)

# ---------- lesson-level exercises ----------
for l in LESSONS:
    L = "l_" + l["id"]
    first = BY_ID[l["exprs"][0]]
    add_ex(id="lyr_" + l["id"], type="MISSING_PHRASE", skill="RECALL", lesson=L, expr=None,
           diff=l["diff"], promptFa="جای خالی در این بند (اصیل و ساخته‌شده برای این برنامه) را کامل کنید.", promptEn=l["blank"]["line"],
           accepted=l["blank"]["answers"], explanationFa="بند کامل: «%s»" % l["blank"]["line"].replace("____", l["blank"]["answers"][0]),
           audio=audio_for(l["blank"]["line"].replace("____", l["blank"]["answers"][0])), timeLimit=25, order=5)
    ls = l["listen"]
    add_ex(id="lc_" + l["id"], type="LISTEN_COMPREHENSION", skill="LISTENING", lesson=L, diff=l["diff"],
           promptFa=ls["q"], options=ls["options"], accepted=[ls["options"][ls["answer"]]], explanationFa=ls["why"],
           audio=audio_for(ls["text"]), timeLimit=25, order=1)

# ---------- comeback exercises from scenario choice steps ----------
for sc in SCENARIOS:
    for st in sc["steps"]:
        if st["kind"] in ("CHOICE", "LISTEN_CHOICE") and st["id"] != "r1":
            best = [o for o in st["options"] if o["q"] == "BEST"]
            if len(best) == 1 and not st["sit"].startswith("او ") and st["partner"]:
                opts = [o["t"] for o in st["options"]]
                rng("cb:%s:%s" % (sc["id"], st["id"])).shuffle(opts)
                add_ex(id="cb_%s_%s" % (sc["id"], st["id"]), type="CONVERSATION_COMEBACK", skill="CONTEXT", diff=sc["diff"],
                       promptFa="بهترین جواب را انتخاب کنید.\n" + st["sit"], promptEn=st["partner"], options=opts,
                       accepted=[best[0]["t"]], explanationFa=best[0]["fb"], audio=audio_for(st["partner"]), timeLimit=20, order=0)

# ---------- scenarios ----------
scen_rows, step_rows = [], []
for sc in SCENARIOS:
    sid = "sc_" + sc["id"]
    scen_rows.append(dict(id=sid, titleFa=sc["titleFa"], titleEn=sc["titleEn"], descFa=sc["descFa"], diff=sc["diff"],
                          topic=sc["topic"], start=sid + "_" + sc["steps"][0]["id"], steps=len(sc["steps"])))
    for pos, st in enumerate(sc["steps"]):
        row = dict(id=sid + "_" + st["id"], scenario=sid, pos=pos, kind=st["kind"], situationFa=st["sit"],
                   partner=st["partner"], audio=audio_for(st["partner"]) if st["partner"] else None,
                   options=None, accepted=None, tokens=None, prompt=None,
                   okFa=st.get("ok"), badFa=st.get("bad"), hint=st.get("hint"),
                   formalFa=st["formal"], alts=st["alts"], avoidFa=st["avoid"],
                   next=(sid + "_" + st["next"]) if st["next"] else None, expr=xid(st["expr"]) if st.get("expr") else None)
        if st["kind"] in ("CHOICE", "LISTEN_CHOICE"):
            row["options"] = [dict(t=o["t"], q=o["q"], fb=o["fb"], next=(sid + "_" + o["next"]) if o["next"] else None) for o in st["options"]]
        elif st["kind"] == "TYPED":
            row["accepted"] = st["accepted"]
        elif st["kind"] == "FILL":
            row["accepted"] = st["accepted"]; row["prompt"] = st["prompt"]
        elif st["kind"] == "ORDER":
            toks = st["sentence"].split(); sh = toks[:]
            r = rng("sord:" + row["id"])
            for _ in range(10):
                r.shuffle(sh)
                if sh != toks: break
            row["tokens"] = sh; row["accepted"] = [st["sentence"]]
        step_rows.append(row)

# ---------- assemble ----------
exprs_out = []
for e in EXPRS:
    exprs_out.append(dict(id=xid(e["id"]), english=e["en"], persian=e["fa"], context=e["ctx"], register=e["reg"],
        topic=e["topic"], difficulty=e["diff"], examples=e["ex"], alternatives=e["alt"], warning=e["warn"],
        pronunciation=e["pron"], audio=audio_for(e["en"]), source="محتوای اصیل Thug Life (نوشته‌شده برای این برنامه)",
        tags=e["tags"], pathway=e["pathway"], situationFa=e["sit"],
        unnatural=(dict(text=e["bad"][0], reasonFa=e["bad"][1]) if e["bad"] else None)))
lessons_out, le_rows = [], []
for l in LESSONS:
    lessons_out.append(dict(id="l_" + l["id"], pathway=l["pathway"], order=l["order"], titleFa=l["titleFa"], titleEn=l["titleEn"],
        descFa=l["descFa"], introFa=l["introFa"], difficulty=l["diff"], minutes=l["minutes"], lyric=l["lyric"],
        lyricAttribution="بند اصیل نوشته‌شده برای Thug Life؛ برگرفته از هیچ ترانه‌ی موجودی نیست.",
        newExample=l["newex"], listenAudio=audio_for(l["listen"]["text"])))
    for i, eid in enumerate(l["exprs"]):
        le_rows.append(dict(lesson="l_" + l["id"], expr=xid(eid), pos=i))

out = dict(version=CONTENT_VERSION, audioAssets=sorted(audio.values(), key=lambda a: a["id"]), expressions=exprs_out,
           lessons=lessons_out, lessonExpressions=le_rows, exercises=exercises, scenarios=scen_rows, scenarioSteps=step_rows)
path = os.path.join(os.path.dirname(__file__), "..", "..", "app", "src", "main", "assets", "content", "curriculum.json")
os.makedirs(os.path.dirname(path), exist_ok=True)
with open(path, "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, separators=(",", ":"))
from collections import Counter
print("expressions", len(exprs_out), "lessons", len(lessons_out), "scenarios", len(scen_rows), "steps", len(step_rows))
print("exercises", len(exercises), dict(Counter(x["type"] for x in exercises)))
print("audio assets", len(audio), "bytes", os.path.getsize(path))
